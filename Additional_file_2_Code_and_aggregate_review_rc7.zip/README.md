# CABG creatinine-reference decomposition code and aggregate review material

Version aki-code-2026-11-17-rc7. Software creators: Yi Liu, Hui Wang, Qian Sun, in that order. The study representative confirmed source/institution/third-party checks and permission to release the included code and selected aggregates. This code is associated with an exploratory methods application in MIMIC-IV 3.1 and eICU-CRD 2.0; it is not a clinically validated AKI definition.

## Check the extracted fixed snapshot

From a clean extracted archive with ordinary Python, run:

    python -X utf8 -B review_tools/check_release_bundle.py --report ../release_check.json
    python -X utf8 -B scripts/check_exact_aggregates_r3.py --data aggregate_data/aggregate_core_r3.json --report ../exact_check.json

Report paths must be new and outside the snapshot. The aggregate checker uses the standard library. It checks existing primary counts/points, denominator/flow consistency, supplied SMD arithmetic and figure sources. It does not execute source classifications or reproduce clustered confidence intervals. Original CI endpoints are supplied; independent external classification/CI reproduction has not been completed.

## Reproduction and source access

reviewable_code/README.md and run_local.py describe independently authorized source execution, including the historical base-R point check. Each analyst must obtain their own source-data access. Patient records, complete retained formal outputs and cluster-resampling matrices are excluded. No clinical, bootstrap or R execution was performed for this reporting revision.

The original eight engines, two rule projections, aggregate_core_r3.json and figure source CSVs are preserved. The plotting script now adds direct estimate/CI labels and emphasizes the net difference without recalculating intervals. The name r3 in frozen data/script paths identifies the reporting origin; it is not the current package version. Historical LOCAL/PUBLIC labels in archived source metadata do not determine current external access or release permission.

## Licences and citation

MIT covers original project software; CC BY 4.0 covers original documentation, figure-source material and selected shareable aggregates within LICENSE_SCOPE.md. Source databases and third-party rights are excluded. See AUTHORS.txt and CITATION.cff for confirmed software attribution. Repository and registered archive identifiers are established by the actual release landing pages, not by historical preparation flags.

## Figures

Install the separately listed figure dependencies in your own environment, then run:

    python scripts/plot_figures_r3.py --data-dir figure_data --out-dir ../figures_reproduced

Outputs render existing aggregates only. Interval endpoints must not be summed. Clinical record access is never granted by these licences or commands.
