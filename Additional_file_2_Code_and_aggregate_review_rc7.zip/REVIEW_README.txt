Review scope for aki-code-2026-11-17-rc7

See README.md and RESULT_REVIEW_MAP.json. Included data-free checks cover original selected primary point/SMD arithmetic, flow/denominator and figure-source consistency. Complete retained outputs and resampling inputs are not supplied. Independently authorized source execution is documented, but external classification/CI reproduction is incomplete.

Creators Yi Liu; Hui Wang; Qian Sun and file-specific MIT/CC BY 4.0 release permission are confirmed through the study representative. Actual hosting/DOI state must be checked on the release landing pages. Do not treat historical local-only flags as current availability evidence, or as a provider-mandated numerical suppression rule.
