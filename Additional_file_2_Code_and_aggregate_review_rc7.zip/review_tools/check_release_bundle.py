"""Verify the local code/released-aggregate archive; no clinical data or network.

Run from any directory with an ordinary Python interpreter. This script never
imports or executes the clinical engines. It checks only archive files and
already disclosed aggregate values; it cannot validate clinical classification,
bootstrap uncertainty, or the safety of every possible combined disclosure.
"""
from pathlib import Path, PurePosixPath
from decimal import Decimal, InvalidOperation, ROUND_CEILING
import argparse
import ast
import hashlib
import json
import sys


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path):
    def unique_pairs(pairs):
        out = {}
        for key, value in pairs:
            require(key not in out, 'Duplicate JSON key in ' + path.name)
            out[key] = value
        return out
    return json.loads(path.read_text(encoding='utf-8-sig'), object_pairs_hook=unique_pairs)


def inventory(root, manifest_name):
    require(root.is_dir(), 'Archive directory is missing.')
    actual = {}
    for p in root.rglob('*'):
        require(not p.is_symlink(), 'Symbolic links are not allowed in this archive.')
        if p.is_file() and p != root / manifest_name:
            require(root in p.resolve().parents, 'A file escapes the archive directory.')
            actual[p.relative_to(root).as_posix()] = p
    return actual


def verify_manifest(root, name):
    manifest = read_json(root / name)
    expected = manifest.get('sha256')
    require(isinstance(expected, dict) and expected, 'Missing nonempty sha256 manifest.')
    for rel, value in expected.items():
        key = PurePosixPath(rel)
        require(isinstance(rel, str) and not key.is_absolute() and '..' not in key.parts
                and '\\' not in rel and ':' not in rel and str(key) == rel,
                'Unsafe or noncanonical relative manifest path.')
        require(isinstance(value, str) and len(value) == 64
                and all(c in '0123456789abcdefABCDEF' for c in value),
                'Invalid SHA-256 digest in manifest.')
    actual = inventory(root, name)
    require(set(actual) == set(expected), 'Unexpected or missing archive file.')
    for rel, p in actual.items():
        require(digest(p) == expected[rel].lower(), 'Checksum mismatch: ' + rel)
    return actual


def main():
    import subprocess
    ap=argparse.ArgumentParser(description='Check archive integrity and exact aggregate arithmetic only.')
    ap.add_argument('--archive-root',default=str(Path(__file__).resolve().parents[1]))
    ap.add_argument('--report',help='New JSON report path outside this archive.')
    a=ap.parse_args();root=Path(a.archive_root).resolve(strict=True)
    output=Path(a.report).resolve() if a.report else None
    if output:
        require(not output.exists(),'Report path must be new.')
        require(output!=root and root not in output.parents,'Report must be outside archive.')
    all_files=verify_manifest(root,'archive_manifest.json')
    code_files=verify_manifest(root/'reviewable_code','package_checksums.json')
    for rel,p in all_files.items():
        if p.suffix=='.py':
            source=p.read_text(encoding='utf-8-sig');ast.parse(source,filename=rel);compile(source,rel,'exec')
        elif p.suffix=='.json':read_json(p)
    result=subprocess.run([sys.executable,'-B',str(root/'scripts/check_exact_aggregates_r3.py'),'--data',str(root/'aggregate_data/aggregate_core_r3.json')],capture_output=True,text=True,encoding='utf-8')
    require(result.returncode==0,'Exact aggregate checker failed: '+result.stderr)
    report={'status':'PASS','version':'aki-code-2026-11-17-rc7','archive_manifest_sha256':digest(root/'archive_manifest.json'),
        'archive_files_checked':len(all_files),'clinical_code_files_checked':len(code_files),
        'exact_checker_output':result.stdout.strip(),'clinical_engines_executed':False,
        'clinical_datasets_opened':False,'models_fitted':False,'bootstrap_reestimated':False,
        'scope':'Integrity, syntax and arithmetic of existing exact aggregates; no source-data or interval reproduction.',
        'not_established':['Clinical classification correctness','Bootstrap confidence-interval validity',
            'Independent external reproduction','Ethics/DUA authorization','Institutional publication approval']}
    if output:
        output.parent.mkdir(parents=True,exist_ok=True)
        with output.open('x',encoding='utf-8') as f:json.dump(report,f,ensure_ascii=False,indent=2)
    print(json.dumps(report,ensure_ascii=False,indent=2));return 0
if __name__=='__main__':
    try:raise SystemExit(main())
    except (ValueError,KeyError,OSError,SyntaxError,TypeError) as exc:
        print('Release-bundle check FAILED: '+str(exc),file=sys.stderr);raise SystemExit(2)

