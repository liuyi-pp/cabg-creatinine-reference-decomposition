# r3 candidate distribution scope

The study representative confirmed the source/institution/third-party checks and permission to release this code and selected aggregates under their file-specific licences. Existing results are restored for reporting; no model or clinical bootstrap is newly fitted or rerun.

The candidate result source is `aggregate_data/aggregate_core_r3.json`, with matching `figure_data/*.csv` and reporting/validation scripts. Selected full-cohort exact counts, original primary estimates and confidence limits, and existing large-group descriptive SMD summaries replace the previous coarse-only result display. The former whole-percent/count-range v4 JSONs are not the r3 result source. Source-to-result verification and final joint package review are separate from changing this documentation.

Other candidates are executable methods, configurations, exact selector projections, reviewed historical documentation and integrity hashes of the final included bytes. Database labels and structured dictionary paths in selector JSONs are method inputs, not patient records; the representative confirmed source-specific redistribution/attribution checks. Do not silently change required selector fields.

Excluded from ordinary public attachments: patient-level records and linkage keys; source database copies; complete internal formal files; unreviewed hospital, fine-stratum or nested-scenario numerical families; private runtime logs, input paths/fingerprints and credentials; old draft/archive histories and internal author decisions. A selected aggregate extracted for r3 is distinct from distributing the complete internal source object that also contains restricted details.

The previous blanket small-cell, coarse-rate and whole-family withholding rules were project-specific conservative choices, not demonstrated universal provider or journal requirements. Any small aggregate implied by the restored core counts/components must not be described as still concealed. Assess identity, hospital linkage, semantic rarity and cumulative outputs; a small reconstructed integer alone neither proves identification nor supplies automatic release permission. This package does not claim differential privacy or an anonymity theorem.

Private-original fingerprints remain excluded. Hashes of the actual candidate files establish integrity, not scientific validity, source truth or permission. Use a clean source snapshot for inventory checks: a Git worktree's `.git` is additional content and is not part of the frozen archive. Regenerate manifests after authorised final changes; do not weaken inventory checks to hide unexpected files.

GitHub, Zenodo, the journal article/supplements and future replies or public reviewer reports form one cumulative disclosure surface. An extra copy of the same selected result changes accessibility, not an independent privacy budget. Review later additions with the material already released.

Software rights do not automatically cover dictionaries, aggregates or documentation, and a code license cannot replace source-data conditions. `LICENSE_SCOPE.md` defines the MIT and CC BY 4.0 grants and their exclusions. The actual signed agreement and any institutional restrictions are not inferred from public policy review. Keep genuine owner/author decisions explicit without relabelling an agent-chosen numerical rule as an institutional mandate.

Included sufficient counts support public point-arithmetic checks. They do not independently reproduce clinical classification, descriptive distributions or cluster-bootstrap confidence intervals. The full source-data pipeline was not rerun for r3, the historical R check is not a new execution, and an external independent exact-CI review arrangement has not yet been established. A credentialed researcher must obtain source access individually; do not promise redistribution of source files or retained restricted outputs on request.


r4 current status: see REPORTING_AND_REVIEW_STATUS.md. Code access is established by the actual release record; source execution is documented. External independent CI execution and retained-output review arrangements are not completed.
