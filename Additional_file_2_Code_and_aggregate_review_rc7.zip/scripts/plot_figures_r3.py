#!/usr/bin/env python3
"""Render manuscript figures from the two accompanying aggregate CSV files.

Usage from the archive root:
  python scripts/plot_figures_r3.py --data-dir figure_data --out-dir ../r3_figures_reproduced
Requires Python and matplotlib. This script does not access clinical databases,
fit a model, generate simulated records, or recalculate confidence intervals.
An explicit output directory is required; there is no default write location.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import platform
import re
import xml.etree.ElementTree as ET

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
from matplotlib.text import Text

WIDTH_MM = 170.0
DPI = 300
MIN_FONT_PT = 8.5
DBS = ("mimic", "eicu")
DB_LABELS = {"mimic": "MIMIC-IV", "eicu": "eICU-CRD"}
METRICS = ("D", "R", "O", "P")
FLOW_FIELDS = ("database", "stage_order", "stage", "label", "unit", "n_before", "n_excluded", "n_after")
POINT_FIELDS = ("database", "metric", "estimate_pp", "ci95_lower_pp", "ci95_upper_pp", "cohort_N", "bootstrap_replicates", "bootstrap_unit", "interval_method")

plt.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["Arial", "DejaVu Sans"],
    "font.size": MIN_FONT_PT, "axes.labelsize": 9.0,
    "xtick.labelsize": MIN_FONT_PT, "ytick.labelsize": 9.0,
    "axes.linewidth": 0.7, "axes.spines.top": False,
    "axes.spines.right": False, "legend.frameon": False,
    "svg.fonttype": "none", "pdf.fonttype": 42,
    "svg.hashsalt": "aki-figures-r3", "savefig.facecolor": "white",
    "axes.unicode_minus": True,
})

def fail(message: str) -> None:
    raise ValueError(message)

def read_rows(path: Path, fields: tuple[str, ...]) -> list[dict]:
    with path.open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        if tuple(reader.fieldnames or ()) != fields:
            fail(f"Unexpected field schema in {path.name}")
        return list(reader)

def int_value(value: str, label: str) -> int:
    if not re.fullmatch(r"\d+", value):
        fail(f"Expected a nonnegative integer: {label}")
    return int(value)

def load_data(data_dir: Path) -> tuple[dict, dict, dict]:
    flow_rows = read_rows(data_dir / "figure1_source.csv", FLOW_FIELDS)
    point_rows = read_rows(data_dir / "figure2_source.csv", POINT_FIELDS)
    flow = {db: [] for db in DBS}
    points = {db: {} for db in DBS}
    seen = set()
    for row in flow_rows:
        if row["database"] not in flow or row["unit"] != "ICU/unit stays":
            fail("Unexpected flow database or count unit")
        row = dict(row)
        for key in ("stage_order", "n_before", "n_excluded", "n_after"):
            row[key] = int_value(row[key], key)
        identity = (row["database"], row["stage_order"])
        if identity in seen:
            fail("Duplicate grouped-flow row")
        seen.add(identity)
        if row["n_before"] - row["n_excluded"] != row["n_after"]:
            fail("Grouped-flow arithmetic mismatch")
        flow[row["database"]].append(row)
    expected_stages = {
        "mimic": ["source", "linked", "first", "adult_valid", "cabg", "primary"],
        "eicu": ["source", "first", "adult_valid", "cabg", "primary"],
    }
    for db in DBS:
        flow[db].sort(key=lambda r: r["stage_order"])
        if [r["stage"] for r in flow[db]] != expected_stages[db]:
            fail(f"Unexpected grouped-flow stages for {db}")
        if [r["stage_order"] for r in flow[db]] != list(range(len(flow[db]))):
            fail("Nonconsecutive grouped-flow ordering")
        for earlier, later in zip(flow[db], flow[db][1:]):
            if earlier["n_after"] != later["n_before"]:
                fail("Grouped-flow continuity mismatch")
    for row in point_rows:
        db, metric = row["database"], row["metric"]
        if db not in points or metric not in METRICS or metric in points[db]:
            fail("Unexpected or duplicate primary point row")
        row = dict(row)
        for key in ("estimate_pp", "ci95_lower_pp", "ci95_upper_pp"):
            row[key] = float(row[key])
            if not math.isfinite(row[key]):
                fail("Nonfinite primary point or interval")
        for key in ("cohort_N", "bootstrap_replicates"):
            row[key] = int_value(row[key], key)
        if not row["ci95_lower_pp"] <= row["estimate_pp"] <= row["ci95_upper_pp"]:
            fail("Point lies outside its supplied confidence limits")
        if row["bootstrap_replicates"] != 2000 or row["interval_method"] != "percentile_2.5_97.5":
            fail("Unexpected supplied resampling metadata")
        if row["bootstrap_unit"] != ("person" if db == "mimic" else "hospital"):
            fail("Unexpected supplied cluster unit")
        if row["cohort_N"] != flow[db][-1]["n_after"]:
            fail("Cohort N differs between the two figure sources")
        points[db][metric] = row
    identity_errors = {}
    for db in DBS:
        if set(points[db]) != set(METRICS):
            fail("Missing primary component")
        vals = {m: points[db][m]["estimate_pp"] for m in METRICS}
        identity_errors[db] = vals["D"] - vals["R"] - vals["O"] - vals["P"]
        if abs(identity_errors[db]) > 1e-10:
            fail("Supplied full-precision point identity mismatch")
        if vals["R"] < 0 or vals["O"] > 0:
            fail("Supplied point conflicts with the stated structural sign")
    return flow, points, {
        "flow_rows": len(flow_rows), "primary_rows": len(point_rows),
        "grouped_flow_arithmetic_and_continuity": "PASS",
        "cross_figure_cohort_N": "PASS",
        "supplied_point_identity_residual_pp": identity_errors,
        "clinical_classification_recalculated": False,
        "confidence_intervals_recomputed": False,
    }

def stage_text(db: str, stage: str) -> str:
    labels = {
        "source": "All ICU stay records" if db == "mimic" else "All unit stay records",
        "linked": "Successful source linkage",
        "first": "First recorded ICU stay\nper hospital admission" if db == "mimic" else "Recorded unitvisitnumber = 1",
        "adult_valid": "Adults with valid keys\nand observation boundaries",
        "cabg": "CABG-related candidate stays",
        "primary": "Primary cohort after\nchronic renal exclusions",
    }
    return labels[stage]

def make_flow(flow: dict):
    fig = plt.figure(figsize=(WIDTH_MM / 25.4, 176 / 25.4))
    for col, db in enumerate(DBS):
        ax = fig.add_axes([0.012 + col * 0.5, 0.055, 0.476, 0.905])
        ax.set(xlim=(0, 1), ylim=(0, 1))
        ax.axis("off")
        ax.text(0.045, 0.986, f"{'a' if col == 0 else 'b'}  {DB_LABELS[db]}",
                ha="left", va="top", fontsize=10, fontweight="bold")
        rows = flow[db]
        ys = [0.888 - i * (0.775 / (len(rows) - 1)) for i in range(len(rows))]
        height = 0.105
        for i, (row, y) in enumerate(zip(rows, ys)):
            final = row["stage"] == "primary"
            box = FancyBboxPatch((0.045, y - height / 2), 0.91, height,
                                 boxstyle="round,pad=0.004,rounding_size=0.008",
                                 facecolor="#e9ecef" if final else "white",
                                 edgecolor="#333333", linewidth=0.75)
            ax.add_patch(box)
            count_label = "N" if final else "n"
            label = f"{stage_text(db, row['stage'])}\n{count_label} = {row['n_after']}"
            ax.text(0.5, y, label, ha="center", va="center", fontsize=8.7,
                    linespacing=1.18, fontweight="bold" if final else "normal")
            if i:
                top = ys[i - 1] - height / 2 - 0.006
                bottom = y + height / 2 + 0.006
                ax.add_patch(FancyArrowPatch((0.5, top), (0.5, bottom),
                                             arrowstyle="-|>", mutation_scale=9,
                                             linewidth=0.8, color="#333333"))
                ax.text(0.555, (top + bottom) / 2, f"Excluded: {row['n_excluded']}",
                        ha="left", va="center", fontsize=8.5)
    fig.text(0.5, 0.025, "Counts are ICU/unit stays, not unique persons.",
             ha="center", va="center", fontsize=8.5)
    return fig

def make_components(points: dict):
    """Display the same original estimates/intervals with direct numeric labels."""
    fig = plt.figure(figsize=(170 / 25.4, 119 / 25.4))
    ax = fig.add_axes([0.29, 0.20, 0.385, 0.61])
    ax.axhspan(2.61, 3.40, facecolor="#eef1f4", edgecolor="none", zorder=0)
    for boundary in (0.5, 1.5, 2.5):
        ax.axhline(boundary, color="#dddddd", linewidth=0.6, zorder=0)
    ax.axvline(0, color="#666666", linewidth=0.8, linestyle=(0,(2,3)),zorder=1)
    colors={"mimic":"#286487","eicu":"#aa642f"}
    for db,offset,marker,filled in (("mimic",.14,"o",True),("eicu",-.14,"s",False)):
        for i,metric in enumerate(METRICS):
            row=points[db][metric];y=3-i+offset
            est,lo,hi=(row[k] for k in ("estimate_pp","ci95_lower_pp","ci95_upper_pp"))
            ax.errorbar(est,y,xerr=[[est-lo],[hi-est]],fmt=marker,markersize=5.2,
                markerfacecolor=colors[db] if filled else "white",markeredgecolor=colors[db],
                markeredgewidth=1.0,ecolor=colors[db],elinewidth=1.1,capsize=2.5,
                linestyle="none",zorder=3)
            ax.text(1.085,y,f"{est:+.2f} ({lo:+.2f} to {hi:+.2f})",
                transform=ax.get_yaxis_transform(),ha="left",va="center",fontsize=8.5,
                color=colors[db],fontweight="bold" if metric=="D" else "normal")
    ax.set(xlim=(-4,6),ylim=(-.50,3.53),xticks=[-4,-2,0,2,4,6],yticks=[3,2,1,0])
    ax.set_yticklabels(["D  Net difference","R  Reference","O  Additional\n     comparisons","P  Population"],fontsize=8.7)
    ax.get_yticklabels()[0].set_fontweight("bold")
    ax.tick_params(axis="y",length=0,pad=8);ax.tick_params(axis="x",length=3,width=.7)
    ax.spines["left"].set_visible(False)
    ax.set_xlabel("Difference (percentage points)",fontsize=8.5,labelpad=6)
    fig.text(.705,.84,"Estimate (95% CI)",ha="left",fontsize=8.5,fontweight="bold")
    handles=[Line2D([0],[0],marker="o",markersize=5.2,color=colors['mimic'],markerfacecolor=colors['mimic'],linestyle="none",label="MIMIC-IV (N = 5782)"),
        Line2D([0],[0],marker="s",markersize=5.2,color=colors['eicu'],markerfacecolor="white",linestyle="none",label="eICU-CRD (N = 4905)")]
    fig.legend(handles=handles,loc="upper center",bbox_to_anchor=(.54,.98),ncol=2,
        fontsize=8.5,handletextpad=.45,columnspacing=1.3)
    fig.text(.5,.075,"D = R + O + P before rounding",ha="center",fontsize=8.5)
    fig.text(.5,.025,"Opposing components can coexist with a small net difference.",
        ha="center",fontsize=8.5)
    return fig

def check_text_bounds(fig) -> dict:
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    bounds = fig.bbox
    outside = []
    small = []
    for obj in fig.findobj(Text):
        if not obj.get_visible() or not obj.get_text().strip():
            continue
        if obj.get_fontsize() < MIN_FONT_PT:
            small.append({"text": obj.get_text(), "points": obj.get_fontsize()})
        bbox = obj.get_window_extent(renderer)
        if bbox.x0 < bounds.x0 - 1 or bbox.y0 < bounds.y0 - 1 or bbox.x1 > bounds.x1 + 1 or bbox.y1 > bounds.y1 + 1:
            outside.append(obj.get_text())
    if outside or small:
        fail(f"Text bounds/font check failed: outside={outside}; small={small}")
    return {"outside_canvas_text": [], "text_smaller_than_minimum": [],
            "minimum_declared_font_pt": MIN_FONT_PT}

def save_figure(fig, stem: str, out_dir: Path) -> dict:
    geometry = check_text_bounds(fig)
    fig.savefig(out_dir / f"{stem}.pdf", metadata={"Creator": "matplotlib", "CreationDate": None, "ModDate": None},
                facecolor="white")
    fig.savefig(out_dir / f"{stem}.svg", metadata={"Creator": "matplotlib", "Date": None},
                facecolor="white")
    fig.savefig(out_dir / f"{stem}.png", dpi=DPI, metadata={"Software": "matplotlib"},
                facecolor="white")
    exports = {}
    for suffix in ("pdf", "svg", "png"):
        file = out_dir / f"{stem}.{suffix}"
        if file.stat().st_size > 10_000_000:
            fail("Figure exceeds the 10 MB target")
        exports[file.name] = {"bytes": file.stat().st_size,
                              "sha256": hashlib.sha256(file.read_bytes()).hexdigest()}
    svg = (out_dir / f"{stem}.svg").read_text(encoding="utf-8")
    svg_root = ET.fromstring(svg)
    text_count = len(svg_root.findall(".//{http://www.w3.org/2000/svg}text"))
    if not text_count or re.search(r"(?<![A-Za-z0-9])[A-Za-z]:[\\/]", svg):
        fail("SVG editable text or path privacy check failed")
    pdf = (out_dir / f"{stem}.pdf").read_bytes()
    if b"/FontFile2" not in pdf:
        fail("PDF does not contain an embedded TrueType font program")
    geometry.update({"editable_svg_text_nodes": text_count,
                     "pdf_embedded_truetype_font_program": True,
                     "svg_absolute_windows_path_found": False})
    dimensions = [round(v * 25.4, 3) for v in fig.get_size_inches()]
    plt.close(fig)
    return {"dimensions_mm": dimensions, "png_dpi": DPI,
            "geometry_and_text_checks": geometry, "exports": exports}

def captions() -> dict:
    return {'figure_1': {'title': 'Figure 1. Grouped cohort construction', 'legend': 'Sequential grouped selection of ICU/unit stays from each source database to the primary cohort. Counts are stays, not distinct persons. Adult eligibility and valid observation boundaries form a combined step; source-specific CABG evidence forms another. Grouped exclusions are not attributed to a single clinical reason. MIMIC-IV source linkage retained all 94458 source stays. Within each database, the primary row is the final N. Exact grouped counts and rule definitions are provided in Tables S1a and S1b.', 'source_data': 'figure1_source.csv'}, 'figure_2': {'title': 'Figure 2. Net differences and descriptive components', 'legend': 'Points and direct labels show the original D, R, O and P estimates and 95% percentile confidence intervals for the primary 168-hour analysis, in percentage points. Filled blue circles identify MIMIC-IV and open brown squares identify eICU-CRD; symbols also distinguish databases in grayscale. The shaded row highlights the net difference D. Intervals come from 2000 paired cluster bootstrap replicates, using person clusters in MIMIC-IV and hospital clusters in eICU-CRD. D uses strategy-specific evaluable denominators; R and O use common comparisons/populations, and P captures the population term along the specified path. R is nonnegative and O nonpositive by construction. Components sum to D before separate display rounding; interval endpoints cannot be added. Crossing zero does not establish equivalence or clinical diagnostic validity. No intervals were recalculated for this display revision.', 'source_data': 'figure2_source.csv'}}

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path,
                        default=Path(__file__).resolve().parent.parent / "figure_data",
                        help="CSV directory (default: archive figure_data beside scripts)")
    parser.add_argument("--out-dir", type=Path, required=True,
                        help="Explicit output directory; choose a directory outside the frozen archive")
    args = parser.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    flow, points, data_checks = load_data(args.data_dir)
    qa = {"status": "COMPUTATIONAL_EXPORT_QA_PASS_VISUAL_REVIEW_REQUIRED",
          "scope": "Figure rendering of existing aggregate values only; no source extraction or statistical rerun.",
          "python_version": platform.python_version(), "matplotlib_version": matplotlib.__version__,
          "data_checks": data_checks,
          "source_csv_sha256": {n: hashlib.sha256((args.data_dir / n).read_bytes()).hexdigest()
                                for n in ("figure1_source.csv", "figure2_source.csv")},
          "figure_1": save_figure(make_flow(flow), "Figure_1_grouped_flow", args.out_dir),
          "figure_2": save_figure(make_components(points), "Figure_2_components", args.out_dir),
          "public_release_authorized_by_script": False}
    legends = captions()
    for item in legends.values():
        if len(item["title"].split()) > 15 or len(item["legend"].split()) > 300:
            fail("Caption exceeds the checked BMC length limits")
    (args.out_dir / "figure_captions.json").write_text(json.dumps(legends, indent=2) + "\n", encoding="utf-8")
    (args.out_dir / "figure_qa.json").write_text(json.dumps(qa, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": qa["status"], "flow_rows": data_checks["flow_rows"],
                      "primary_rows": data_checks["primary_rows"], "figures": 2}))

if __name__ == "__main__":
    main()
