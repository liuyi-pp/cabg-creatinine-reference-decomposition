#!/usr/bin/env python3
"""Check released aggregate arithmetic and structure; never reads clinical data.

Python standard library only. This is NOT a source-data rerun, an independent
bootstrap validation, an historical R rerun, or permission to publish data.
No source fingerprint or private historical file is needed. Run --help.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import re
import sys

COUNTS = 'N EA EB C YA YB YA_own_in_C YB_own_in_C YAJ YBJ refA refB'.split()
GROUPS = ['EA', 'EB', 'C']
POPULATIONS = ['N', 'EA', 'not_EA', 'EB', 'not_EB', 'C', 'not_C']
CONTINUOUS = ['age', 'admit_lag', 'post_count', 'last_gap_h']
CATEGORICAL = ['sex', 'age_group', 'age_recording']
OBSERVATION = ['observation_h', 'pre_count', 'post_count', 'last_gap_h',
               'post_median_gap_h', 'refA_age_h', 'refB_age_h', 'last_pre_age_h']
VARIABLES = ['age', 'admit_lag', 'sex', 'age_group', *OBSERVATION]
CONTRASTS = ['D', 'R', 'O', 'P', 'delta_eval']
SUMMARY_KEYS = 'n_total n_observed n_missing_or_nonnumeric mean sd q1 median q3'.split()
CAT_KEYS = 'selected_n other_n selected_proportion other_proportion signed_SMD'.split()
DEN_KEYS = ('population variable label unit n_total n_available n_unavailable '
            'n_privacy_topcoded n_other_missing_or_nonnumeric '
            'n_undefined_required_measurement_absent definition').split()
BOOT_KEYS = ('method cluster_count person_count hospital_count cross_hospital_person_count '
             'replicates seed backend numpy_version interval_method '
             'same_weights_all_strategies_and_subsets max_na_fraction_for_reportable_interval '
             'maximum_absolute_identity_error_percentage_points').split()
FORBIDDEN_KEYS = set(('subject_id hadm_id stay_id patientunitstayid uniquepid patient_id '
                     'source_files loaded_module_paths script_hashes source_jsonpath json_path '
                     'pre_state common_matrix hospital_summary variants secondary sql query '
                     'source_formal source_json_paths source_sha256 original_plan_sha256 '
                     'hospitalid hospital_id').split())
# This checker's arithmetic policy, chosen explicitly for float64 aggregate
# ratios/subtractions, is separate from historical R-Python agreement evidence.
PROPORTION_ATOL = 1e-12
PP_ATOL = 1e-10
SMD_ATOL = 1e-12
SMD_RTOL = 1e-12


def require(condition, where, message):
    if not condition:
        raise ValueError(f'{where}: {message}')


def keys(value, expected, where):
    require(isinstance(value, dict), where, 'expected an object')
    require(set(value) == set(expected), where, 'unexpected or missing keys')


def integer(value, where):
    require(type(value) is int and value >= 0, where, 'expected a nonnegative integer')
    return value


def finite(value, where, nullable=False):
    if value is None and nullable:
        return
    require(type(value) in (int, float) and math.isfinite(value), where, 'expected finite number')


def close(actual, expected, where, atol=PROPORTION_ATOL, rtol=0):
    if expected is None:
        require(actual is None, where, 'expected undefined/null')
    else:
        finite(actual, where)
        require(math.isclose(actual, expected, abs_tol=atol, rel_tol=rtol),
                where, 'aggregate arithmetic mismatch')


def ratio(numerator, denominator):
    return numerator / denominator if denominator else None


def scalar_smd(a, b, denominator):
    if denominator:
        return (a - b) / denominator
    return 0.0 if a == b else None


def continuous_smd(a, b):
    if any(v is None for v in [a['mean'], b['mean'], a['sd'], b['sd']]):
        return None
    return scalar_smd(a['mean'], b['mean'], math.sqrt((a['sd'] ** 2 + b['sd'] ** 2) / 2))


def binary_smd(a, b):
    if a is None or b is None:
        return None
    return scalar_smd(a, b, math.sqrt((a * (1 - a) + b * (1 - b)) / 2))


def scan_scope(value, where='$'):
    if isinstance(value, dict):
        for key, item in value.items():
            require(key.casefold() not in FORBIDDEN_KEYS, where, 'forbidden field')
            require(not any(s in key.casefold() for s in ('sha256', 'token', 'password', 'secret')),
                    where, 'private metadata/secret-like field')
            scan_scope(item, f'{where}.{key}')
    elif isinstance(value, list):
        for index, item in enumerate(value):
            scan_scope(item, f'{where}[{index}]')
    elif isinstance(value, str):
        require(re.search(r'(?i)\b[a-z]:[\\/]|\\\\|file://|/home/|/Users/|/mnt/', value) is None,
                where, 'local filesystem path found')
        require(re.search(r'(?i)(?<![a-f0-9])[a-f0-9]{64}(?![a-f0-9])', value) is None,
                where, 'source-fingerprint-like value found')
        require(re.search(r'(?i)\bBearer\s+|\beyJ[A-Za-z0-9_-]{8,}\.', value) is None,
                where, 'credential-like value found')
    elif type(value) is float:
        finite(value, where)


def quantiles(summary, where, observed):
    values = [summary[k] for k in ('q1', 'median', 'q3')]
    if observed == 0:
        require(values == [None, None, None], where, 'empty summary has quantiles')
    else:
        for v in values:
            finite(v, where)
        require(values[0] <= values[1] <= values[2], where, 'quantile order invalid')


def check_summary(summary, size, where):
    keys(summary, SUMMARY_KEYS, where)
    for key in SUMMARY_KEYS[:3]:
        integer(summary[key], f'{where}.{key}')
    require(summary['n_total'] == size, where, 'population denominator mismatch')
    require(summary['n_observed'] + summary['n_missing_or_nonnumeric'] == size,
            where, 'observed and missing counts do not sum to population')
    finite(summary['mean'], where, nullable=True)
    finite(summary['sd'], where, nullable=True)
    require(summary['sd'] is None or summary['sd'] >= 0, where, 'negative standard deviation')
    require(summary['n_observed'] != 0 or summary['mean'] is None, where, 'empty mean is not null')
    quantiles(summary, where, summary['n_observed'])


def check_primary(p, db, where):
    keys(p, ['counts', 'rates', 'contrasts_percentage_points', 'confidence_intervals', 'bootstrap'], where)
    c = p['counts']; keys(c, COUNTS, where + '.counts')
    for key, val in c.items():
        integer(val, where + '.counts.' + key)
    require(c['N'] > 0, where, 'primary population must be nonempty')
    for name in ('EA', 'EB', 'C', 'refA', 'refB'):
        require(c[name] <= c['N'], where, 'population margin exceeds N')
    for lhs, rhs in [('EA', 'refA'), ('EB', 'refB'), ('refA', 'refB'), ('C', 'EA'), ('C', 'EB'),
                     ('YA', 'EA'), ('YB', 'EB'), ('YA_own_in_C', 'C'), ('YB_own_in_C', 'C'),
                     ('YA_own_in_C', 'YA'), ('YB_own_in_C', 'YB'), ('YAJ', 'YA_own_in_C'),
                     ('YBJ', 'YB_own_in_C'), ('YAJ', 'YBJ')]:
        require(c[lhs] <= c[rhs], where, f'margin nesting failed for {lhs} and {rhs}')
    require(c['YB_own_in_C'] == c['YBJ'], where, 'frozen B/common comparison equality failed')
    for suffix in 'AB':
        require(c['Y' + suffix] - c['Y' + suffix + '_own_in_C'] <= c['E' + suffix] - c['C'],
                where, 'positive count outside C exceeds outside-C population')
    r = {'eval_A': ratio(c['EA'], c['N']), 'eval_B': ratio(c['EB'], c['N']),
         'common': ratio(c['C'], c['N']), 'reference_A': ratio(c['refA'], c['N']),
         'reference_B': ratio(c['refB'], c['N'])}
    for s in 'AB':
        r['positive_among_evaluable_' + s] = ratio(c['Y' + s], c['E' + s])
        r['recorded_positive_fraction_N_' + s] = ratio(c['Y' + s], c['N'])
        r['not_evaluable_fraction_N_' + s] = ratio(c['N'] - c['E' + s], c['N'])
        r['no_positive_observed_fraction_N_' + s] = ratio(c['E' + s] - c['Y' + s], c['N'])
        r['positive_own_in_C_' + s] = ratio(c['Y' + s + '_own_in_C'], c['C'])
        r['positive_common_comparisons_' + s] = ratio(c['Y' + s + 'J'], c['C'])
    keys(p['rates'], r, where + '.rates')
    for name, expected in r.items():
        close(p['rates'][name], expected, where + '.rates.' + name)
    a, b = r['positive_among_evaluable_A'], r['positive_among_evaluable_B']
    ac, bc = r['positive_own_in_C_A'], r['positive_own_in_C_B']
    aj, bj = r['positive_common_comparisons_A'], r['positive_common_comparisons_B']
    expected_points = {
        'D': None if a is None or b is None else 100 * (b - a),
        'R': None if aj is None or bj is None else 100 * (bj - aj),
        'O': None if any(v is None for v in [ac, bc, aj, bj]) else 100 * ((bc - bj) - (ac - aj)),
        'P': None if any(v is None for v in [a, b, ac, bc]) else 100 * ((b - bc) - (a - ac)),
        'delta_eval': 100 * (c['EB'] - c['EA']) / c['N']}
    points = p['contrasts_percentage_points']; keys(points, CONTRASTS, where + '.contrasts')
    for name, expected in expected_points.items():
        close(points[name], expected, where + '.contrasts.' + name, PP_ATOL)
    if all(points[k] is not None for k in ['D', 'R', 'O', 'P']):
        close(points['D'], points['R'] + points['O'] + points['P'], where + '.identity', PP_ATOL)
        require(points['R'] >= -PP_ATOL and points['O'] <= PP_ATOL, where, 'frozen-rule direction failed')
    boot = p['bootstrap']; keys(boot, BOOT_KEYS, where + '.bootstrap')
    for name in ['cluster_count', 'person_count', 'hospital_count', 'cross_hospital_person_count', 'replicates', 'seed']:
        integer(boot[name], where + '.bootstrap.' + name)
    require(0 < boot['cluster_count'] <= c['N'] and 0 < boot['person_count'] <= c['N'], where, 'invalid bootstrap support')
    require(boot['cross_hospital_person_count'] <= boot['person_count'], where, 'cross-hospital person margin invalid')
    require(boot['replicates'] > 0, where, 'bootstrap replicates must be positive')
    require(boot['same_weights_all_strategies_and_subsets'] is True, where, 'paired resampling flag is not true')
    require(boot['method'] == {'mimic': 'whole_person', 'eicu': 'whole_hospital_person_nested'}[db], where, 'unexpected bootstrap method')
    require(boot['cluster_count'] == boot['person_count' if db == 'mimic' else 'hospital_count'], where, 'cluster unit/support mismatch')
    finite(boot['maximum_absolute_identity_error_percentage_points'], where)
    require(boot['maximum_absolute_identity_error_percentage_points'] >= 0, where, 'negative error support field')
    threshold = boot['max_na_fraction_for_reportable_interval']; finite(threshold, where)
    require(0 <= threshold <= 1, where, 'invalid bootstrap NA threshold')
    ci = p['confidence_intervals']; keys(ci, [*r, *CONTRASTS], where + '.confidence_intervals')
    for name, interval in ci.items():
        at = where + '.confidence_intervals.' + name
        keys(interval, ['lower', 'upper', 'na_fraction', 'valid_replicates', 'reportable',
                        'NA_replicates', 'unit', 'caution_few_independent_clusters'], at)
        for k in ['valid_replicates', 'NA_replicates']:
            integer(interval[k], at + '.' + k)
        require(interval['valid_replicates'] + interval['NA_replicates'] == boot['replicates'], at, 'replicate support does not sum')
        close(interval['na_fraction'], interval['NA_replicates'] / boot['replicates'], at + '.na_fraction')
        require(interval['unit'] == ('percentage_points' if name in CONTRASTS else 'proportion'), at, 'unit mismatch')
        require(type(interval['reportable']) is bool and type(interval['caution_few_independent_clusters']) is bool, at, 'invalid flags')
        for end in ['lower', 'upper']:
            finite(interval[end], at + '.' + end, nullable=True)
        require((interval['lower'] is None) == (interval['upper'] is None), at, 'one interval endpoint is absent')
        if interval['lower'] is not None:
            require(interval['lower'] <= interval['upper'], at, 'interval endpoint order invalid')
            if name not in CONTRASTS:
                require(0 <= interval['lower'] <= interval['upper'] <= 1, at, 'proportion interval outside unit range')
        if interval['reportable']:
            require(interval['lower'] is not None and interval['na_fraction'] <= threshold, at, 'reportability metadata inconsistent')
    return c


def check_descriptions(d, c, db, where):
    groups = d['descriptive_comparisons']; keys(groups, GROUPS, where)
    categories = {'sex': ['F', 'M'] if db == 'mimic' else ['Female', 'Male'],
                  'age_group': ['18-64', '65-79', '>=80'] + (['unknown'] if db == 'mimic' else []),
                  'age_recording': ['numeric', 'privacy_topcoded']}
    full_categories = {v: {} for v in CATEGORICAL}
    for group, g in groups.items():
        at = where + '.' + group
        keys(g, ['selected_n', 'other_n', 'continuous', 'categorical'], at)
        integer(g['selected_n'], at); integer(g['other_n'], at)
        require(g['selected_n'] == c[group] and g['other_n'] == c['N'] - c[group], at, 'group size mismatch')
        keys(g['continuous'], CONTINUOUS, at + '.continuous')
        keys(g['categorical'], CATEGORICAL, at + '.categorical')
        for variable, v in g['continuous'].items():
            loc = at + '.continuous.' + variable
            keys(v, ['selected', 'other', 'signed_SMD', 'role'], loc)
            for side in ['selected', 'other']:
                check_summary(v[side], g[side + '_n'], loc + '.' + side)
            require(v['role'] == ('observation_process' if variable in ['post_count', 'last_gap_h'] else 'baseline_description'), loc, 'variable role mismatch')
            close(v['signed_SMD'], continuous_smd(v['selected'], v['other']), loc + '.signed_SMD', SMD_ATOL, SMD_RTOL)
        for variable, levels in g['categorical'].items():
            loc = at + '.categorical.' + variable
            keys(levels, categories[variable], loc)
            for side in ['selected', 'other']:
                require(sum(integer(v[side + '_n'], loc) for v in levels.values()) == g[side + '_n'], loc, 'category counts do not sum')
            for category, v in levels.items():
                point = loc + '.' + category
                keys(v, CAT_KEYS, point)
                for side in ['selected', 'other']:
                    close(v[side + '_proportion'], ratio(v[side + '_n'], g[side + '_n']), point + '.' + side)
                close(v['signed_SMD'], binary_smd(v['selected_proportion'], v['other_proportion']), point + '.signed_SMD', SMD_ATOL, SMD_RTOL)
                total = v['selected_n'] + v['other_n']
                if group == 'EA':
                    full_categories[variable][category] = total
                else:
                    require(full_categories[variable][category] == total, point, 'disjoint partitions imply different overall count')
    return full_categories


def check_context(d, c, totals, where):
    ctx = d['full_cohort_context']
    keys(ctx, ['N', 'observation_summary', 'categorical_counts', 'recorded_male',
               'recorded_age_at_least_65', 'numeric_age_overall_quantiles', 'numeric_age_note'], where)
    require(ctx['N'] == c['N'], where, 'full-cohort N mismatch')
    obs = ctx['observation_summary']; keys(obs, ['n', *OBSERVATION], where + '.observation_summary')
    require(obs['n'] == c['N'], where, 'observation N mismatch')
    for name in OBSERVATION:
        v = obs[name]; at = where + '.observation_summary.' + name
        keys(v, ['observed', 'missing', 'q1', 'median', 'q3'], at)
        require(integer(v['observed'], at) + integer(v['missing'], at) == c['N'], at, 'observed and missing counts do not sum')
        quantiles(v, at, v['observed'])
    keys(ctx['categorical_counts'], CATEGORICAL, where + '.categorical_counts')
    for variable, values in totals.items():
        v = ctx['categorical_counts'][variable]
        keys(v, ['counts', 'denominator'], where)
        require(v['counts'] == values and v['denominator'] == c['N'], where, 'overall categories differ from partitions')
    male = ctx['recorded_male']; keys(male, ['n', 'denominator', 'proportion', 'source_category_label'], where)
    labels = [x for x in totals['sex'] if x.strip().casefold() in {'m', 'male'}]
    require(len(labels) == 1 and male['source_category_label'] == labels[0], where, 'male category label missing/ambiguous')
    require(male['n'] == totals['sex'][labels[0]] and male['denominator'] == c['N'], where, 'male count does not match recorded label')
    close(male['proportion'], male['n'] / c['N'], where + '.recorded_male.proportion')
    old = ctx['recorded_age_at_least_65']; keys(old, ['n', 'denominator', 'proportion'], where)
    require(old['n'] == totals['age_group']['65-79'] + totals['age_group']['>=80'] and old['denominator'] == c['N'], where, 'older-age group sum mismatch')
    close(old['proportion'], old['n'] / c['N'], where + '.recorded_age_at_least_65.proportion')
    require(ctx['numeric_age_overall_quantiles'] is None, where, 'overall numeric-age quantiles must not be synthesized')


def check_denominators(d, c, where):
    rows = d['variable_denominators']; require(isinstance(rows, list), where, 'expected denominator rows')
    index = {}
    for row in rows:
        keys(row, DEN_KEYS, where)
        pop, var = row['population'], row['variable']; at = where + '.' + pop + '.' + var
        require(pop in POPULATIONS and var in VARIABLES, at, 'unknown population or variable')
        require((pop, var) not in index, at, 'duplicate denominator row')
        index[(pop, var)] = row
        size = c['N'] if pop == 'N' else (c['N'] - c[pop[4:]] if pop.startswith('not_') else c[pop])
        for k in ['n_total', 'n_available', 'n_unavailable', 'n_privacy_topcoded',
                  'n_other_missing_or_nonnumeric', 'n_undefined_required_measurement_absent']:
            integer(row[k], at + '.' + k)
        require(row['n_total'] == size and row['n_available'] + row['n_unavailable'] == size, at, 'denominator sum mismatch')
        require(sum(row[k] for k in ['n_privacy_topcoded', 'n_other_missing_or_nonnumeric', 'n_undefined_required_measurement_absent']) == row['n_unavailable'], at, 'unavailable components do not sum')
        if pop != 'N':
            group = pop[4:] if pop.startswith('not_') else pop
            side = 'other' if pop.startswith('not_') else 'selected'
            g = d['descriptive_comparisons'][group]
            if var in CONTINUOUS:
                v = g['continuous'][var][side]
                require(row['n_available'] == v['n_observed'] and row['n_unavailable'] == v['n_missing_or_nonnumeric'], at, 'continuous availability mismatch')
            if var == 'sex':
                require(row['n_available'] == sum(v[side + '_n'] for v in g['categorical']['sex'].values()), at, 'sex availability mismatch')
            if var == 'age_group':
                require(row['n_available'] == sum(v[side + '_n'] for k, v in g['categorical']['age_group'].items() if k != 'unknown'), at, 'age category availability mismatch')
            if var == 'age':
                require(row['n_privacy_topcoded'] == g['categorical']['age_recording']['privacy_topcoded'][side + '_n'], at, 'topcoded-age category mismatch')
        elif var in OBSERVATION:
            v = d['full_cohort_context']['observation_summary'][var]
            require(row['n_available'] == v['observed'] and row['n_unavailable'] == v['missing'], at, 'full-N observation availability mismatch')
    require(set(index) == {(p, v) for p in POPULATIONS for v in VARIABLES}, where, 'seven-population variable grid incomplete')
    for group in GROUPS:
        for var in VARIABLES:
            for field in ['n_total', 'n_available', 'n_unavailable', 'n_privacy_topcoded',
                          'n_other_missing_or_nonnumeric', 'n_undefined_required_measurement_absent']:
                require(index[(group, var)][field] + index[('not_' + group, var)][field] == index[('N', var)][field], where, 'partition denominator does not reconstruct N')
    for var, field in [('refA_age_h', 'refA'), ('refB_age_h', 'refB')]:
        require(index[('N', var)]['n_available'] == c[field], where, 'reference availability mismatch')


def check(data):
    scan_scope(data)
    keys(data, ['schema_version', 'status', 'scope', 'precision', 'units', 'interpretation', 'databases'], '$')
    require(data['schema_version'] == 'aki-aggregate-core-r3-1', '$', 'unsupported schema')
    require(data['status'] == 'LOCAL_CANDIDATE_NOT_UPLOADED', '$', 'unexpected candidate status')
    keys(data['units'], ['rates', 'primary_contrasts', 'SMD', 'observation_time', 'age', 'measurement_count'], '$.units')
    keys(data['databases'], ['mimic', 'eicu'], '$.databases')
    for db, d in data['databases'].items():
        at = '$.databases.' + db
        keys(d, ['label', 'release', 'source_release_era', 'date_scope_note', 'observation_unit',
                 'recorded_runtime', 'primary', 'grouped_flow', 'descriptive_comparisons',
                 'full_cohort_context', 'variable_denominators'], at)
        require(d['label'] == {'mimic': 'MIMIC-IV', 'eicu': 'eICU-CRD'}[db], at, 'database label mismatch')
        keys(d['recorded_runtime'], ['python', 'numpy', 'duckdb'], at + '.recorded_runtime')
        c = check_primary(d['primary'], db, at + '.primary')
        flow = d['grouped_flow']
        stages = ['source'] + (['linked'] if db == 'mimic' else []) + ['first', 'adult_valid', 'cabg', 'primary']
        require(isinstance(flow, list) and [r.get('stage') for r in flow] == stages, at, 'grouped flow stages mismatch')
        previous = None
        for row in flow:
            loc = at + '.grouped_flow.' + row['stage']
            keys(row, ['stage', 'label', 'unit', 'n_before', 'n_excluded', 'n_after'], loc)
            for k in ['n_before', 'n_excluded', 'n_after']:
                integer(row[k], loc + '.' + k)
            require(row['n_before'] - row['n_excluded'] == row['n_after'], loc, 'flow subtraction mismatch')
            if previous is not None:
                require(row['n_before'] == previous, loc, 'flow continuity mismatch')
            previous = row['n_after']
        require(previous == c['N'], at, 'flow endpoint differs from primary N')
        totals = check_descriptions(d, c, db, at + '.descriptive_comparisons')
        check_context(d, c, totals, at + '.full_cohort_context')
        check_denominators(d, c, at + '.variable_denominators')
    return {
        'status': 'PASS_AGGREGATE_ARITHMETIC_AND_STRUCTURE',
        'schema_version': data['schema_version'],
        'checked_databases': ['mimic', 'eicu'],
        'checked_denominator_populations': POPULATIONS,
        'scope': ['Released sufficient-count rates and point contrasts', 'D = R + O + P identity',
                  'Original CI endpoint/support structure only', 'Grouped cohort flow',
                  'Descriptive SMD arithmetic and disjoint categorical totals',
                  'All seven population-by-variable denominator grids',
                  'Forbidden fields, source fingerprints and local path patterns'],
        'numerical_policy': {'proportion_absolute_tolerance': PROPORTION_ATOL,
                             'point_and_identity_percentage_point_absolute_tolerance': PP_ATOL,
                             'SMD_absolute_tolerance': SMD_ATOL, 'SMD_relative_tolerance': SMD_RTOL,
                             'purpose': 'Explicit policy for arithmetic on published float64 summaries; not historical R-Python validation tolerance.'},
        'not_established': ['Source-row correctness or licensed access', 'CI resampling correctness or coverage',
                            'Historical software execution or R verification', 'External publication approval',
                            'Absence of small direct or algebraically derivable counts'],
        'clinical_data_read': False, 'clinical_pipeline_or_model_or_bootstrap_run': False}


def no_duplicates(pairs):
    out = {}
    for key, value in pairs:
        require(key not in out, '$', 'duplicate JSON key')
        out[key] = value
    return out


def default_data():
    here = Path(__file__).resolve().parent
    options = [here.parent / 'aggregate_data' / 'aggregate_core_r3.json',
               here / 'aggregate_data' / 'aggregate_core_r3.json', here / 'aggregate_core_r3.json']
    return next((p for p in options if p.is_file()), options[0])


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--data', type=Path, default=None,
                        help='Aggregate JSON file or its directory. Default: ../aggregate_data/aggregate_core_r3.json; adjacent candidate fallback.')
    parser.add_argument('--report', type=Path, help='Optional NEW JSON report path; existing files are never overwritten.')
    args = parser.parse_args()
    path = args.data or default_data()
    if path.is_dir():
        path = path / 'aggregate_core_r3.json'
    try:
        data = json.loads(path.read_text(encoding='utf-8-sig'), object_pairs_hook=no_duplicates,
                          parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Non-finite JSON literal')))
        result = check(data)
        if args.report:
            args.report.parent.mkdir(parents=True, exist_ok=True)
            with args.report.open('x', encoding='utf-8') as output:
                json.dump(result, output, indent=2, ensure_ascii=False, allow_nan=False)
                output.write('\n')
        print(result['status'])
        print('No clinical data, model, bootstrap or historical R execution; CI structure only.')
        return 0
    except (ValueError, OSError, KeyError, TypeError, ArithmeticError) as error:
        print('FAIL: ' + str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
