# Reviewable clinical analysis code retained for r3

This is the archived reviewable code containing executable cohort construction, SQL/Python classification, statistical calculations and an independent R point check. It contains no patient records, fitted model, observed outcome matrix, numerical result file or publication builder. No clinical analysis or bootstrap was rerun to prepare this package. Actual repository status is reported on the release landing page.

The r3 work restores selected exact primary results and existing SMD summaries from previously stored aggregates first supplied in the rc2 candidate and preserved in the current enclosing candidate. The code below enables a separately authorized researcher to inspect the methods and, with their own authorized MIMIC-IV/eICU-CRD files, attempt reproduction. Authorization and ethics approval are not supplied by this package. All authors approved the manuscript and authorized MIT/CC BY 4.0 for project-owned content. Software attribution is confirmed in ../AUTHORS.txt; licensing does not authorize data access.

## Contents and provenance

| File | Role |
|---|---|
| `engine/audit_round2.py` | Discovers actual local CSV/TSV tables and columns, guards required fields, casts values explicitly, links records, normalizes creatinine and timestamps. |
| `engine/audit_round3.py` | Exact CABG and renal evidence selectors; renal flags; duplicate/conflicting timestamp handling; legacy three-state screening. |
| `engine/audit_round5.py` | Frozen final analysis, exact-second endpoint/death handling, strategy and common-key classification, independent SQL/Python comparisons, scenarios and aggregate output. |
| `engine/analysis_stats.py` | Denominators, decomposition, descriptive summaries and cluster bootstrap. |
| `engine/flow_audit.py` | Reconstructs sequential screening and grouped flow; compares the selected stay sets and source hashes against a prior formal run. |
| `engine/denominator_audit.py` | Reconstructs variable-specific nonmissing/undefined/topcoded denominators from internal frozen aggregates. |
| `engine/extract_aggregate_counts.py`, `engine/verify_points.R` | Export internal sufficient counts and independently recalculate point estimates in base R. |
| `rules/*.json` | All exact CABG, chronic renal and RRT selector fields read by the frozen engine. No utilization frequencies. |
| `schema_requirements.json` | Static table/column index extracted from code, with source locations. It is not an inventory of a newly inspected database. |
| `protocol_parameters.json`, `METHOD_IMPLEMENTATION.md` | Method map, fixed settings and interpretation limits. |
| `protocol/` | A clearly marked reviewed extract of the dated plan, a reviewed public extract of the implementation record, a dated interpretation addendum and redaction/provenance notes. The unabridged plan remains internal. |
| `provenance_manifest.json`, `CHANGELOG.json` | Hashes of public bytes, core byte identity and narrowly scoped packaging changes; private-original fingerprints excluded. |
| `run_local.py`, `verify_package.py` | Explicit internal execution launcher and data-free integrity/syntax checks. |

The four core Python modules are byte-identical to the final frozen implementation and to the v2 source copies. The CABG and renal JSONs are projections: every field read by the engine has exactly the same value, type and order, while observational annotations and unused metadata are omitted. The denominator extractor replaces one historical observed-N assertion with source-label and internal-N consistency checks. This does not alter its extraction or suppression arithmetic. The source originals and v3 are preserved.

The historical freeze was exploratory and included implementation corrections after initial results had been viewed. It is not a prospective preregistration. The manifest establishes code provenance, not external validity or a successful new execution.

## Runtime

The original final analysis recorded Python 3.14.6, DuckDB 2.0.0 and NumPy 2.5.5. The prior README incorrectly stated Python 3.14.0; rc2 corrects that documentation without changing code or results. R verification requires base R only. Python and R package upgrades can affect reproducibility; preserve the recorded versions when reproducing the frozen results. The clinical engines do not require matplotlib. The separate enclosing r3 reporting script `../scripts/plot_figures_r3.py` has its own figure-rendering requirements; consult that script before recreating figures. Use a separate environment outside both the restricted data tree and this code bundle. Installation is a separate administrator/user action; none of the supplied scripts downloads data, packages or credentials.

Example environment preparation in PowerShell, after selecting your own local environment location:

```powershell
python -m venv $env:AKI_VENV
& "$env:AKI_VENV/Scripts/python.exe" -m pip install -r ./requirements.txt
```

Use ordinary Python execution: do not use `-O`, `-OO` or `PYTHONOPTIMIZE`, because the original engines use assertion checks. Set `AKI_PYTHON` to the environment's Python executable. Set `AKI_DUCKDB_DIR` and `AKI_NUMPY_DIR` to the directory containing their installed package folders (usually the same environment's `Lib/site-packages`). Set `AKI_RSCRIPT` to your existing Rscript executable. Set the source and output environment variables below to actual local paths; no guessed data directory is embedded in this package.

First, run the data-free check from this package directory:

```powershell
& $env:AKI_PYTHON -X utf8 ./verify_package.py
& $env:AKI_PYTHON -X utf8 ./run_local.py --help
```

## Authorized local execution

Each `AKI_*_RUN` variable must name a **new, nonexistent internal directory**, disjoint from the code bundle and raw-data tree. The launcher copies the engine and rules there, captures all console output there and redirects even the flow auditor's historical side-effect file away from the code package. A failed run is retained for internal diagnosis; choose a new directory for the next attempt.

The scripts discover `.csv`, `.tsv`, `.csv.gz` and `.tsv.gz` files recursively. Duplicate table basenames are treated as ambiguous. Required fields and key uniqueness are checked before querying. Missing/ambiguous source tables or fields stop execution; they are not synthesized. Do not place multiple releases under one source root. DuckDB is in memory, has one thread and no automatic extension loading; temporary disk spilling is disabled. Large input files are hashed, so a full run can be slow and memory intensive. This package does not support a remote database or cloud query service.

Reproduce a formal source analysis only if you are authorized to do so:

```powershell
& $env:AKI_PYTHON -X utf8 ./run_local.py formal --source mimic `
  --root $env:MIMIC_ROOT --internal-run $env:AKI_MIMIC_RUN `
  --dependency-dir $env:AKI_DUCKDB_DIR --stats-dependency-dir $env:AKI_NUMPY_DIR `
  --authorized-local-data

& $env:AKI_PYTHON -X utf8 ./run_local.py formal --source eicu `
  --root $env:EICU_ROOT --internal-run $env:AKI_EICU_RUN `
  --dependency-dir $env:AKI_DUCKDB_DIR --stats-dependency-dir $env:AKI_NUMPY_DIR `
  --authorized-local-data
```

Set `AKI_MIMIC_FORMAL`/`AKI_EICU_FORMAL` to the relevant internal `results/formal_analysis.json` files. Previously retained final analyses can be used for aggregate-only work if their provenance is independently verified. Reconstruct a source's grouped screening flow without recalculating creatinine outcomes or bootstrap estimates:

```powershell
& $env:AKI_PYTHON -X utf8 ./run_local.py flow --source mimic `
  --root $env:MIMIC_ROOT --internal-run $env:AKI_MIMIC_FLOW_RUN `
  --previous-result $env:AKI_MIMIC_FORMAL --dependency-dir $env:AKI_DUCKDB_DIR `
  --authorized-local-data
```

For eICU, use `--source eicu`, `EICU_ROOT`, `AKI_EICU_FORMAL` and a separate new flow-run directory. The flow auditor verifies source hashes and selected sets against the given formal analysis; a mismatch stops the run. Its grouping and suppression are historical internal outputs, not the current r3 release decision. Any selected new output needs an object-specific whole-package review before external dissemination.

Recover variable denominators from existing aggregates and independently check point estimates:

```powershell
& $env:AKI_PYTHON -X utf8 ./run_local.py denominators `
  --mimic $env:AKI_MIMIC_FORMAL --eicu $env:AKI_EICU_FORMAL `
  --internal-run $env:AKI_DENOMINATOR_RUN --authorized-local-data

& $env:AKI_PYTHON -X utf8 ./run_local.py points `
  --mimic $env:AKI_MIMIC_FORMAL --eicu $env:AKI_EICU_FORMAL `
  --rscript $env:AKI_RSCRIPT --internal-run $env:AKI_POINTCHECK_RUN `
  --authorized-local-data
```

The R routine checks aggregate feasibility, rates, the D=R+O+P identity and point estimates. It does **not** validate patient-level classification, database mappings or confidence intervals; it does not rerun the bootstrap. It deliberately handles zero denominators as undefined rather than zero.

## Internal outputs and release boundaries

All run outputs are internal, including filenames or dictionary keys containing `public`, `conservative_public_view` or `PASS`. Historical single-file suppression does not establish safety when combined with other tables, exact percentages, intervals, figures or prior releases. The launcher does not authorize a public release. Internal formal files contain full exact aggregates, source paths/hashes and sparse strata; no such files are distributed here. Do not copy runtime directories, logs, source data, credentials or full matrices into a repository or submission supplement.

Method code and exact clinical selectors are supplied without observed rare-cell answers. Structural zeros required by the frozen comparison logic and thresholds such as 0.3 mg/dL, 1.5, 48/168 hours, the random seed, and minimum-display rules are algorithmic constants, not disclosed observed counts. The enclosing r3 candidate separately selects exact primary aggregates and existing descriptive SMDs for reporting. The old project suppression threshold is not a universal provider rule. This legacy launcher is not the exporter or public checker for `../aggregate_data/aggregate_core_r3.json`; that selected schema is checked by `../scripts/check_exact_aggregates_r3.py`. Institutional release approval is not inferred from either review.

## Checks completed and checks still needed

`code_audit_v4.json` records static compilation, JSON parsing, source identity, rule-projection equality, file inventory and disclosure-oriented code inspection. No synthetic clinical dataset was generated. No original datasets were opened, no cohort was recomputed, no bootstrap was rerun, and no clinical numerical validation was added by packaging. Credentialed end-to-end execution and independent external scientific reproduction remain separate from the confirmed author approval and AI responsibility. See the current enclosing release record for actual access and confirmed attribution.


## Public preparation update

This separate GitHub/Zenodo candidate removes private-original protocol/rule fingerprints and updates provenance wording and integrity manifests. All eight engine files and both executable rule projections remain byte-identical to the preceding candidate. The enclosing r3 reporting layer replaces the former coarse-only exports with selected existing exact primary aggregates and SMD summaries; those reporting files are versioned separately. The implementation record is now a reviewed metadata extract, not a byte-identical original. No algorithm, selector, underlying estimate or historical chronology was changed by these documentation edits; selected existing results are now reported at their retained precision outside this code directory. Manuscript approval and project-owned-content licence choices are confirmed. The representative confirmed software attribution and source-specific conditions; see ../AUTHORS.txt. Actual access is established separately by release records.

## r3 review boundaries

The enclosing rc2 candidate supplies exact primary sufficient counts for direct point-arithmetic checks. Do not pass its selected JSON to the legacy `run_local.py points` or `denominators` stages; these require complete, provenance-verified internal formal outputs. Historical R verification is not a new R run for r3. For any later authorized check, compare the R output with the formal result actually supplied, using a documented numerical tolerance and investigation of discrepancies.

The original percentile limits are supplied as reported results. Public point counts alone cannot regenerate clustered resampling, and neither the historical base-R point check nor a JSON consistency test validates confidence intervals. No full clinical/CI rerun occurred during this revision; external independent source-classification/CI execution has not been completed. An authorized source-data rerun or lawful cluster-input review is a separate scientific task.

`code_audit_v4.json` remains a historical packaging record, not a newly executed r3 audit. Historical protocol extracts and their hashes describe that earlier record. Current rc6 integrity and included-aggregate checks are performed by the outer review tools after final assembly; no historical PASS should be presented as a new result.


## r4 status clarification

See ../REPORTING_AND_REVIEW_STATUS.md for the inherited post-analysis numerical scope, actual code access in the release record, unresolved retained-output review arrangements and finite-bootstrap ordering limits. No clinical analysis, bootstrap or R run was performed for r4.

