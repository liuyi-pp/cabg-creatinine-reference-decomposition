# Mapping from methods to executable implementation

The active final entry point is `audit_round5.py`. The round-2/round-3 classes are imported dependencies and legacy bridges, not separate primary analyses. Their older contract wording must be read in that role: the final analysis uses the round-5 chronic-evidence exclusion and valid MIMIC death cap. No new clinical rule is introduced by the original v4 packaging or the separate r3/rc2 documentation and reporting update.

| Method | Implementation and selectors |
|---|---|
| Source discovery | `Audit.__init__` in `audit_round2.py`: recursive CSV/TSV discovery, exact table basename ambiguity checks, actual headers, string-preserving input and explicit SQL casts. `Round3.table` verifies every required field, including subsequent calls on an already bound table. |
| MIMIC cohort | `Audit.mimic` creates first ICU stay per hospital admission, adult and valid overlap bounds. `Round3.reviewed_cohort` uses exact code/version/title triples in `rules/cabg_review.json`; the qualifying CABG date is ICU-entry day or preceding calendar day, with exactly one distinct qualifying date in that window. It does not establish surgery-end time. |
| eICU cohort | `Audit.eicu`: recorded `unitvisitnumber=1`, adult rule including `>89`, nonmissing keys and valid offsets. `Round3.reviewed_cohort`: OR/Recovery Room/PACU source and exact reviewed CABG admission-diagnosis paths. All included paths and subgroup labels are supplied in `rules/cabg_review.json`. |
| Chronic renal evidence | `Round3.renal_flags`; all consumed codes, exact labels and history path/value pairs are supplied in `rules/renal_rules.json`. MIMIC prior admissions require discharge before index admission; index codes are retrospective. eICU history and ESRD diagnosis are source-specific. Negative documentation flags do not prove absence of chronic disease. |
| RRT | Exact procedure item IDs plus labels for MIMIC; exact treatment strings and APACHE dialysis flag for eICU, all visible in rules/code. Documentation is not a treatment-start timestamp. RRT is a sensitivity stratum, not automatic KDIGO stage 3 or a new exclusion of post-entry treatment. |
| Creatinine mapping | `Audit.creatinine`: MIMIC exact normalized dictionary label `creatinine` with fluid `blood`, `serum` or `plasma`, then actual discovered item IDs; eICU exact normalized `labname=creatinine`. No fixed unverified lab ID is inserted. |
| Units and values | Normalize whitespace/case and micro characters; use mg/dL unchanged, umol/L divided by 88.4, mg/L divided by 10. Require finite positive values and recognized nonconflicting units; no normal-range imputation or plausibility ceiling. |
| Time and observation | MIMIC specimen `charttime` is relative to ICU `intime`; `storetime` is an availability proxy. eICU `labresultoffset` is measured time and `labresultrevisedoffset` is revision time, not first availability. Observation is same admission, pre-entry up to 168 hours and post-entry [0,168 hours), capped at unit exit/hospital discharge and valid precise MIMIC death time. eICU death time is not inferred. |
| Duplicate/conflicting specimens | `Round3.screen`: exact integer-second verification; mg/dL decimal precision; identical same-time values collapsed; conflicting same-time values removed for that timepoint without discarding all other observations of the stay. |
| References and thresholds | `make_record`: A is latest valid pre-entry value in [-48h,0); B is minimum in [-168h,0), latest timestamp for tied minima. Each actual post/reference comparison uses 0<dt<=48h for an absolute rise >=0.3 and 0<dt<=168h for a ratio >=1.5. Decimal threshold arithmetic; no same-time self-comparison. |
| Common comparison set | Keys are `(actual post-entry timestamp, criterion type)`. C requires a nonempty intersection of A/B keys; it is not simply the intersection of individual evaluability flags. `sql_validate` independently constructs SQL DECIMAL pairs and checks classifications and comparison counts against Python. |
| Three-state denominator | A or B: recorded positive; evaluable with no positive observed; not evaluable. No positive observed is not clinical AKI absence. Undefined common outcomes remain null outside C. |
| Descriptive denominators | `baseline_descriptions` plus formal observation summaries; zero measurement count is observed, gap statistics can be undefined, and topcoded age is distinguished from ordinary missingness. `denominator_audit.extract` reconciles observed and unavailable counts across groups/complements. |

Let qA=YA/EA and qB=YB/EB; qAC and qBC are each strategy's own-key positive fractions among C; qAJ and qBJ use shared keys among C. `analysis_stats._estimate_vectors` calculates, in percentage points:

```
D = 100 * (qB - qA)
R = 100 * (qBJ - qAJ)
O = 100 * ((qBC - qBJ) - (qAC - qAJ))
P = 100 * ((qB - qBC) - (qA - qAC))
D = R + O + P
```

These are descriptive algebraic components, not causal effects or diagnostic accuracy. The frozen construction imposes R>=0 and O<=0; D and P have no fixed sign. The retained implementation is unchanged; this statement records the narrower interpretation adopted before v4.

`_cluster_design` and `_bootstrap` in `analysis_stats.py` implement 2,000 replicates with seed 20261115. MIMIC resamples whole persons. eICU resamples whole hospitals when persons are nested; if a person spans hospitals, independent hospital and person multinomial weights are multiplied on hospital-person cells. This is not within-hospital person resampling at every replicate. The hospital-specific supplementary analysis, when run, separately uses person clustering and a deterministic seed offset. Each overall replicate uses the same weights for all strategies/components. Intervals are 2.5/97.5 percentiles; they are withheld if more than 5% of replicates are undefined or fewer than two independent clusters are available. Small cluster counts are flagged. Undefined estimates remain undefined.

The R script re-expresses point estimates using rational aggregate-count formulas, checks logical count constraints and checks the algebraic identity. This independence is limited to point arithmetic; it cannot validate the upstream classification or resampling design.

No MIMIC/eICU/FinnGen/OpenGWAS linkage, MR analysis or GWAS model is part of this frozen CABG ascertainment analysis. Authentication or GWAS data are therefore neither required nor embedded here.

## r3 reporting and verification boundary

The eight engine files and two selector projections remain unchanged. The enclosing r3 candidate restores selected existing exact primary sufficient counts and descriptive/observation-process SMD summaries. Its exact aggregate checker verifies point arithmetic and reported-value consistency; it does not rerun clinical classification, recompute SMDs from records or regenerate percentile confidence limits. The latter require authorized cluster inputs or a full source-data rerun. No such rerun is claimed here. Historical suppression helpers describe old operational choices and do not constitute a universal data-provider threshold.
