"""Checksum and syntax checks only. Reads package files, never clinical datasets."""
from pathlib import Path
import hashlib,json,ast

root=Path(__file__).resolve().parent
manifest=json.loads((root/'package_checksums.json').read_text(encoding='utf-8'))
actual={str(p.relative_to(root)).replace('\\','/') for p in root.rglob('*') if p.is_file() and p.name!='package_checksums.json'}
assert actual==set(manifest['sha256']), 'Unexpected or missing package file'
for rel,digest in manifest['sha256'].items():
    p=root/rel
    assert hashlib.sha256(p.read_bytes()).hexdigest()==digest, 'Checksum mismatch: '+rel
    if p.suffix=='.py':
        code=p.read_text(encoding='utf-8-sig');ast.parse(code,filename=rel);compile(code,rel,'exec')
    elif p.suffix=='.json':json.loads(p.read_text(encoding='utf-8-sig'))
print('Package checksums, Python syntax and JSON parsing passed. No clinical execution performed.')
