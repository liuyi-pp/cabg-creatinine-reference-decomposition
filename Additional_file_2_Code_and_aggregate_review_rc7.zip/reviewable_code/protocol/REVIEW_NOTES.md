# Historical protocol materials: review status

Originally prepared 16 November 2026 for the independent v4 reporting candidate; explanatory notes updated for the separate r3/rc2 candidate. The dated plan followed exploratory aggregate inspection and the implementation corrections followed initial formal outputs. Neither document establishes prospective preregistration or an independently verified clock-time freeze.

`plan_2026-11-15_reviewed_extract.txt` is a **reviewed extract**, not the complete original plan. Three marked historical-frequency annotations were removed: paired candidate-stay/person frequencies, strict-boundary candidate totals, and an unrelated exploratory cohort's hospital frequency. Definitions and method settings remain visible. The full original is preserved internally; its fingerprint and exact source locations are retained only in the internal audit. The public review manifest describes the omitted categories without publishing the private-original fingerprint. The source text is in Chinese. No English translation of the entire historical plan is claimed.

`implementation_freeze.json` is a reviewed public metadata extract of the dated implementation record. Its four core Python hashes still identify the bundled core bytes. Original plan/rule fingerprints are omitted; hashes of the public rule projections replace the private rule commitments. The record preserves the outcome-informed timing, clarifications, corrections and execution history. It is not byte-identical to the private original. The internal audit retains that comparison.

The retained historical wording is not all current guidance. In particular:

- The plan's statement that all algebraic components may have either sign is corrected by the dated addendum: R>=0, O<=0; D and P have no fixed sign.
- The v4 disclosure policy was a project-specific conservative reporting choice. The separate r3 candidate restores selected existing full-cohort exact primary summaries and descriptive SMDs, following an object-level review. It does not alter the underlying analysis. Hospital/fine-state/nested-scenario details are not automatically cleared by the historical plan or by this new scope.
- The original implementation record's historical suppression wording is not a whole-package privacy guarantee. Every new output requires joint review and the applicable institutional/author decisions before external dissemination.
- Historical guideline-access notes describe the date on the plan; they are not presented as a new current-guideline check by this code-packaging task.

These materials make the evolution of the methods reviewable. They do not establish clinical diagnostic validity, unseen-data validation or a new end-to-end run. No source records, exact analysis results or public repository are supplied by this protocol folder.

The historical small-cell rule and hospital display thresholds are not asserted to be universal provider requirements. Historical source execution and R checks are not new runs for r3. The original final Python runtime is 3.14.6; the prior code README statement of 3.14.0 was a documentation error. No full clinical or exact-CI reproduction was performed by this documentation update.
