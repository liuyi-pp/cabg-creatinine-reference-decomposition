"""Explicit local execution in a new INTERNAL directory; no downloads or publication.

All original engine output, including legacy files named 'public', is quarantined.
The clinical engines are deliberately not executed during v4 package preparation.
"""
from pathlib import Path
import argparse, hashlib, json, os, shutil, subprocess, sys
from datetime import datetime, timezone

PACKAGE=Path(__file__).resolve().parent

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def local_existing(text, directory=False):
    if '://' in text or text.startswith(('\\\\','//')):
        raise ValueError('Use a local authorized filesystem path, not a URL or network share.')
    p=Path(text).expanduser().resolve(strict=True)
    if directory and not p.is_dir(): raise ValueError('Expected a directory.')
    if not directory and not p.is_file(): raise ValueError('Expected a file.')
    return p

def verify_package():
    manifest=json.loads((PACKAGE/'package_checksums.json').read_text(encoding='utf-8'))
    for rel,digest in manifest['sha256'].items():
        p=(PACKAGE/rel).resolve(strict=True)
        if PACKAGE not in p.parents or not p.is_file() or sha(p)!=digest:
            raise ValueError('Package checksum validation failed.')

def args():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage',choices=['formal','flow','denominators','points'])
    p.add_argument('--internal-run',required=True,help='New directory outside both this package and clinical input trees.')
    p.add_argument('--authorized-local-data',action='store_true',help='Assert your own authorization for every specified local input.')
    p.add_argument('--source',choices=['mimic','eicu'])
    p.add_argument('--root',help='Authorized local CSV/TSV source root; formal or flow only.')
    p.add_argument('--dependency-dir',help='Directory containing DuckDB; formal or flow only.')
    p.add_argument('--stats-dependency-dir',help='Directory containing NumPy; formal only.')
    p.add_argument('--previous-result',help='Internal formal_analysis.json from the same source files; flow only.')
    p.add_argument('--mimic',help='Internal MIMIC formal_analysis.json; denominators or points.')
    p.add_argument('--eicu',help='Internal eICU formal_analysis.json; denominators or points.')
    p.add_argument('--rscript',help='Existing Rscript executable; points only.')
    p.add_argument('--memory-limit',default='4GB')
    p.add_argument('--replicates',type=int,default=2000)
    a=p.parse_args()
    if not a.authorized_local_data:p.error('Explicit local authorization assertion is required.')
    if sys.flags.optimize:p.error('Run without -O or PYTHONOPTIMIZE: engine validation uses assertions.')
    needed={'formal':['source','root','dependency_dir','stats_dependency_dir'],
            'flow':['source','root','dependency_dir','previous_result'],
            'denominators':['mimic','eicu'], 'points':['mimic','eicu','rscript']}[a.stage]
    for k in needed:
        if not getattr(a,k):p.error('Missing --'+k.replace('_','-')+' for '+a.stage)
    if a.stage=='formal' and a.replicates!=2000:p.error('Frozen reproduction uses exactly 2000 replicates. A changed setting is a separate analysis.')
    return a

def main():
    a=args(); verify_package()
    pths={}
    for name in ['root','dependency_dir','stats_dependency_dir','previous_result','mimic','eicu','rscript']:
        value=getattr(a,name)
        if value:pths[name]=local_existing(value,name in ['root','dependency_dir','stats_dependency_dir'])
    rawout=a.internal_run
    if '://' in rawout or rawout.startswith(('\\\\','//')):raise ValueError('Output must be local.')
    run=Path(rawout).expanduser().resolve()
    if run.exists():raise ValueError('Internal-run directory must not already exist.')
    if run==PACKAGE or PACKAGE in run.parents or run in PACKAGE.parents:
        raise ValueError('Output must be disjoint from the reviewable package.')
    if 'root' in pths:
        root=pths['root']
        if run==root or root in run.parents or run in root.parents:
            raise ValueError('Output must be disjoint from the clinical input tree.')
    for p in pths.values():
        if p==run or run in p.parents:raise ValueError('Output cannot contain an input or dependency.')
    run.mkdir(parents=True)
    (run/'INTERNAL_DO_NOT_RELEASE.txt').write_text(
        'All files here are restricted internal outputs, including legacy files named public.\n'
        'Exact aggregates, local paths, source hashes and small cells may be present.\n'
        'Do not combine with a publication bundle without a fresh joint disclosure review.\n',encoding='utf-8')
    runtime=run/'runtime_engine';shutil.copytree(PACKAGE/'engine',runtime)
    for p in (PACKAGE/'rules').iterdir():
        if p.is_file():shutil.copyfile(p,runtime/p.name)
    results=run/'results'
    py=[sys.executable,'-X','utf8']
    if a.stage=='formal':
        commands=[py+[str(runtime/'audit_round5.py'),'--source',a.source,'--root',str(pths['root']),
             '--out',str(results),'--dependency-dir',str(pths['dependency_dir']),
             '--stats-dependency-dir',str(pths['stats_dependency_dir']),
             '--memory-limit',a.memory_limit,'--replicates','2000','--authorized-local-data']]
    elif a.stage=='flow':
        commands=[py+[str(runtime/'flow_audit.py'),'--source',a.source,'--root',str(pths['root']),
             '--out',str(results),'--dependency-dir',str(pths['dependency_dir']),'--frozen-dir',str(runtime),
             '--previous-result',str(pths['previous_result']),'--memory-limit',a.memory_limit,'--authorized-local-data']]
    elif a.stage=='denominators':
        commands=[py+[str(runtime/'denominator_audit.py'),'--mimic',str(pths['mimic']),
             '--eicu',str(pths['eicu']),'--out',str(results)]]
    else:
        results.mkdir()
        commands=[py+[str(runtime/'extract_aggregate_counts.py'),'--inputs',str(pths['mimic']),str(pths['eicu']),
                  '--out',str(results/'aggregate_counts_INTERNAL.csv')],
             [str(pths['rscript']),str(runtime/'verify_points.R'),str(results/'aggregate_counts_INTERNAL.csv'),
                  str(results/'verified_points_INTERNAL.csv')]]
    record={'created_utc':datetime.now(timezone.utc).isoformat(),'stage':a.stage,'status':'RUNNING',
       'scope':'Authorized internal execution; not an approved publication export.',
       'commands':commands,'package_manifest_sha256':sha(PACKAGE/'package_checksums.json'),
       'python':sys.version,'raw_inputs_modified_by_launcher':False,'network_calls_by_launcher':False}
    logpath=run/'execution_record_INTERNAL.json'
    def save():logpath.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    save();env=dict(os.environ);env.pop('PYTHONOPTIMIZE',None);env['PYTHONDONTWRITEBYTECODE']='1'
    for i,cmd in enumerate(commands,1):
        with (run/f'command_{i}_INTERNAL.log').open('w',encoding='utf-8') as log:
            completed=subprocess.run(cmd,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
        if completed.returncode:
            record.update(status='FAILED',failed_command=i,returncode=completed.returncode);save()
            print('Execution failed; restricted diagnostics are retained inside the internal-run directory.')
            return completed.returncode
    record.update(status='COMPLETED',finished_utc=datetime.now(timezone.utc).isoformat());save()
    print('Internal execution completed. No output has been approved for external release.')
    return 0

if __name__=='__main__':
    try:raise SystemExit(main())
    except (ValueError,FileNotFoundError,PermissionError) as exc:
        print('Launcher validation failed: '+str(exc),file=sys.stderr);raise SystemExit(2)
