"""Aggregate inference for the frozen CABG ascertainment protocol.

No raw-file, database, network, or export functions are provided. The caller
supplies authorized, already-derived records in memory. Returned values contain
aggregates only. NumPy must be available on the caller's import path.

Rates are proportions; D/R/O/P and delta_eval are PERCENTAGE POINTS.
All bootstrap estimates use the same resampling weights within a replicate.
Hospital summaries are internal aggregates; publication requires the supplied
conservative suppression view AND review against other released totals.
"""

from __future__ import annotations

import math
from collections import Counter, defaultdict
from typing import Any

import numpy as np


VERSION = "1.0.0"
VECTOR_NAMES = (
    "N", "EA", "EB", "C", "YA", "YB", "YA_own_in_C",
    "YB_own_in_C", "YAJ", "YBJ", "refA", "refB",
)
RATE_NAMES = (
    "eval_A", "eval_B", "common", "reference_A", "reference_B",
    "positive_among_evaluable_A", "positive_among_evaluable_B",
    "recorded_positive_fraction_N_A", "recorded_positive_fraction_N_B",
    "not_evaluable_fraction_N_A", "not_evaluable_fraction_N_B",
    "no_positive_observed_fraction_N_A", "no_positive_observed_fraction_N_B",
    "positive_own_in_C_A", "positive_own_in_C_B",
    "positive_common_comparisons_A", "positive_common_comparisons_B",
)
CONTRAST_NAMES = ("D", "R", "O", "P", "delta_eval")
METRIC_NAMES = RATE_NAMES + CONTRAST_NAMES
REQUIRED = (
    "stay", "person", "hospital", "EA", "EB", "C", "YA", "YB",
    "YAJ", "YBJ", "refA", "refB",
)
BOOL_KEYS = ("EA", "EB", "C", "YA", "YB", "refA", "refB")


def _boolean(value: Any) -> bool:
    """Accept actual booleans and integer 0/1, never strings or missing."""
    if isinstance(value, (bool, np.bool_)):
        return bool(value)
    if isinstance(value, (int, np.integer)) and value in (0, 1):
        return bool(value)
    raise ValueError("A required indicator is not a boolean or integer 0/1")


def _missing(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, str):
        return value.strip().lower() in ("", "na", "nan", "null", "none", "unknown")
    try:
        return not math.isfinite(float(value))
    except (TypeError, ValueError):
        return False


def _number(value: Any) -> float | None:
    if _missing(value) or isinstance(value, bool):
        return None
    try:
        number = float(value)
        return number if math.isfinite(number) else None
    except (TypeError, ValueError):
        return None


def _key(value: Any) -> str:
    # Canonical key creation is internal only; no identifier values are emitted.
    return str(value)


def validate_rows(rows: list[dict], source: str) -> dict:
    """Fail on invalid derived records without including patient identifiers."""
    if source not in ("mimic", "eicu"):
        raise ValueError("source must be 'mimic' or 'eicu'")
    seen = set()
    for row in rows:
        if any(key not in row for key in REQUIRED):
            raise ValueError("Derived row is missing required analysis columns")
        if _missing(row["stay"]) or _missing(row["person"]):
            raise ValueError("Missing stay/person identifier prevents valid clustering")
        if source == "eicu" and _missing(row["hospital"]):
            raise ValueError("Missing eICU hospital identifier; resolve or disclose before inference")
        stay = _key(row["stay"])
        if stay in seen:
            raise ValueError("Duplicate stay rows; one record per index ICU stay is required")
        seen.add(stay)
        flags = {key: _boolean(row[key]) for key in BOOL_KEYS}
        if flags["EA"] and not flags["refA"]:
            raise ValueError("EA requires an observed reference A")
        if flags["EB"] and not flags["refB"]:
            raise ValueError("EB requires an observed reference B")
        if flags["YA"] and not flags["EA"] or flags["YB"] and not flags["EB"]:
            raise ValueError("Observed positive must have a valid comparison")
        if flags["C"]:
            if not (flags["EA"] and flags["EB"]):
                raise ValueError("C must be a subset of EA intersection EB")
            yaj, ybj = _boolean(row["YAJ"]), _boolean(row["YBJ"])
            if yaj and not ybj:
                raise ValueError("Common-comparison A-only positive violates reference ordering")
            if yaj and not flags["YA"] or ybj and not flags["YB"]:
                raise ValueError("On C, own comparisons must include common positives")
        elif row["YAJ"] is not None or row["YBJ"] is not None:
            raise ValueError("YAJ/YBJ must be None outside C, not a negative label")
    return {
        "rows_checked": len(rows), "unique_stay_rows": True,
        "C_subset_EA_intersection_EB": True,
        "common_A_only_positive_zero": True,
        "own_ge_common_only_on_C": True,
        "undefined_common_outcomes_retained_outside_C": True,
        "reference_value_order": "not checked here: numeric reference values not supplied; caller must verify B<=A where both exist",
        "input_patients_written": False,
    }


def _row_vector(row: dict) -> np.ndarray:
    c = bool(row["C"])
    return np.asarray([
        1, row["EA"], row["EB"], c, row["YA"], row["YB"],
        c and row["YA"], c and row["YB"],
        bool(row["YAJ"]) if c else False,
        bool(row["YBJ"]) if c else False, row["refA"], row["refB"],
    ], dtype=np.float64)


def _matrix(rows: list[dict]) -> np.ndarray:
    if not rows:
        return np.zeros((0, len(VECTOR_NAMES)), dtype=np.float64)
    return np.stack([_row_vector(row) for row in rows])


def _divide(numerator: np.ndarray, denominator: np.ndarray) -> np.ndarray:
    result = np.full(np.broadcast_shapes(numerator.shape, denominator.shape), np.nan)
    return np.divide(numerator, denominator, out=result, where=denominator > 0)


def _estimate_vectors(totals: np.ndarray) -> np.ndarray:
    """Rows are resamples; returns rates then percentage-point contrasts."""
    totals = np.atleast_2d(totals)
    n, ea, eb, c, ya, yb, yac, ybc, yaj, ybj, ra, rb = totals.T
    qa, qb = _divide(ya, ea), _divide(yb, eb)
    qac, qbc = _divide(yac, c), _divide(ybc, c)
    qaj, qbj = _divide(yaj, c), _divide(ybj, c)
    d = qb - qa
    r = qbj - qaj
    o = (qbc - qbj) - (qac - qaj)
    p = (qb - qbc) - (qa - qac)
    rates = (
        _divide(ea, n), _divide(eb, n), _divide(c, n),
        _divide(ra, n), _divide(rb, n), qa, qb,
        _divide(ya, n), _divide(yb, n),
        _divide(n-ea, n), _divide(n-eb, n),
        _divide(ea-ya, n), _divide(eb-yb, n), qac, qbc, qaj, qbj,
    )
    return np.column_stack(rates + (
        100*d, 100*r, 100*o, 100*p, 100*_divide(eb-ea, n),
    ))


def _finite(value: Any) -> float | None:
    result = float(value)
    return result if math.isfinite(result) else None


def _counts(totals: np.ndarray) -> dict:
    result = {key: int(round(float(value))) for key, value in zip(VECTOR_NAMES, totals)}
    n, ea, eb, c = (result[key] for key in ("N", "EA", "EB", "C"))
    result["states_A"] = {"positive_recorded_criterion": result["YA"],
                          "no_positive_in_observed_comparisons": ea-result["YA"],
                          "not_evaluable": n-ea}
    result["states_B"] = {"positive_recorded_criterion": result["YB"],
                          "no_positive_in_observed_comparisons": eb-result["YB"],
                          "not_evaluable": n-eb}
    # A-only cannot occur after row-level validation of the frozen ordering.
    result["common_matrix"] = {"both_positive": result["YAJ"], "A_only": 0,
                               "B_only": result["YBJ"]-result["YAJ"],
                               "neither_positive_in_J": c-result["YBJ"]}
    return result


def _groups(values: list[Any]) -> tuple[np.ndarray, int]:
    lookup = {}
    ids = np.empty(len(values), dtype=np.int64)
    for index, value in enumerate(values):
        key = _key(value)
        if key not in lookup:
            lookup[key] = len(lookup)
        ids[index] = lookup[key]
    return ids, len(lookup)


def _aggregate(matrix: np.ndarray, indices: np.ndarray, n_groups: int) -> np.ndarray:
    sums = np.zeros((n_groups, matrix.shape[1]), dtype=np.float64)
    np.add.at(sums, indices, matrix)
    return sums


def _cluster_design(rows: list[dict], matrix: np.ndarray, source: str,
                    force_person: bool = False) -> dict:
    persons, nperson = _groups([row["person"] for row in rows])
    if source == "mimic" or force_person:
        return {"method": "whole_person", "matrix": _aggregate(matrix, persons, nperson),
                "cluster_count": nperson, "person_count": nperson,
                "hospital_count": 1 if rows else 0, "cross_hospital_person_count": 0}
    hospitals, nhospital = _groups([row["hospital"] for row in rows])
    memberships = defaultdict(set)
    for p, h in zip(persons, hospitals):
        memberships[int(p)].add(int(h))
    cross = sum(len(group) > 1 for group in memberships.values())
    if not cross:
        return {"method": "whole_hospital_person_nested", "matrix": _aggregate(matrix, hospitals, nhospital),
                "cluster_count": nhospital, "person_count": nperson,
                "hospital_count": nhospital, "cross_hospital_person_count": 0}
    pairs = {}
    edge_ids = np.empty(len(rows), dtype=np.int64)
    edge_h, edge_p = [], []
    for index, (h, p) in enumerate(zip(hospitals, persons)):
        pair = (int(h), int(p))
        if pair not in pairs:
            pairs[pair] = len(pairs)
            edge_h.append(int(h)); edge_p.append(int(p))
        edge_ids[index] = pairs[pair]
    return {"method": "hospital_by_person_product_weights", "matrix": _aggregate(matrix, edge_ids, len(pairs)),
            "edge_h": np.asarray(edge_h), "edge_p": np.asarray(edge_p),
            "cluster_count": min(nhospital, nperson), "person_count": nperson,
            "hospital_count": nhospital, "cross_hospital_person_count": cross,
            "interpretation": "pigeonhole-style independent cluster weight product; may be conservative"}


def _bootstrap(rows: list[dict], matrix: np.ndarray, source: str,
               replicates: int, seed: int, force_person: bool = False) -> tuple[dict, dict]:
    if not isinstance(replicates, int) or replicates < 0:
        raise ValueError("replicates must be a nonnegative integer")
    design = _cluster_design(rows, matrix, source, force_person=force_person)
    info = {key: value for key, value in design.items() if key not in ("matrix", "edge_h", "edge_p")}
    info.update({"replicates": replicates, "seed": seed, "backend": "numpy",
                 "numpy_version": np.__version__, "interval_method": "percentile_2.5_97.5",
                 "same_weights_all_strategies_and_subsets": True,
                 "max_na_fraction_for_reportable_interval": 0.05})
    intervals = {}
    draws = np.full((replicates, len(METRIC_NAMES)), np.nan, dtype=np.float64)
    if rows and replicates:
        rng = np.random.default_rng(seed)
        cluster_count = design["cluster_count"]
        for start in range(0, replicates, 100):
            batch = min(100, replicates-start)
            if design["method"] == "hospital_by_person_product_weights":
                nh, nperson = design["hospital_count"], design["person_count"]
                hw = rng.multinomial(nh, np.full(nh, 1/nh), size=batch)
                pw = rng.multinomial(nperson, np.full(nperson, 1/nperson), size=batch)
                weights = hw[:, design["edge_h"]] * pw[:, design["edge_p"]]
            else:
                weights = rng.multinomial(cluster_count, np.full(cluster_count, 1/cluster_count), size=batch)
            totals = weights.astype(np.float64) @ design["matrix"]
            draws[start:start+batch] = _estimate_vectors(totals)
    d_index = METRIC_NAMES.index("D")
    residual = draws[:, d_index] - draws[:, d_index+1:d_index+4].sum(axis=1)
    finite_residual = residual[np.isfinite(residual)]
    max_residual = float(np.max(np.abs(finite_residual))) if finite_residual.size else None
    # Reported contrasts are percentage points, so this enforces the stricter
    # 1e-10 probability-scale protocol tolerance by two orders of magnitude.
    if max_residual is not None and max_residual > 1e-10:
        raise ArithmeticError("Bootstrap decomposition identity failed")
    info["maximum_absolute_identity_error_percentage_points"] = max_residual
    for index, name in enumerate(METRIC_NAMES):
        values = draws[:, index]
        finite = values[np.isfinite(values)]
        na_count = replicates-len(finite)
        # Direct missing-count division preserves the exact 5% boundary;
        # 1 - valid/reps can round 0.05 upward through cancellation.
        na_fraction = na_count/replicates if replicates else None
        enough_clusters = design["cluster_count"] >= 2
        reportable = bool(replicates and finite.size and na_fraction <= .05 and enough_clusters)
        limits = np.quantile(finite, [.025, .975]) if reportable else [None, None]
        intervals[name] = {
            "lower": _finite(limits[0]) if limits[0] is not None else None,
            "upper": _finite(limits[1]) if limits[1] is not None else None,
            "na_fraction": _finite(na_fraction) if na_fraction is not None else None,
            "valid_replicates": int(len(finite)), "reportable": reportable,
            "NA_replicates": int(na_count),
            "unit": "percentage_points" if name in CONTRAST_NAMES else "proportion",
            "caution_few_independent_clusters": design["cluster_count"] < 20,
        }
    return intervals, info


def _summarize(rows: list[dict], source: str, replicates: int, seed: int,
               force_person: bool = False) -> dict:
    matrix = _matrix(rows)
    totals = matrix.sum(axis=0)
    estimates = _estimate_vectors(totals)[0]
    rates = {name: _finite(estimates[index]) for index, name in enumerate(RATE_NAMES)}
    contrasts = {name: _finite(estimates[len(RATE_NAMES)+index]) for index, name in enumerate(CONTRAST_NAMES)}
    finite = all(contrasts[key] is not None for key in ("D", "R", "O", "P"))
    identity_error = (contrasts["D"] - contrasts["R"] - contrasts["O"] - contrasts["P"]) if finite else None
    if identity_error is not None and abs(identity_error) > 1e-10:
        raise ArithmeticError("Point-estimate decomposition identity failed")
    intervals, bootstrap = _bootstrap(rows, matrix, source, replicates, seed, force_person)
    reasons = {}
    for s in ("A", "B"):
        reasons[s] = dict(sorted(Counter(str(row.get("no_reason"+s) or "reason_not_supplied")
                                        for row in rows if not row["E"+s]).items()))
    return {"counts": _counts(totals), "rates": rates,
            "contrasts_percentage_points": contrasts, "confidence_intervals": intervals,
            "not_evaluable_reasons": reasons,
            "bootstrap": bootstrap, "identity_error_percentage_points": identity_error}


def _continuous(values: list[Any]) -> dict:
    usable = [_number(value) for value in values]
    nums = np.asarray([value for value in usable if value is not None], dtype=float)
    count = len(nums)
    q = np.quantile(nums, [.25, .5, .75]) if count else [None]*3
    return {"n_total": len(values), "n_observed": count, "n_missing_or_nonnumeric": len(values)-count,
            "mean": float(np.mean(nums)) if count else None,
            "sd": float(np.std(nums, ddof=1)) if count > 1 else None,
            "q1": _finite(q[0]) if count else None,
            "median": _finite(q[1]) if count else None,
            "q3": _finite(q[2]) if count else None}


def _continuous_smd(a: dict, b: dict) -> float | None:
    if a["mean"] is None or b["mean"] is None or a["sd"] is None or b["sd"] is None:
        return None
    denominator = math.sqrt((a["sd"]**2+b["sd"]**2)/2)
    if denominator == 0:
        return 0.0 if a["mean"] == b["mean"] else None
    return (a["mean"]-b["mean"])/denominator


def _age_category(value: Any) -> str:
    if isinstance(value, str) and value.strip().replace(" ", "") in (">89", ">=90", "90+"):
        return ">=80"
    age = _number(value)
    if age is None:
        return "unknown"
    if age < 18:
        return "below18_requires_review"
    return "18-64" if age < 65 else "65-79" if age < 80 else ">=80"


def _category(value: Any) -> str:
    return "unknown" if _missing(value) else str(value).strip()


def _row_age_group(row: dict) -> str:
    """Use caller's validated privacy-aware age category when supplied."""
    if "age_group" in row:
        value = row["age_group"]
        return "unknown" if _missing(value) else str(value)
    return _age_category(row.get("age"))


def _age_recording(row: dict) -> str:
    value = row.get("age")
    if bool(row.get("age_topcoded", False)):
        return "privacy_topcoded"
    if _age_category(value) == ">=80" and _number(value) is None:
        return "privacy_topcoded"
    if _missing(value):
        return "missing"
    return "numeric" if _number(value) is not None else "unrecognized"


def _categorical(a: list[Any], b: list[Any]) -> dict:
    ca, cb = Counter(a), Counter(b)
    result = {}
    for category in sorted(set(ca)|set(cb)):
        pa = ca[category]/len(a) if a else None
        pb = cb[category]/len(b) if b else None
        smd = None
        if pa is not None and pb is not None:
            denominator = math.sqrt((pa*(1-pa)+pb*(1-pb))/2)
            smd = (pa-pb)/denominator if denominator else (0.0 if pa == pb else None)
        result[category] = {"selected_n": ca[category], "other_n": cb[category],
                            "selected_proportion": pa, "other_proportion": pb,
                            "signed_SMD": smd}
    return result


def baseline_descriptions(rows: list[dict], groups: tuple[str, ...] = ("EA", "EB", "C")) -> dict:
    """Observed baseline and observation-process descriptions; no imputation.

    Signed SMD is selected minus other. Continuous SMD uses sample SDs and
    unweighted mean of the two group variances. Categorical SMD is one-vs-rest.
    Counts here are INTERNAL; do not directly publish small descriptive cells.
    """
    output = {}
    for group in groups:
        if group not in ("EA", "EB", "C"):
            raise ValueError("Description groups are EA, EB, or C")
        selected = [row for row in rows if row[group]]
        other = [row for row in rows if not row[group]]
        continuous = {}
        for variable in ("age", "admit_lag", "post_count", "last_gap_h"):
            a = _continuous([row.get(variable) for row in selected])
            b = _continuous([row.get(variable) for row in other])
            continuous[variable] = {"selected": a, "other": b, "signed_SMD": _continuous_smd(a,b),
                                    "role": "observation_process" if variable in ("post_count", "last_gap_h") else "baseline_description"}
        categorical = {
            "age_group": _categorical([_row_age_group(row) for row in selected],
                                      [_row_age_group(row) for row in other]),
            "sex": _categorical([_category(row.get("sex")) for row in selected],
                                [_category(row.get("sex")) for row in other]),
            "pre_state": _categorical([_category(row.get("pre_state")) for row in selected],
                                      [_category(row.get("pre_state")) for row in other]),
        }
        # Known top-coded ages are not missing, but are excluded from continuous
        # numerical summaries. Expose that distinction as a separate category.
        categorical["age_recording"] = _categorical(
            [_age_recording(row) for row in selected],
            [_age_recording(row) for row in other],
        )
        output[group] = {"selected_n": len(selected), "other_n": len(other),
                         "continuous": continuous, "categorical": categorical}
    return {"groups": output, "publication_status": "internal_unsuppressed_aggregates",
            "age_topcoding": "Caller-supplied age_group and age_topcoded take precedence; no exact age imputation or eligibility changes",
            "observation_variables_are_not_baseline_predictors": True}


def _atomic_minimum(rows: list[dict]) -> int | None:
    """Smallest nonzero joint cell of all released indicator/count dimensions."""
    fields = ("EA", "EB", "C", "YA", "YB", "YAJ", "YBJ", "refA", "refB")
    cells = Counter(tuple(row.get(key) for key in fields) for row in rows)
    return min(cells.values()) if cells else None


def suppress_hospital_cells(site_rows: list[dict], threshold: int = 10) -> dict:
    """Conservative whole-row suppression, with complementary row suppression.

    Uses PRIVATE joint-cell minima prepared by hospital_summary. A row is
    withheld if any underlying nonzero joint indicator cell is below threshold.
    At least two numerical site rows are withheld if any is withheld, to reduce
    reconstruction from all-site totals. Never returns the minima or hidden N.
    Other releases can still create disclosure routes: this is not a privacy
    guarantee and root must review the full set of released tables.
    """
    suppressed = {index for index, row in enumerate(site_rows)
                  if not row["display_eligible"] or row["_atomic_minimum"] is None
                  or row["_atomic_minimum"] < threshold}
    if len(suppressed) == 1 and len(site_rows) > 1:
        others = [index for index in range(len(site_rows)) if index not in suppressed]
        suppressed.add(min(others, key=lambda index: site_rows[index]["counts"]["N"]))
    output = []
    for index, row in enumerate(site_rows):
        if index in suppressed:
            output.append({"site_label": row["site_label"], "numeric_row_suppressed": True})
        else:
            output.append({key: value for key, value in row.items() if not key.startswith("_")})
    return {"rows": output, "suppressed_rows": len(suppressed),
            "rule": "whole-row suppression if any nonzero joint indicator cell<10 or site display ineligible; complementary suppression when exactly one row withheld",
            "cross_table_disclosure_review_required": True}


def hospital_summary(rows: list[dict], *, replicates: int = 0, seed: int = 20261115,
                     minimum_N: int = 30, minimum_C: int = 20) -> dict:
    """Internal eICU site aggregates; optional patient-cluster within-site CIs.

    Primary overall eICU CIs must use analyze(), not these within-site CIs.
    Site labels are local sequential labels; raw hospital identifiers are absent.
    """
    by_hospital = defaultdict(list)
    for row in rows:
        if _missing(row.get("hospital")):
            raise ValueError("Hospital summary requires nonmissing hospital identifiers")
        by_hospital[_key(row["hospital"])].append(row)
    output = []
    for index, key in enumerate(sorted(by_hospital)):
        members = by_hospital[key]
        n, c = len(members), sum(bool(row["C"]) for row in members)
        eligible = n >= minimum_N and c >= minimum_C
        summary = _summarize(members, "eicu", replicates if eligible else 0, seed+index, force_person=True)
        summary.update({"site_label": f"site_{index+1:03d}", "display_eligible": eligible,
                        "interval_scope": "exploratory_within_hospital_patient_cluster",
                        "_atomic_minimum": _atomic_minimum(members)})
        output.append(summary)
    def equal_hospital_summary(selected: list[dict]) -> dict:
        results = {}
        for key in ("eval_A", "eval_B", "common") + CONTRAST_NAMES:
            values = [(row["contrasts_percentage_points"] if key in CONTRAST_NAMES else row["rates"])[key]
                      for row in selected]
            observed = [value for value in values if value is not None]
            q = np.quantile(observed, [.25,.5,.75]) if observed else [None]*3
            results[key] = {"n_sites_defined": len(observed), "q1": _finite(q[0]) if observed else None,
                            "median": _finite(q[1]) if observed else None,
                            "q3": _finite(q[2]) if observed else None,
                            "unit": "percentage_points" if key in CONTRAST_NAMES else "proportion"}
        return results
    eligible = [row for row in output if row["display_eligible"]]
    return {"hospital_count": len(output), "display_eligible_count": len(eligible),
            "minimum_N": minimum_N, "minimum_C": minimum_C,
            "at_least_20_display_eligible_sites": len(eligible) >= 20,
            "equal_hospital_all_defined": equal_hospital_summary(output),
            "equal_hospital_display_eligible": equal_hospital_summary(eligible),
            "internal_unsuppressed_rows": output,
            "conservative_public_view": suppress_hospital_cells(output),
            "note": "Overall patient-weighted estimates are in analyze(); hospital medians/IQR target a different estimand. No hospital quality ranking."}


def analyze(rows: list[dict], source: str, replicates: int = 2000,
            seed: int = 20261115, *, include_details: bool = True) -> dict:
    """Main aggregate API. No patient identifiers or individual rows returned.

    include_details=False is intended for prespecified sensitivity analyses.
    Main details include baseline descriptions and site POINT ESTIMATES only.
    Request hospital_summary(..., replicates=2000) separately for within-site CIs.
    """
    validation = validate_rows(rows, source)
    result = _summarize(rows, source, replicates, seed)
    result.update({"analysis_stats_version": VERSION, "source": source,
                   "validation": validation, "rate_unit": "proportion",
                   "contrast_unit": "percentage_points", "internal_aggregate_only": True,
                   "uncertainty_scope": "Sampling variability under the frozen ascertainment rules; not unknown clinical truth or algorithm-selection uncertainty"})
    if include_details:
        result["baseline_descriptions"] = baseline_descriptions(rows)
        if source == "eicu":
            result["hospital_summary"] = hospital_summary(rows, replicates=0, seed=seed)
    return result
