# Independent base-R recalculation from aggregate sufficient-count CSV only.
# Usage: Rscript verify_points.R aggregate_counts.csv verified_points.csv
# Also accepts a leading --args. No patient-level or raw-source file is read.
# This checks aggregate feasibility and point estimates, not bootstrap coverage,
# patient-level outcome construction, or clinical diagnostic validity.

args <- commandArgs(trailingOnly = TRUE)
if (length(args) > 0L && identical(args[[1L]], "--args")) args <- args[-1L]
if (length(args) != 2L) stop("Usage: verify_points.R input_aggregate.csv output.csv", call. = FALSE)
input <- normalizePath(args[[1L]], winslash = "/", mustWork = TRUE)
output <- normalizePath(args[[2L]], winslash = "/", mustWork = FALSE)
if (identical(tolower(input), tolower(output))) stop("Input and output must differ", call. = FALSE)

d <- read.csv(input, stringsAsFactors = FALSE, check.names = FALSE,
              fileEncoding = "UTF-8-BOM", na.strings = c("NA", "", "null", "None"))
counts <- c("N", "EA", "EB", "C", "YA", "YB", "YA_own_in_C",
            "YB_own_in_C", "YAJ", "YBJ", "refA", "refB")
needed <- c("source", "scenario", counts)
if (anyDuplicated(names(d))) stop("Duplicate CSV column names", call. = FALSE)
if (!all(needed %in% names(d))) stop("Required aggregate columns are missing", call. = FALSE)
if (anyNA(d$source) || anyNA(d$scenario) || any(!nzchar(trimws(d$source))) ||
    any(!nzchar(trimws(d$scenario)))) stop("Missing source/scenario labels", call. = FALSE)
if (anyDuplicated(d[c("source", "scenario")] )) stop("Duplicate source/scenario rows", call. = FALSE)

for (nm in counts) {
  x <- suppressWarnings(as.numeric(d[[nm]]))
  if (anyNA(x) || any(!is.finite(x)) || any(x < 0) || any(x != floor(x)) ||
      any(x > 2^53)) stop(paste("Invalid nonnegative integer count column:", nm), call. = FALSE)
  d[[nm]] <- x
}

checks <- with(d, data.frame(
  EA_le_N = EA <= N,
  EB_le_N = EB <= N,
  C_le_both_evaluable = C <= EA & C <= EB,
  YA_le_EA = YA <= EA,
  YB_le_EB = YB <= EB,
  references_bound_evaluability = EA <= refA & EB <= refB & refA <= N & refB <= N,
  reference_availability_nested = refA <= refB,
  common_counts_within_C = YA_own_in_C <= C & YB_own_in_C <= C & YAJ <= C & YBJ <= C,
  common_own_counts_within_total = YA_own_in_C <= YA & YB_own_in_C <= YB,
  common_outcomes_within_own = YAJ <= YA_own_in_C & YBJ <= YB_own_in_C,
  common_direction_aggregate = YAJ <= YBJ,
  outside_C_positive_fits = YA - YA_own_in_C <= EA - C & YB - YB_own_in_C <= EB - C,
  stringsAsFactors = FALSE
))
if (nrow(checks) && any(!as.matrix(checks))) {
  bad <- which(!apply(checks, 1L, all))
  stop(paste("Aggregate logical constraint failed in CSV row(s):", paste(bad, collapse = ",")), call. = FALSE)
}

safe_ratio <- function(num, den) {
  answer <- rep(NA_real_, length(den))
  ok <- is.finite(num) & is.finite(den) & den > 0
  answer[ok] <- num[ok] / den[ok]
  answer
}

# These rational expressions deliberately differ from the Python sequence of
# differences of means. Outside-C contrasts avoid division by (EA-C)/(EB-C),
# which can legitimately be zero. Zero overall/common denominators remain NA.
with_counts <- function(d) {
  within(d, {
    D_pp <- 100 * safe_ratio(YB * EA - YA * EB, EA * EB)
    R_pp <- 100 * safe_ratio(YBJ - YAJ, C)
    O_pp <- 100 * safe_ratio((YB_own_in_C - YBJ) - (YA_own_in_C - YAJ), C)
    P_pp <- 100 * (safe_ratio(C * YB - EB * YB_own_in_C, EB * C) -
                  safe_ratio(C * YA - EA * YA_own_in_C, EA * C))
    delta_eval_pp <- 100 * safe_ratio(EB - EA, N)
    eval_A <- safe_ratio(EA, N)
    eval_B <- safe_ratio(EB, N)
    common_fraction_N <- safe_ratio(C, N)
    positive_among_evaluable_A <- safe_ratio(YA, EA)
    positive_among_evaluable_B <- safe_ratio(YB, EB)
    unknown_A <- N - EA
    unknown_B <- N - EB
    observed_no_positive_A <- EA - YA
    observed_no_positive_B <- EB - YB
    identity_error_pp <- D_pp - R_pp - O_pp - P_pp
  })
}

result <- with_counts(d[needed])
result$counts_checks_pass <- TRUE
result$decomposition_defined <- with(result, is.finite(D_pp) & is.finite(R_pp) &
                                                is.finite(O_pp) & is.finite(P_pp))
result$identity_check_pass <- ifelse(result$decomposition_defined,
                                    abs(result$identity_error_pp) <= 1e-10, NA)
if (any(result$identity_check_pass %in% FALSE)) stop("Independent R identity check failed", call. = FALSE)

ordered <- c(needed, "eval_A", "eval_B", "common_fraction_N",
             "positive_among_evaluable_A", "positive_among_evaluable_B",
             "unknown_A", "unknown_B", "observed_no_positive_A", "observed_no_positive_B",
             "D_pp", "R_pp", "O_pp", "P_pp", "delta_eval_pp", "identity_error_pp",
             "counts_checks_pass", "decomposition_defined", "identity_check_pass")
parent <- dirname(output)
if (!dir.exists(parent) && !dir.create(parent, recursive = TRUE)) stop("Cannot create output directory", call. = FALSE)
write.csv(result[ordered], output, row.names = FALSE, na = "NA", fileEncoding = "UTF-8")
cat("Verified", nrow(result), "aggregate scenario rows; no patient records read.\n")
cat("Independent point-estimate verification only; bootstrap intervals not re-estimated in R.\n")
