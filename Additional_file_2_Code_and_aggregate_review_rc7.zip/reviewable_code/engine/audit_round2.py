"""Exploratory, offline, read-only round-two cohort/timing/creatinine audit.

No AKI diagnosis, imputation, patient export, network call, or package installation.
Only real discovered columns are queried. Ambiguous files/duplicate keys stop the run.
"""
from pathlib import Path
import argparse, csv, gzip, hashlib, json, re, sys, time
from datetime import datetime, timezone

def lit(x): return "'"+str(x).replace("'","''")+"'"
def ident(x): return '"'+str(x).replace('"','""')+'"'
def trim(x): return f"nullif(trim({x}),'')"
def ts(x): return f"try_cast({x} AS TIMESTAMP)"
def number(x): return f"try_cast({x} AS DOUBLE)"
def normalized(x): return f"lower(replace(replace(replace(trim({x}),' ',''),'μ','u'),'µ','u'))"

class Audit:
    def __init__(self,a,duckdb):
        self.a=a; self.root=Path(a.root).resolve(strict=True); self.out=Path(a.out).resolve()
        if not self.root.is_dir() or '://' in a.root or str(self.root).startswith('\\\\'):
            raise ValueError('Only a locally available authorized directory is supported.')
        if self.out.exists() or self.root==self.out or self.root in self.out.parents or self.out in self.root.parents:
            raise ValueError('Use a new output directory disjoint from the input tree.')
        self.out.mkdir(parents=True)
        self.t=time.time(); self.stats={}; self.files={}; self.columns={}; self.bound=set()
        self.r={'source':a.source,'status':'running','scope':'Exploratory timing and measurement availability; not confirmed surgery, baseline or AKI outcomes.',
                'created_utc':datetime.now(timezone.utc).isoformat(),'python':sys.version.split()[0],'duckdb':duckdb.__version__,
                'stage':a.stage,'patient_rows_exported':False,'network_calls':False,'inputs':[],'cohort_coverage':[],
                'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
        self.c=duckdb.connect(':memory:',config={'threads':'1','memory_limit':a.memory_limit,'autoinstall_known_extensions':'false','autoload_known_extensions':'false'})
        self.c.execute("SET temp_directory = ''")
        grouped={}
        for path in self.root.rglob('*'):
            if path.is_file() and re.search(r'\.(csv|tsv)(\.gz)?$',path.name,re.I):
                path=path.resolve(strict=True)
                if self.root not in path.parents: continue
                name=re.sub(r'\.(csv|tsv)(\.gz)?$','',path.name,flags=re.I).lower()
                grouped.setdefault(name,[]).append(path)
        self.r['ambiguous_tables']=[name for name,paths in grouped.items() if len(paths)>1]
        for name,paths in grouped.items():
            if len(paths)!=1: continue
            path=paths[0]; delimiter='\t' if re.search(r'\.tsv(\.gz)?$',path.name,re.I) else ','
            opener=gzip.open if path.suffix.lower()=='.gz' else open
            with opener(path,'rt',encoding='utf-8-sig',newline='') as f: columns=next(csv.reader(f,delimiter=delimiter,strict=True))
            if not columns or any(not c.strip() for c in columns) or len(set(c.lower() for c in columns))!=len(columns):
                raise ValueError('Invalid table header: '+name)
            self.files[name]=(path,delimiter); self.columns[name]={c.lower():c for c in columns}
        self.r['discovered_schema']=self.columns

    def rows(self,sql):
        cur=self.c.execute(sql); fields=[d[0] for d in cur.description]
        return [dict(zip(fields,row)) for row in cur.fetchall()]

    def table(self,name,required):
        if name not in self.columns or any(c not in self.columns[name] for c in required):
            raise ValueError('Required table/columns unavailable or ambiguous: '+name)
        if name in self.bound: return
        path,delim=self.files[name]; stat=path.stat(); h=hashlib.sha256()
        with path.open('rb') as f:
            for block in iter(lambda:f.read(8*1024*1024),b''): h.update(block)
        self.stats[path]=(stat.st_size,stat.st_mtime_ns)
        self.r['inputs'].append({'table':name,'path':str(path),'bytes':stat.st_size,'mtime_ns':stat.st_mtime_ns,'sha256':h.hexdigest()})
        cols=', '.join(ident(actual)+' AS '+ident(c) for c,actual in self.columns[name].items())
        self.c.execute(f'CREATE TEMP VIEW {ident(name)} AS SELECT {cols} FROM read_csv({lit(path)},delim={lit(delim)},header=true,all_varchar=true,strict_mode=true,ignore_errors=false)')
        self.bound.add(name)

    def unique(self,table,key):
        r=self.rows(f'SELECT count(*) n,count({trim(key)}) nonempty,count(DISTINCT {trim(key)}) distinct_keys FROM {table}')[0]
        self.r.setdefault('key_checks',[]).append({'table':table,'key':key,**r})
        if r['n']!=r['nonempty'] or r['n']!=r['distinct_keys']: raise ValueError('Missing or duplicate required primary key: '+table)

    def mimic(self):
        for table,fields in {
            'patients':['subject_id','anchor_age','anchor_year'],
            'admissions':['subject_id','hadm_id','admittime','dischtime'],
            'icustays':['subject_id','hadm_id','stay_id','intime','outtime'],
            'services':['subject_id','hadm_id','transfertime','curr_service'],
            'procedures_icd':['subject_id','hadm_id','icd_code','icd_version','chartdate'],
            'd_icd_procedures':['icd_code','icd_version','long_title'],
            'd_items':['itemid','label','linksto'],
            'procedureevents':['subject_id','hadm_id','stay_id','itemid','starttime','endtime','statusdescription'],
        }.items(): self.table(table,fields)
        for table,key in [('patients','subject_id'),('admissions','hadm_id'),('icustays','stay_id')]: self.unique(table,key)
        self.c.execute(f'''CREATE TEMP TABLE linked AS SELECT i.stay_id stay,i.subject_id person,i.hadm_id encounter,
            {ts('i.intime')} t0,{ts('i.outtime')} tout,{ts('a.admittime')} admit,{ts('a.dischtime')} discharge,
            try_cast(p.anchor_age AS INTEGER)+year({ts('a.admittime')})-try_cast(p.anchor_year AS INTEGER) age,
            row_number() OVER(PARTITION BY i.hadm_id ORDER BY {ts('i.intime')} NULLS LAST,i.stay_id) first_rank
            FROM icustays i JOIN admissions a ON i.hadm_id=a.hadm_id AND i.subject_id=a.subject_id JOIN patients p ON i.subject_id=p.subject_id''')
        self.r['anchor_quality']=self.rows('''SELECT count(*) linked_stays,
            count(*) FILTER(WHERE t0 IS NULL OR tout IS NULL OR admit IS NULL OR discharge IS NULL) missing_time,
            count(*) FILTER(WHERE t0<admit) icu_before_hospital_admit,
            count(*) FILTER(WHERE tout>discharge) icu_exit_after_hospital_discharge,
            count(*) FILTER(WHERE tout>discharge AND tout<=discharge+INTERVAL 6 HOUR) exit_after_discharge_within_6h,
            count(*) FILTER(WHERE tout>discharge+INTERVAL 24 HOUR) exit_after_discharge_over_24h,
            count(*) FILTER(WHERE age>=18 AND admit<=t0 AND t0<=tout AND tout<=discharge) all_strict_eligible,
            count(*) FILTER(WHERE first_rank=1 AND age>=18 AND admit<=t0 AND t0<=tout AND tout<=discharge) first_strict_eligible,
            count(*) FILTER(WHERE first_rank=1 AND age>=18 AND admit<=t0 AND t0<=tout AND t0<=discharge) first_overlap_eligible FROM linked''')[0]
        self.r['anchor_quality']['admissions_with_tied_nonmissing_icu_entry']=self.rows('SELECT count(DISTINCT encounter) n FROM (SELECT encounter,t0 FROM linked WHERE t0 IS NOT NULL GROUP BY 1,2 HAVING count(*)>1)')[0]['n']
        self.c.execute('''CREATE TEMP TABLE base AS SELECT *,epoch(least(tout,discharge)-t0)/3600.0 end_h,
            epoch(discharge-t0)/3600.0 hospital_end_h,epoch(admit-t0)/3600.0 admit_h,
            tout<=discharge strict_bounds FROM linked WHERE first_rank=1 AND age>=18 AND admit<=t0 AND t0<=tout AND t0<=discharge''')
        # Entry service is the latest timestamp <= ICU entry. Conflicting ties remain unclassified.
        self.c.execute(f'''CREATE TEMP TABLE latest_service AS WITH x AS (
            SELECT b.stay,s.curr_service,{ts('s.transfertime')} service_time,
            dense_rank() OVER(PARTITION BY b.stay ORDER BY {ts('s.transfertime')} DESC) rnk
            FROM base b JOIN services s ON b.encounter=s.hadm_id AND b.person=s.subject_id
            WHERE {ts('s.transfertime')}<=b.t0)
            SELECT stay,count(DISTINCT curr_service) n_services,min(curr_service) service FROM x WHERE rnk=1 GROUP BY stay''')
        self.r['entry_service_counts']=self.rows('SELECT service,n_services,count(*) n_stays FROM latest_service GROUP BY 1,2 ORDER BY n_stays DESC')
        self.r['cabg_dictionary_candidates']=self.rows("SELECT DISTINCT icd_code,icd_version,long_title FROM d_icd_procedures WHERE regexp_matches(lower(long_title),'coronary.*bypass|bypass.*coronary') ORDER BY icd_version,icd_code")
        self.c.execute("CREATE TEMP TABLE cabg_codes AS SELECT DISTINCT icd_code,icd_version FROM d_icd_procedures WHERE regexp_matches(lower(long_title),'coronary.*bypass|bypass.*coronary')")
        self.c.execute('''CREATE TEMP TABLE proc_dates AS SELECT p.subject_id person,p.hadm_id encounter,try_cast(p.chartdate AS DATE) op_date,
            c.icd_code IS NOT NULL cabg_label FROM procedures_icd p LEFT JOIN cabg_codes c ON p.icd_code=c.icd_code AND p.icd_version=c.icd_version''')
        self.c.execute('''CREATE TEMP TABLE nearby_proc AS SELECT b.stay,count(DISTINCT p.op_date) any_dates,
            count(DISTINCT p.op_date) FILTER(WHERE p.cabg_label) cabg_dates,
            max(p.op_date) FILTER(WHERE p.cabg_label) cabg_date
            FROM base b JOIN proc_dates p ON b.encounter=p.encounter AND b.person=p.person
            WHERE p.op_date BETWEEN cast(b.t0 AS DATE)-1 AND cast(b.t0 AS DATE) GROUP BY b.stay''')
        self.c.execute("""CREATE TEMP TABLE flags AS SELECT b.*,coalesce(s.n_services=1 AND contains(lower(s.service),'surg'),false) service_surg,
            coalesce(p.any_dates>0,false) nearby_procedure,coalesce(p.cabg_dates=1,false) cabg_day,p.cabg_date
            FROM base b LEFT JOIN latest_service s USING(stay) LEFT JOIN nearby_proc p USING(stay)""")
        self.cohorts=[('first_icu_overlap_bounds','true'),('first_icu_strict_bounds','strict_bounds'),
            ('surgical_service_at_entry','service_surg'),('surgical_service_plus_procedure_day','service_surg AND nearby_procedure'),
            ('cabg_code_single_nearby_date','cabg_day'),('cabg_code_strict_bounds','cabg_day AND strict_bounds'),
            ('cabg_same_icu_calendar_date','cabg_day AND cabg_date=cast(t0 AS DATE)'),
            ('cabg_previous_calendar_date','cabg_day AND cabg_date=cast(t0 AS DATE)-1')]
        self.r['operation_dictionary']=self.rows("SELECT DISTINCT itemid,label,linksto FROM d_items WHERE lower(trim(label))='operation' AND lower(linksto)='procedureevents'")
        ids=[lit(row['itemid']) for row in self.r['operation_dictionary']]
        if ids:
            self.r['operation_raw_counts']=self.rows(f"SELECT count(*) n_rows,count(DISTINCT stay_id) n_stays FROM procedureevents WHERE itemid IN ({','.join(ids)})")[0]
            self.c.execute(f'''CREATE TEMP TABLE op_events AS SELECT p.stay_id stay,{ts('p.starttime')} op_start,{ts('p.endtime')} op_end,
                p.statusdescription status,i.t0,i.tout,i.admit,i.discharge
                FROM procedureevents p JOIN linked i ON p.stay_id=i.stay AND p.hadm_id=i.encounter AND p.subject_id=i.person
                WHERE p.itemid IN ({','.join(ids)})''')
            self.r['operation_event_quality']=self.rows('''SELECT count(*) n_events,count(DISTINCT stay) n_stays,
                count(*) FILTER(WHERE op_start IS NULL OR op_end IS NULL) missing_bounds,
                count(*) FILTER(WHERE op_end<op_start) negative_duration,
                count(*) FILTER(WHERE op_start=op_end) zero_duration,
                count(*) FILTER(WHERE op_end>op_start+INTERVAL 24 HOUR) duration_over_24h,
                count(*) FILTER(WHERE op_end<=t0) ends_before_or_at_icu_entry,
                count(*) FILTER(WHERE op_end<=t0 AND op_end>=t0-INTERVAL 6 HOUR) ends_within_6h_before_entry,
                count(*) FILTER(WHERE op_start>=t0 AND op_start<=tout) starts_during_icu,
                count(*) FILTER(WHERE op_start<admit OR op_end>discharge) outside_hospital_bounds FROM op_events''')[0]
            self.r['operation_event_status']=self.rows('SELECT status,count(*) n FROM op_events GROUP BY 1 ORDER BY n DESC')
        self.r['operational_notes']=['First ICU per admission ranked before time exclusions; one admission is not one person.',
            'Overlap-bounded alternative requires valid ICU entry inside hospital admission and censors at min(ICU exit,hospital discharge); not an adjudicated correction.',
            'Service contains surg is a reproducible narrow proxy, not exhaustive surgical classification.',
            'CABG dictionary-title matches plus exactly one distinct candidate date in ICU date or previous date are exploratory; concomitant procedures and code specificity need review.',
            'Operation event interval is not validated surgery/anesthesia timing. No exact postoperative cohort is asserted.']

    def eicu(self):
        self.table('patient',['patientunitstayid','patienthealthsystemstayid','uniquepid','age','hospitalid','unittype','unitvisitnumber','hospitaladmitoffset','hospitaldischargeoffset','unitdischargeoffset','unitadmitsource'])
        self.table('apachepredvar',['patientunitstayid','electivesurgery'])
        self.table('admissiondx',['patientunitstayid','admitdxpath','admitdxenteredoffset'])
        self.unique('patient','patientunitstayid')
        self.c.execute(f'''CREATE TEMP TABLE linked AS SELECT {trim('patientunitstayid')} stay,{trim('patienthealthsystemstayid')} encounter,
            {trim('uniquepid')} person,hospitalid hospital,unitadmitsource,unittype,
            CASE WHEN replace(trim(age),' ','')='>89' THEN 90 ELSE try_cast(age AS INTEGER) END age,
            {number('hospitaladmitoffset')}/60.0 admit_h,{number('hospitaldischargeoffset')}/60.0 hospital_end_h,
            {number('unitdischargeoffset')}/60.0 unit_end_h,try_cast(unitvisitnumber AS INTEGER) visit FROM patient''')
        self.r['anchor_quality']=self.rows('''SELECT count(*) all_stays,
            count(*) FILTER(WHERE age>=18 AND isfinite(admit_h) AND admit_h<=0 AND isfinite(unit_end_h) AND unit_end_h>=0 AND stay IS NOT NULL AND encounter IS NOT NULL AND person IS NOT NULL) prior_round_eligible,
            count(*) FILTER(WHERE unit_end_h>hospital_end_h) icu_exit_after_hospital_discharge,
            count(*) FILTER(WHERE visit IS NULL) missing_visit_number,
            count(*) FILTER(WHERE visit=1) recorded_first_visit_rows FROM linked''')[0]
        repeated=self.rows('SELECT count(*) n FROM (SELECT person,encounter FROM linked WHERE visit=1 GROUP BY 1,2 HAVING count(*)>1)')[0]['n']
        self.r['anchor_quality']['duplicate_first_visit_encounters']=repeated
        if repeated: raise ValueError('Multiple visit=1 records within encounter; first-stay rule requires adjudication.')
        self.r['recorded_unit_order_check']=self.rows('''WITH enc AS (SELECT person,encounter,
            count(*) FILTER(WHERE visit=1) n_first,max(admit_h) FILTER(WHERE visit=1) first_admit_h,
            max(admit_h) FILTER(WHERE isfinite(admit_h) AND admit_h<=0) latest_admit_offset
            FROM linked WHERE person IS NOT NULL AND encounter IS NOT NULL GROUP BY 1,2)
            SELECT count(*) n_encounters,count(*) FILTER(WHERE n_first=0) no_visit1,
            count(*) FILTER(WHERE n_first=1 AND isfinite(first_admit_h) AND first_admit_h<latest_admit_offset) first_visit_offset_not_earliest FROM enc''')[0]
        self.c.execute('''CREATE TEMP TABLE base AS SELECT *,least(unit_end_h,hospital_end_h) end_h,unit_end_h<=hospital_end_h strict_bounds
            FROM linked WHERE visit=1 AND age>=18 AND stay IS NOT NULL AND person IS NOT NULL AND encounter IS NOT NULL
            AND isfinite(admit_h) AND admit_h<=0 AND isfinite(unit_end_h) AND unit_end_h>=0 AND isfinite(hospital_end_h) AND hospital_end_h>=0''')
        self.r['source_distribution']=self.rows('SELECT unitadmitsource,count(*) n FROM base GROUP BY 1 ORDER BY n DESC')
        self.r['first_recorded_unit_types']=self.rows('SELECT unittype,count(*) n FROM base GROUP BY 1 ORDER BY n DESC')
        self.c.execute(f'''CREATE TEMP TABLE dx_flags AS SELECT patientunitstayid stay,
            bool_or(contains(lower(admitdxpath),'|all diagnosis|operative|diagnosis|')) operative_any,
            bool_or(contains(lower(admitdxpath),'|all diagnosis|operative|diagnosis|') AND {number('admitdxenteredoffset')} BETWEEN 0 AND 1440) operative_24h,
            bool_or(contains(lower(admitdxpath),'|all diagnosis|operative|diagnosis|') AND contains(lower(admitdxpath),'cabg')) cabg_any,
            bool_or(contains(lower(admitdxpath),'|all diagnosis|operative|diagnosis|') AND contains(lower(admitdxpath),'cabg') AND {number('admitdxenteredoffset')} BETWEEN 0 AND 1440) cabg_24h
            FROM admissiondx GROUP BY patientunitstayid''')
        self.c.execute("CREATE TEMP TABLE elective AS SELECT patientunitstayid stay,bool_or(try_cast(electivesurgery AS INTEGER)=1) elective,count(*) FILTER(WHERE try_cast(electivesurgery AS INTEGER) IN (0,1)) n_valid_flag FROM apachepredvar GROUP BY 1")
        self.c.execute('''CREATE TEMP TABLE flags AS SELECT b.*,
            coalesce(unitadmitsource IN ('Operating Room','Recovery Room','PACU'),false) or_pacu,
            coalesce(unitadmitsource IN ('Operating Room','Recovery Room'),false) old_or,
            coalesce(d.operative_any,false) operative_any,coalesce(d.operative_24h,false) operative_24h,
            coalesce(d.cabg_any,false) cabg_any,coalesce(d.cabg_24h,false) cabg_24h,coalesce(e.elective,false) elective,
            d.stay IS NOT NULL diagnosis_record_present,e.stay IS NOT NULL apache_record_present,coalesce(e.n_valid_flag>0,false) valid_elective_flag
            FROM base b LEFT JOIN dx_flags d USING(stay) LEFT JOIN elective e USING(stay)''')
        self.r['proxy_overlap']=self.rows('''SELECT or_pacu,operative_any,operative_24h,elective,count(*) n FROM flags GROUP BY 1,2,3,4 ORDER BY n DESC''')
        self.r['documentation_presence']=self.rows('''SELECT count(*) n_stays,
            count(*) FILTER(WHERE diagnosis_record_present) has_admissiondx_rows,
            count(*) FILTER(WHERE apache_record_present) has_apachepredvar_rows,
            count(*) FILTER(WHERE valid_elective_flag) has_valid_elective_flag,
            count(*) FILTER(WHERE NOT valid_elective_flag) missing_or_invalid_elective_flag FROM flags''')[0]
        self.r['cabg_diagnosis_labels']=self.rows("SELECT admitdxpath,count(*) n FROM admissiondx WHERE contains(lower(admitdxpath),'|all diagnosis|operative|diagnosis|') AND contains(lower(admitdxpath),'cabg') GROUP BY 1 ORDER BY n DESC")
        self.cohorts=[('first_recorded_unit_overlap_bounds','true'),('first_recorded_unit_strict_bounds','strict_bounds'),
            ('or_recovery_prior_proxy','old_or'),('or_recovery_pacu_source','or_pacu'),
            ('or_pacu_and_operative_dx','or_pacu AND operative_any'),('or_pacu_and_operative_dx_by24h','or_pacu AND operative_24h'),
            ('or_pacu_and_cabg_dx','or_pacu AND cabg_any'),('or_pacu_and_cabg_dx_by24h','or_pacu AND cabg_24h'),
            ('or_pacu_and_cabg_strict_bounds','or_pacu AND cabg_any AND strict_bounds')]
        self.r['operational_notes']=['First unitvisitnumber=1 per hospitalization; cannot establish first lifetime stay or calendar order across admissions.',
            'OR/Recovery/PACU source and operative APACHE diagnosis are complementary surgical proxies; neither gives actual operation completion time.',
            'Operative classification recorded within24h is a cohort ascertainment sensitivity, not a predictor available at ICU entry.',
            'False proxy flags mean no positive evidence in the supplied records; missing diagnosis/elective data are not proof of non-operative or non-elective care.',
            'Lab measurements stay within the indexed ICU stay; no cross-stay clock conversion or missing timestamps imputed.']

    def creatinine(self):
        if self.a.source=='mimic':
            self.table('d_labitems',['itemid','label','fluid'])
            self.table('labevents',['subject_id','hadm_id','itemid','charttime','valuenum','valueuom','storetime'])
            items=self.rows("SELECT DISTINCT itemid,label,fluid FROM d_labitems WHERE lower(trim(label))='creatinine' AND lower(trim(fluid)) IN ('blood','serum','plasma')")
            if not items: raise ValueError('No exact local blood creatinine dictionary match.')
            self.r['creatinine_dictionary']=items
            ids=','.join(lit(row['itemid']) for row in items)
            self.c.execute(f'''CREATE TEMP TABLE creat AS SELECT subject_id person,hadm_id encounter,{ts('charttime')} measured,
                {ts('storetime')} recorded,{number('valuenum')} value,{normalized('valueuom')} unit,false unit_conflict
                FROM labevents WHERE itemid IN ({ids})''')
            self.c.execute('''CREATE TEMP TABLE lab_link AS SELECT b.stay,b.t0,b.end_h,b.hospital_end_h,
                epoch(c.measured-b.t0)/3600.0 h,epoch(c.recorded-b.t0)/3600.0 recorded_h,c.value,c.unit,c.unit_conflict,
                c.measured,b.cabg_date FROM flags b JOIN creat c ON b.person=c.person AND b.encounter=c.encounter
                WHERE c.measured>=b.admit AND c.measured<=b.discharge AND c.measured>=b.t0-INTERVAL 168 HOUR AND c.measured<b.t0+INTERVAL 168 HOUR''')
        else:
            self.table('lab',['patientunitstayid','labname','labresult','labresultoffset','labresultrevisedoffset','labmeasurenamesystem','labmeasurenameinterface'])
            u1=normalized('labmeasurenamesystem'); u2=normalized('labmeasurenameinterface')
            self.c.execute(f'''CREATE TEMP TABLE creat AS SELECT patientunitstayid stay,{number('labresultoffset')}/60.0 measured,
                {number('labresultrevisedoffset')}/60.0 recorded,{number('labresult')} value,
                coalesce(nullif({u1},''),nullif({u2},'')) unit,
                coalesce(nullif({u1},'') IS NOT NULL AND nullif({u2},'') IS NOT NULL AND {u1}<>{u2},false) unit_conflict
                FROM lab WHERE lower(trim(labname))='creatinine' ''')
            self.c.execute('''CREATE TEMP TABLE lab_link AS SELECT b.stay,b.end_h,b.hospital_end_h,c.measured h,c.recorded recorded_h,
                c.value,c.unit,c.unit_conflict FROM flags b JOIN creat c USING(stay)
                WHERE isfinite(c.measured) AND c.measured>=greatest(-168,b.admit_h) AND c.measured<168 AND c.measured<=b.end_h''')
        self.r['creatinine_unit_counts']=self.rows('SELECT unit,unit_conflict,count(*) n FROM creat GROUP BY 1,2 ORDER BY n DESC')
        # Conversion is explicit and restricted to recognized lexical units. No plausibility ceiling is imposed.
        self.c.execute('''CREATE TEMP TABLE usable AS SELECT *,CASE WHEN unit='mg/dl' THEN value WHEN unit='umol/l' THEN value/88.4 WHEN unit='mg/l' THEN value/10.0 END mgdl
            FROM lab_link WHERE isfinite(value) AND value>0 AND NOT unit_conflict AND unit IN ('mg/dl','umol/l','mg/l')''')
        self.r['lab_quality']=self.rows('''SELECT count(*) linked_rows,count(*) FILTER(WHERE unit_conflict) unit_conflicts,
            count(*) FILTER(WHERE value IS NULL OR NOT isfinite(value) OR value<=0) invalid_value,
            count(*) FILTER(WHERE unit IS NULL OR unit NOT IN ('mg/dl','umol/l','mg/l')) unrecognized_unit FROM lab_link''')[0]
        self.r['lab_quality']['same_time_conflicting_values']=self.rows('SELECT count(*) n FROM (SELECT stay,h FROM usable GROUP BY 1,2 HAVING count(DISTINCT mgdl)>1)')[0]['n']
        self.c.execute('''CREATE TEMP TABLE measures AS SELECT stay,
            count(*) FILTER(WHERE h<0)>0 pre7d,
            count(*) FILTER(WHERE h>=-48 AND h<0)>0 pre48h,
            count(*) FILTER(WHERE h<0 AND isfinite(recorded_h) AND recorded_h>=h AND recorded_h<=0)>0 pre_available,
            count(*) FILTER(WHERE h>=0 AND h<6 AND h<=end_h)>0 h0_6,
            count(*) FILTER(WHERE h>=6 AND h<48 AND h<=end_h)>0 h6_48,
            count(*) FILTER(WHERE h>=48 AND h<168 AND h<=end_h)>0 h48_168,
            count(*) FILTER(WHERE h>=6 AND h<168 AND h<=end_h)>0 h6_168,
            count(DISTINCT h) FILTER(WHERE h>=0 AND h<168 AND h<=end_h)>=2 two_icu_times,
            count(*) FILTER(WHERE h>=6 AND h<168)>0 h6_168_hospital
            FROM usable GROUP BY stay''')
        if self.a.source=='mimic':
            self.c.execute('''CREATE TEMP TABLE procedure_baseline AS SELECT DISTINCT f.stay FROM flags f JOIN creat c
                ON f.encounter=c.encounter AND f.person=c.person WHERE f.cabg_day
                AND c.measured>=f.admit AND c.measured<cast(f.cabg_date AS TIMESTAMP)
                AND c.measured>=cast(f.cabg_date AS TIMESTAMP)-INTERVAL 7 DAY
                AND isfinite(c.value) AND c.value>0 AND NOT c.unit_conflict AND c.unit IN ('mg/dl','umol/l','mg/l')''')
            self.r['procedure_date_baseline']=self.rows('''SELECT count(*) n_cabg_candidate_stays,
                count(*) FILTER(WHERE EXISTS(SELECT 1 FROM procedure_baseline p WHERE p.stay=f.stay)) preprocedure_calendar7d,
                count(*) FILTER(WHERE EXISTS(SELECT 1 FROM usable u WHERE u.stay=f.stay AND cast(u.measured AS DATE)=f.cabg_date AND u.h<0)) same_day_preicu_order_unknown,
                count(*) FILTER(WHERE EXISTS(SELECT 1 FROM usable u WHERE u.stay=f.stay AND u.h<0)) any_preicu7d,
                count(*) FILTER(WHERE EXISTS(SELECT 1 FROM procedure_baseline p WHERE p.stay=f.stay)
                    AND EXISTS(SELECT 1 FROM usable u WHERE u.stay=f.stay AND u.h>=6 AND u.h<168 AND u.h<=f.end_h)) preprocedure_and_icu_followup
                FROM flags f WHERE cabg_day''')[0]
            self.r['procedure_date_baseline']['limitation']='Reference window covers7 calendar days before procedure date, bounded by the same hospital admission; outpatient/unknown-admission labs are not reassigned. Same-day samples have unknown pre/post-operation order. Presence is not stable preoperative kidney function.'
        self.r['measurement_definition']='Positive finite creatinine with mg/dl, umol/l or mg/l units (explicit conversion), observed timestamps and matching stay/admission. Coverage is not a stable baseline, negative AKI or KDIGO diagnosis. The0-6h and pre_early_followup metrics use specimen time, not predictor availability by6h. Recorded/revised time is an availability proxy; eICU revised time is not first availability.'

    def summarize(self):
        full=self.a.stage=='full'
        for name,where in self.cohorts:
            metrics='''count(*) n_stays,count(DISTINCT f.person) n_persons,count(DISTINCT f.encounter) n_encounters,
                count(*) FILTER(WHERE NOT strict_bounds) n_end_boundary_discordant,
                count(*) FILTER(WHERE end_h<6) observation_under6h,count(*) FILTER(WHERE end_h<48) observation_under48h,
                count(*) FILTER(WHERE end_h>=168) observation_atleast168h'''
            if full:
                metrics+=''' ,count(*) FILTER(WHERE m.pre7d) preicu7d,count(*) FILTER(WHERE m.pre48h) preicu48h,
                count(*) FILTER(WHERE m.pre_available) preicu_available_by_entry,
                count(*) FILTER(WHERE m.h0_6) creatinine0_6h,count(*) FILTER(WHERE m.h6_48) creatinine6_48h,
                count(*) FILTER(WHERE m.h48_168) creatinine48_168h,count(*) FILTER(WHERE m.h6_168) creatinine6_168h,
                count(*) FILTER(WHERE m.pre7d AND m.h6_168) preicu_and_followup,
                count(*) FILTER(WHERE m.two_icu_times) two_distinct_icu_times,
                count(*) FILTER(WHERE m.pre7d AND m.h0_6 AND m.h6_168) pre_early_followup'''
                metrics+=',count(*) FILTER(WHERE m.pre7d AND m.h6_168_hospital) preicu_and_hospital_followup' if self.a.source=='mimic' else ',NULL::BIGINT preicu_and_hospital_followup'
            join='LEFT JOIN measures m USING(stay)' if full else ''
            r=self.rows(f'SELECT {metrics} FROM flags f {join} WHERE {where}')[0]
            self.r['cohort_coverage'].append({'cohort':name,'rule':where,**r})
        if full and self.a.source=='eicu':
            hospitals=self.rows('''SELECT hospital,count(*) n,count(*) FILTER(WHERE m.pre7d AND m.h6_168) paired
                FROM flags f LEFT JOIN measures m USING(stay) WHERE or_pacu AND operative_any GROUP BY hospital''')
            # Only summaries across hospitals, with no hospital identifiers exported.
            denominators=[r['n'] for r in hospitals if r['hospital'] is not None]
            eligible=[r for r in hospitals if r['hospital'] is not None and r['n']>=20]
            ratios=sorted(r['paired']/r['n'] for r in eligible)
            def quantile(p):
                if not ratios:return None
                k=(len(ratios)-1)*p;lo=int(k);hi=min(lo+1,len(ratios)-1)
                return ratios[lo]+(ratios[hi]-ratios[lo])*(k-lo)
            self.r['hospital_heterogeneity']={'cohort':'or_pacu_and_operative_dx','hospitals':len(denominators),
                'hospitals_with_atleast20_stays':len(eligible),'hospitals_with_any_paired':sum(r['paired']>0 for r in hospitals if r['hospital'] is not None),
                'paired_fraction_q1':quantile(.25),'paired_fraction_median':quantile(.5),'paired_fraction_q3':quantile(.75),
                'rule':'Hospital coverage distribution restricted to >=20 candidate stays; exploratory threshold, no sites excluded from main counts.'}

    def save(self):
        self.r['elapsed_seconds']=round(time.time()-self.t,2)
        (self.out/'audit_round2.json').write_text(json.dumps(self.r,ensure_ascii=False,indent=2),encoding='utf-8')
        rows=self.r['cohort_coverage']
        if rows:
            with (self.out/'cohort_coverage.csv').open('w',encoding='utf-8-sig',newline='') as f:
                writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

    def run(self):
        try:
            print(self.a.source+': discovered local schemas; auditing anchors and surgical proxies.',flush=True)
            self.mimic() if self.a.source=='mimic' else self.eicu()
            self.save()
            if self.a.stage=='full':
                print(self.a.source+': scanning actual creatinine events; no patient rows exported.',flush=True)
                self.creatinine()
            self.summarize()
            for path,stat in self.stats.items():
                now=path.stat()
                if (now.st_size,now.st_mtime_ns)!=stat:raise ValueError('Input changed during audit.')
            self.r['status']='completed';self.save()
            print(self.a.source+': completed aggregate audit.',flush=True)
        except Exception as exc:
            self.r['status']='failed';self.r['error_type']=type(exc).__name__;self.save()
            # Do not leak raw CSV lines or clinical record values in errors.
            print(self.a.source+': stopped; exception type '+type(exc).__name__,flush=True)
            raise RuntimeError('Audit failed; inspect code/schema and aggregate status, not raw error text.') from None

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',choices=['mimic','eicu'],required=True);p.add_argument('--root',required=True);p.add_argument('--out',required=True)
    p.add_argument('--dependency-dir',required=True);p.add_argument('--memory-limit',default='4GB');p.add_argument('--stage',choices=['cohort','full'],default='full')
    p.add_argument('--authorized-local-data',action='store_true');a=p.parse_args()
    if not a.authorized_local_data:p.error('Only run with your locally authorized data and --authorized-local-data.')
    sys.path.insert(0,str(Path(a.dependency_dir).resolve(strict=True)))
    import duckdb
    Audit(a,duckdb).run()

if __name__=='__main__':main()
