"""Recover per-variable denominators from frozen aggregates, without clinical rows.

Private input: final round-5 formal_analysis.json files.
Private output: exact aggregate counts, potentially sparse.
Public output: counts subject to linked suppression across overlapping subsets.
"""
from pathlib import Path
import argparse,copy,csv,hashlib,json

VARIABLES={
 'age':('Age in years used for continuous summaries','years','Privacy-topcoded ages are known records but excluded from exact numeric summaries; not imputed.'),
 'admit_lag':('Hospital admission to ICU entry interval','hours','Defined from the recorded admission and ICU-entry boundaries; eligibility requires usable boundaries.'),
 'sex':('Recorded sex category','category','Observed recorded category; unknown/missing categories are excluded from the available count.'),
 'age_group':('Age category used for grouped summaries','category','18–64,65–79,>=80,unknown. MIMIC anchor_age=91 is unknown; eICU >89 remains in >=80.'),
 'observation_h':('Recorded observation duration','hours','Truncated at the existing recorded-end/death/horizon rules; short duration remains observed.'),
 'pre_count':('Valid pre-entry measurement count','count','Zero is an observed count, not a missing count.'),
 'post_count':('Valid post-entry measurement count','count','Zero is an observed count, not a missing count.'),
 'last_gap_h':('Final post-entry measurement to observation endpoint','hours','Undefined when there is no valid post-entry measurement.'),
 'post_median_gap_h':('Within-stay median consecutive post-entry measurement interval','hours','Undefined when fewer than two distinct valid post-entry measurement times are available.'),
 'refA_age_h':('Time from strategy A reference to ICU entry','hours','Undefined when no valid strategy A reference exists; reference presence alone does not establish evaluability.'),
 'refB_age_h':('Time from strategy B reference to ICU entry','hours','Undefined when no valid strategy B reference exists; reference presence alone does not establish evaluability.'),
 'last_pre_age_h':('Time from final valid pre-entry measurement to ICU entry','hours','Undefined when no valid pre-entry measurement exists.')}
GROUPS=['N','EA','not_EA','EB','not_EB','C','not_C']
OBS=['observation_h','pre_count','post_count','last_gap_h','post_median_gap_h','refA_age_h','refB_age_h','last_pre_age_h']
COUNT_FIELDS=['n_available','n_unavailable','n_privacy_topcoded','n_other_missing_or_nonnumeric','n_undefined_required_measurement_absent']

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def writecsv(p,rows):
    with p.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def categorical_count(levels,side,category):return levels.get(category,{}).get(side+'_n',0)

def row(source,group,var,total,available,path,method,privacy=0,other=None,undefined=None):
    if other is None and undefined is None:other=total-available-privacy
    if undefined is None:undefined=0
    if other is None:other=0
    assert all(isinstance(x,int) and x>=0 for x in [total,available,privacy,other,undefined])
    assert available+privacy+other+undefined==total,(source,group,var,total,available,privacy,other,undefined)
    return {'source':source,'population':group,'variable':var,'label':VARIABLES[var][0],'unit':VARIABLES[var][1],
      'n_total':total,'n_available':available,'n_unavailable':total-available,'n_privacy_topcoded':privacy,
      'n_other_missing_or_nonnumeric':other,'n_undefined_required_measurement_absent':undefined,
      'definition':VARIABLES[var][2],'source_jsonpath':path,'derivation':method,'disclosure_status':'internal_exact_aggregate'}

def extract(source,d):
    assert d['source']==source and d['N']==d['variants']['main_168h']['counts']['N']
    records={}
    for key,g in d['baseline_descriptions']['groups'].items():
        assert key in ('EA','EB','C')
        for side,pop in [('selected',key),('other','not_'+key)]:
            total=g[side+'_n'];assert total==sum(v[side+'_n'] for v in g['categorical']['sex'].values())
            for var,v in g['continuous'].items():
                q=v[side];assert q['n_total']==total and q['n_observed']+q['n_missing_or_nonnumeric']==total
                priv=categorical_count(g['categorical']['age_recording'],side,'privacy_topcoded') if var=='age' else 0
                undefined=q['n_missing_or_nonnumeric'] if var=='last_gap_h' else 0
                r=row(source,pop,var,total,q['n_observed'],f'$.baseline_descriptions.groups.{key}.continuous.{var}.{side}',
                    'direct frozen aggregate',privacy=priv,other=q['n_missing_or_nonnumeric']-priv-undefined,undefined=undefined)
                records[(pop,var)]=r
            for var in ['sex','age_group']:
                levels=g['categorical'][var];unknown=categorical_count(levels,side,'unknown')
                assert sum(v[side+'_n'] for v in levels.values())==total
                priv=unknown if source=='mimic' and var=='age_group' else 0
                records[(pop,var)]=row(source,pop,var,total,total-unknown,
                    f'$.baseline_descriptions.groups.{key}.categorical.{var}',
                    'sum known category counts; unknown retained as unavailable',privacy=priv,other=unknown-priv)
    # N counts use the mutually exclusive EA / not_EA partition. No medians are pooled.
    for var in ['age','admit_lag','sex','age_group']:
        a=records[('EA',var)];b=records[('not_EA',var)]
        records[('N',var)]=row(source,'N',var,a['n_total']+b['n_total'],a['n_available']+b['n_available'],
          a['source_jsonpath']+' + '+b['source_jsonpath'],'sum of disjoint EA and not_EA aggregate counts',
          privacy=a['n_privacy_topcoded']+b['n_privacy_topcoded'],other=a['n_other_missing_or_nonnumeric']+b['n_other_missing_or_nonnumeric'])
    for pop,g in d['observation_summary'].items():
        for var in OBS:
            v=g[var];assert v['observed']+v['missing']==g['n']
            undefined=v['missing'] if var in ['last_gap_h','post_median_gap_h','refA_age_h','refB_age_h','last_pre_age_h'] else 0
            r=row(source,pop,var,g['n'],v['observed'],f'$.observation_summary.{pop}.{var}',
                'direct frozen aggregate',other=v['missing']-undefined,undefined=undefined)
            if (pop,var) in records:
                for field in ['n_total']+COUNT_FIELDS:assert records[(pop,var)][field]==r[field]
            records[(pop,var)]=r
    # Exact complement counts from nested N and C; no summary quantiles are imputed.
    for var in OBS:
        a=records[('N',var)];b=records[('C',var)]
        r=row(source,'not_C',var,a['n_total']-b['n_total'],a['n_available']-b['n_available'],
          a['source_jsonpath']+' minus '+b['source_jsonpath'],'difference of nested N and C aggregate counts',
          other=a['n_other_missing_or_nonnumeric']-b['n_other_missing_or_nonnumeric'],
          undefined=a['n_undefined_required_measurement_absent']-b['n_undefined_required_measurement_absent'])
        if ('not_C',var) in records:
            for field in ['n_total']+COUNT_FIELDS:assert records[('not_C',var)][field]==r[field]
        records[('not_C',var)]=r
    # Reconcile each partition against N, across every variable and count component.
    for var in VARIABLES:
        for group in ['EA','EB','C']:
            for field in ['n_total']+COUNT_FIELDS:
                assert records[(group,var)][field]+records[('not_'+group,var)][field]==records[('N',var)][field],(source,group,var,field)
    assert len(records)==len(GROUPS)*len(VARIABLES)
    return [records[(g,v)] for g in GROUPS for v in VARIABLES]

def suppress(rows):
    out=[]
    for original in rows:
        r=copy.deepcopy(original);g=r['population'];v=r['variable'];reason=None
        if g!='N':
            if v=='age' or (r['source']=='mimic' and v=='age_group'):
                reason='linked_age_count_block_withheld_across_overlapping_populations'
            elif v=='post_median_gap_h':
                reason='linked_interval_count_block_withheld_across_overlapping_populations'
            elif v in ['refA_age_h','refB_age_h','last_pre_age_h'] and r['n_unavailable']!=0:
                reason='linked_reference_count_block_withheld_across_overlapping_populations'
        if any(0<r[k]<10 for k in COUNT_FIELDS):
            reason=reason or 'nonzero_count_below_10_linked_count_block_withheld'
        if reason:
            for k in COUNT_FIELDS:r[k]=None
            r['disclosure_status']=reason
        else:r['disclosure_status']='reported_aggregate'
        # A withheld observed/missing count cannot be recovered by n_total subtraction
        # because both complementary fields and all cause-specific fields are null.
        out.append(r)
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--mimic',required=True);ap.add_argument('--eicu',required=True);ap.add_argument('--out',required=True);a=ap.parse_args()
    out=Path(a.out);private=out/'internal_audit';public=out/'tables';private.mkdir(exist_ok=True,parents=True);public.mkdir(exist_ok=True,parents=True)
    sources={s:Path(getattr(a,s)) for s in ['mimic','eicu']};before={s:{'path':str(p.resolve()),'sha256':sha(p),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for s,p in sources.items()}
    records=[]
    for s,p in sources.items():records+=extract(s,json.loads(p.read_text(encoding='utf-8')))
    released=suppress(records)
    note={
      'status':'COMPLETE_FROM_EXISTING_FROZEN_AGGREGATES','date':'2026-11-16','source_files':before,
      'clinical_rows_read':False,'clinical_network_calls':False,'new_clinical_analysis':False,'n_records':len(records),
      'scope':'Both source databases, 7 primary-population partitions and 12 descriptive/observation variables. Counts use the frozen primary population and measurement definitions.',
      'population_note':'N=primary population; EA/EB=strategy-specific evaluable; C=nonempty shared comparison keys; not_ prefixes are complements inside N.',
      'available_note':'n_available is the actual denominator for the defined numeric or known-category summary, not necessarily a count of clinically observed outcomes. A zero measurement count is observed, while a time interval needing an absent measurement is undefined.',
      'age_note':'Numeric age excludes privacy-topcoded records without imputing an exact age. MIMIC age-group unknown also includes its topcoded age; eICU >89 has a known >=80 age group. No genuine missing/nonnumeric age remained in the primary populations.',
      'disclosure_note':'All exact counts are internal. The public table suppresses whole linked count blocks, including numerator and unavailable count, for age across overlapping subgroups, post-measurement interval subgroups, and mixed-reference-availability subgroups. N-level counts and guaranteed-complete subgroup variables remain reportable. This is deliberately conservative; suppressed counts are verified, not unknown.',
      'partition_checks':'For each variable and count field, EA+not_EA=EB+not_EB=C+not_C=N; duplicate sources for post_count/last_gap_h reconcile.',
      'quantiles_recomputed':False,'public_count_blocks_reported':sum(r['disclosure_status']=='reported_aggregate' for r in released),
      'public_count_blocks_withheld':sum(r['disclosure_status']!='reported_aggregate' for r in released),
      'no_counts_inferred_from_rounded_statistics':True}
    for s,p in sources.items():assert sha(p)==before[s]['sha256'] and p.stat().st_mtime_ns==before[s]['mtime_ns']
    exact={'audit':note,'rows':records};share={'audit':note,'rows':released}
    (private/'variable_denominators_internal.json').write_text(json.dumps(exact,ensure_ascii=False,indent=2),encoding='utf-8')
    writecsv(private/'variable_denominators_internal.csv',records)
    (public/'variable_denominators_public.json').write_text(json.dumps(share,ensure_ascii=False,indent=2),encoding='utf-8')
    writecsv(public/'variable_denominators_public.csv',released)
    (private/'denominator_audit_validation.json').write_text(json.dumps(note,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:note[k] for k in ['status','n_records','public_count_blocks_reported','public_count_blocks_withheld','clinical_rows_read']},ensure_ascii=False))

if __name__=='__main__':main()
