"""Reconstruct cumulative source-to-cohort flow without changing frozen eligibility.

Local authorized data only. SQL aggregates are exported, never clinical identifiers.
Frozen Round3 selection supplies the independent final base/F/renal comparison.
"""
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime, timezone
import argparse, hashlib, json, sys, time

HERE=Path(__file__).resolve().parent
FROZEN=HERE.parent/'aki_round5'

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()

def audit(a):
    sys.path.insert(0,str(Path(a.dependency_dir).resolve()))
    sys.path.insert(0,str(Path(a.frozen_dir).resolve()))
    import duckdb
    from audit_round3 import Round3
    fdir=Path(a.frozen_dir).resolve()
    frozen_names=['audit_round2.py','audit_round3.py','cabg_review.json','renal_rules.json']
    frozen_start={n:sha(fdir/n) for n in frozen_names}
    script_start=sha(Path(__file__))
    cfg=SimpleNamespace(source=a.source,root=a.root,out=a.out,stage='flow_reporting_completion',
                        memory_limit=a.memory_limit,codebook=str(fdir/'cabg_review.json'),renal_rules=str(fdir/'renal_rules.json'))
    q=Round3(cfg,duckdb)
    q.reviewed_cohort()
    q.renal_flags()
    flow=[]
    def scalar(sql):return q.rows(sql)[0]['n']
    def stage(stage_id,label,from_table,predicate,unit='ICU or unit stays',target=None):
        out=target or 'flow_'+stage_id
        before=scalar(f'SELECT count(*) n FROM {from_table}')
        excluded=scalar(f'SELECT count(*) n FROM {from_table} WHERE NOT coalesce(({predicate}),false)')
        q.c.execute(f'CREATE TEMP TABLE {out} AS SELECT * FROM {from_table} WHERE coalesce(({predicate}),false)')
        after=scalar(f'SELECT count(*) n FROM {out}')
        assert before==excluded+after
        counts=q.rows(f'SELECT count(DISTINCT person) n_persons,count(DISTINCT encounter) n_hospital_admissions FROM {out}')[0]
        flow.append({'stage':stage_id,'label':label,'unit':unit,'n_before':before,'n_excluded':excluded,'n_after':after,
                     'sql_predicate':predicate,'from_relation':from_table,'to_relation':out,**counts})
        return out

    if a.source=='mimic':
        inventory={
          'all_patients':scalar('SELECT count(*) n FROM patients'),
          'all_hospital_admissions':scalar('SELECT count(*) n FROM admissions'),
          'all_icu_stays':scalar('SELECT count(*) n FROM icustays'),
          'persons_in_icu_table':scalar('SELECT count(DISTINCT subject_id) n FROM icustays'),
          'hospital_admissions_in_icu_table':scalar('SELECT count(DISTINCT hadm_id) n FROM icustays')}
        q.c.execute('CREATE TEMP TABLE flow_raw AS SELECT stay_id stay,subject_id person,hadm_id encounter FROM icustays')
        prev=stage('linked','Successful patient and hospital-admission linkage','flow_raw','EXISTS(SELECT 1 FROM linked x WHERE x.stay=flow_raw.stay)')
        assert scalar(f'SELECT count(*) n FROM {prev}')==scalar('SELECT count(*) n FROM linked')
        prev=stage('first','First recorded ICU stay per hospital admission','linked','first_rank=1')
        prev=stage('adult','Adult age rule',prev,'age>=18')
        prev=stage('times_present','Parseable ICU and hospital entry/exit timestamps',prev,'t0 IS NOT NULL AND tout IS NOT NULL AND admit IS NOT NULL AND discharge IS NOT NULL')
        prev=stage('entry_after_admit','ICU entry not before hospital admission',prev,'admit<=t0')
        prev=stage('unit_duration','ICU exit not before ICU entry',prev,'t0<=tout')
        prev=stage('hospital_overlap','ICU entry not after hospital discharge',prev,'t0<=discharge',target='flow_base')
        base=prev
        prev=stage('cabg_code','At least one exact reviewed CABG code in the same hospital admission',prev,
            'EXISTS(SELECT 1 FROM procedures_icd p JOIN allow_codes a ON p.icd_code=a.code AND p.icd_version=a.version WHERE p.subject_id='+prev+'.person AND p.hadm_id='+prev+'.encounter)')
        prev=stage('cabg_window','At least one reviewed CABG date on ICU-entry date or preceding date',prev,
            'EXISTS(SELECT 1 FROM reviewed_dates r WHERE r.stay='+prev+'.stay)')
        prev=stage('cabg_single_date','Exactly one distinct qualifying CABG date within the two-calendar-date window',prev,
            'EXISTS(SELECT 1 FROM reviewed_dates r WHERE r.stay='+prev+'.stay AND r.n_dates=1)',target='flow_F')
    else:
        inventory={
          'all_unit_stays':scalar('SELECT count(*) n FROM patient'),
          'all_persons':scalar("SELECT count(DISTINCT nullif(trim(uniquepid),'')) n FROM patient"),
          'all_hospital_admissions':scalar("SELECT count(DISTINCT nullif(trim(patienthealthsystemstayid),'')) n FROM patient")}
        prev=stage('first','Recorded first unit visit per hospital admission','linked','visit=1')
        prev=stage('adult','Adult age rule including topcoded >89',prev,'age>=18')
        prev=stage('identifiers','Nonempty stay, person and hospital-admission keys',prev,'stay IS NOT NULL AND person IS NOT NULL AND encounter IS NOT NULL')
        prev=stage('finite_offsets','Finite hospital-admission and discharge plus unit-discharge offsets',prev,'isfinite(admit_h) AND isfinite(unit_end_h) AND isfinite(hospital_end_h)')
        prev=stage('entry_after_admit','Hospital admission at or before unit entry',prev,'admit_h<=0')
        prev=stage('unit_duration','Unit discharge at or after entry',prev,'unit_end_h>=0')
        prev=stage('hospital_overlap','Hospital discharge at or after unit entry',prev,'hospital_end_h>=0',target='flow_base')
        base=prev
        prev=stage('or_source','Admission source Operating Room, Recovery Room or PACU',prev,"unitadmitsource IN ('Operating Room','Recovery Room','PACU')")
        prev=stage('cabg_path','At least one exact reviewed operative CABG admission-diagnosis path',prev,
             'EXISTS(SELECT 1 FROM admissiondx d JOIN allow_paths a ON d.admitdxpath=a.path WHERE d.patientunitstayid='+prev+'.stay)',target='flow_F')
    def sets_equal(left,right):
        # Set membership is compared inside DuckDB; only the discrepancy count leaves SQL.
        return scalar(f'''SELECT count(*) n FROM (
          (SELECT stay FROM {left} EXCEPT SELECT stay FROM {right}) UNION ALL
          (SELECT stay FROM {right} EXCEPT SELECT stay FROM {left}))''')==0
    assert sets_equal(base,'base'), 'Reconstructed base differs from frozen base'
    assert sets_equal('flow_F','flags'), 'Reconstructed F differs from frozen F'
    prev=stage('primary','No recorded chronic renal evidence under source-specific frozen rules','flow_F',
        'NOT EXISTS(SELECT 1 FROM renal_flags r WHERE r.stay=flow_F.stay AND (r.prior_chronic OR r.index_eskd OR r.index_dialysis_status))',target='flow_N')
    prior=json.loads(Path(a.previous_result).read_text(encoding='utf-8'))
    assert scalar('SELECT count(*) n FROM flow_F')==prior['F']
    assert scalar('SELECT count(*) n FROM flow_N')==prior['N']
    assert scalar('SELECT count(DISTINCT person) n FROM flow_N')==prior['variants']['main_168h']['bootstrap']['person_count']
    previous_hash={r['table']:r['sha256'] for r in prior['source_files']}
    for item in q.r['inputs']:
        assert previous_hash[item['table']]==item['sha256'],'Source hash differs from final prior analysis'
    unchanged=all((p.stat().st_size,p.stat().st_mtime_ns)==stat for p,stat in q.stats.items())
    assert unchanged
    assert frozen_start=={n:sha(fdir/n) for n in frozen_names}
    assert script_start==sha(Path(__file__))
    result={'status':'PASS','source':a.source,'created_utc':datetime.now(timezone.utc).isoformat(),
      'scope':'Reporting completion only; existing selection rules and final cohort unchanged',
      'source_inventory':inventory,'inventory_note':'These source counts have different units and are not successive subtraction steps.',
      'flow':flow,'validation':{'stepwise_conservation':True,'base_stay_set_equals_frozen_base':True,'F_stay_set_equals_frozen_F':True,
         'F_and_N_match_previous_formal_analysis':True,'source_hashes_match_previous':True,'source_files_size_mtime_unchanged':unchanged},
      'source_files':q.r['inputs'],'discovered_required_columns':{k:q.columns[k] for k in sorted(q.bound)},
      'schema_discovered_before_queries':True,'frozen_code_hashes':frozen_start,'script_sha256':script_start,
      'previous_result_path':a.previous_result,'previous_result_sha256':sha(Path(a.previous_result)),
      'patient_rows_exported':False,'clinical_network_calls':False,'clinical_tables_modified':False,
      'privacy':'Internal aggregate flow. Do not publish a 1-9 cell or derivable linked small exclusions. Public collapsed steps provided separately.',
      'elapsed_seconds':round(time.time()-q.t,2),
      'notes':[
         'A hospital admission may differ from a person; recurrent admissions are retained.',
         'Later ICU/unit records are not substituted if the first record fails eligibility.',
         'MIMIC requires exactly one qualifying CABG date inside the two-date window, not exactly one procedure date anywhere in the hospital admission.',
         'Recorded renal history/index status is retrospective evidence, not adjudicated disease absence or an onset timestamp.',
         'No creatinine measurements, outcome comparisons, bootstrap estimates or models are recalculated in this flow-only audit.'
      ]}
    if a.source=='eicu':result['unit_order_quality']=q.r['recorded_unit_order_check']
    # Release coarse scientifically meaningful stages; each block was directly re-counted.
    stages=[('source','All ICU records' if a.source=='mimic' else 'All unit records',None),
      ('linked','Successful source linkage','flow_linked')] if a.source=='mimic' else [('source','All unit records',None)]
    stages += [('first','First recorded ICU/unit per hospital admission','flow_first'),
               ('adult_valid','Adult records with valid required keys and observation boundaries','flow_base'),
               ('cabg','Reviewed CABG-related candidate stays F','flow_F'),
               ('primary','Primary stays N after recorded chronic renal exclusion','flow_N')]
    pub=[];previous_n=inventory['all_icu_stays' if a.source=='mimic' else 'all_unit_stays']
    previous_relation='flow_raw' if a.source=='mimic' else 'linked'
    for sid,label,relation in stages:
        if relation is None:n=previous_n;ex=0
        else:
            n=scalar(f'SELECT count(*) n FROM {relation}')
            ex=scalar(f'SELECT count(*) n FROM {previous_relation} p WHERE NOT EXISTS(SELECT 1 FROM {relation} n WHERE n.stay=p.stay)')
            assert ex+n==previous_n
        assert not 0<ex<10,'Coarsened flow still discloses a rare exclusion; further linkage-aware grouping needed'
        pub.append({'stage':sid,'label':label,'unit':'ICU/unit stays','n_before':previous_n,'n_excluded':ex,'n_after':n})
        if relation:previous_relation=relation
        previous_n=n
    result['public_collapsed_flow']=pub
    if a.source=='mimic':
        detailed=[('source','All ICU records',None),('linked','Successful patient and hospital-admission linkage','flow_linked'),
          ('first','First recorded ICU stay per hospital admission','flow_first'),('adult','Adult age rule','flow_adult'),
          ('times_present','Parseable ICU and hospital entry/exit timestamps','flow_times_present'),
          ('entry_after_admit','ICU entry not before hospital admission','flow_entry_after_admit'),
          ('unit_duration','ICU exit not before ICU entry','flow_unit_duration'),
          ('hospital_overlap','ICU entry not after hospital discharge','flow_base'),
          ('cabg_code','At least one exact reviewed CABG code in the same hospital admission','flow_cabg_code'),
          ('cabg_date_combined','Exactly one distinct reviewed CABG date within the ICU-entry/preceding-calendar-date window','flow_F'),
          ('primary','No recorded chronic renal evidence under frozen source-specific rules','flow_N')]
    else:
        detailed=[('source','All unit records',None),('first','Recorded unitvisitnumber = 1','flow_first'),
          ('adult','Adult age rule including topcoded >89','flow_adult'),
          ('identifiers','Nonempty stay, person and hospital-admission keys','flow_identifiers'),
          ('finite_offsets','Finite hospital-admission and discharge plus unit-discharge offsets','flow_finite_offsets'),
          ('entry_after_admit','Hospital admission at or before unit entry','flow_entry_after_admit'),
          ('discharge_combined','Both unit and hospital discharge at or after unit entry','flow_base'),
          ('or_source','Admission source Operating Room, Recovery Room or PACU','flow_or_source'),
          ('cabg_path','At least one exact reviewed operative CABG admission-diagnosis path','flow_F'),
          ('primary','No recorded chronic renal evidence under frozen source-specific rules','flow_N')]
    pubdetail=[];previous_n=inventory['all_icu_stays' if a.source=='mimic' else 'all_unit_stays']
    previous_relation='flow_raw' if a.source=='mimic' else 'linked'
    for sid,label,relation in detailed:
        if relation is None:n=previous_n;ex=0
        else:
            n=scalar(f'SELECT count(*) n FROM {relation}')
            ex=scalar(f'SELECT count(*) n FROM {previous_relation} p WHERE NOT EXISTS(SELECT 1 FROM {relation} n WHERE n.stay=p.stay)')
            assert ex+n==previous_n
        assert not 0<ex<10,'Public detailed flow contains a rare exclusion'
        pubdetail.append({'stage':sid,'label':label,'unit':'ICU/unit stays','n_before':previous_n,'n_excluded':ex,'n_after':n})
        if relation:previous_relation=relation
        previous_n=n
    result['public_detailed_flow']=pubdetail
    out=Path(a.out);(out/'flow_internal.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    public={'status':'PASS','source':a.source,'source_inventory':inventory,'inventory_note':result['inventory_note'],
      'flow':pub,'detailed_flow':pubdetail,'validation':result['validation'],'notes':result['notes'],
         'suppression_note':'Detailed public flow combines adjacent CABG-date checks in MIMIC and discharge-sign checks in eICU. Withheld intermediate nodes must not be published alongside the grouped flow; their differences would disclose small exclusions.'}
    if a.source=='eicu':public['first_unit_availability']=q.r['recorded_unit_order_check']
    (out/'flow_public.json').write_text(json.dumps(public,ensure_ascii=False,indent=2),encoding='utf-8')
    (HERE/f'flow_{a.source}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'source':a.source,'status':'PASS','source_inventory':inventory,'public_flow':pub,'internal_output':str(out/'flow_internal.json'),'elapsed_seconds':result['elapsed_seconds']},ensure_ascii=False))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--source',choices=['mimic','eicu'],required=True);ap.add_argument('--root',required=True);ap.add_argument('--out',required=True)
    ap.add_argument('--dependency-dir',required=True);ap.add_argument('--frozen-dir',default=str(FROZEN));ap.add_argument('--previous-result',required=True)
    ap.add_argument('--memory-limit',default='4GB');ap.add_argument('--authorized-local-data',action='store_true');a=ap.parse_args()
    if not a.authorized_local_data:ap.error('Explicit local-data authorization flag required.')
    try:audit(a)
    except Exception as exc:
        # Do not echo parser context or raw values from restricted CSVs.
        print(json.dumps({'status':'FAILED','error_type':type(exc).__name__,'message':'Inspect the local audit implementation; clinical values are withheld.'}),file=sys.stderr)
        raise SystemExit(1)
