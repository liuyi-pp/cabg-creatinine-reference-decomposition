"""Extract internal aggregate counts for independent R checks; no patient rows."""
from pathlib import Path
import argparse,csv,json
p=argparse.ArgumentParser();p.add_argument('--inputs',nargs='+',required=True);p.add_argument('--out',required=True);a=p.parse_args()
target=Path(a.out)
if target.exists():raise SystemExit('Use a new output path.')
fields=['source','scenario','N','EA','EB','C','YA','YB','YA_own_in_C','YB_own_in_C','YAJ','YBJ','refA','refB']
rows=[]
for filename in a.inputs:
    data=json.loads(Path(filename).read_text(encoding='utf-8'))
    for scenario,v in data['variants'].items():rows.append({'source':data['source'],'scenario':scenario,**{k:v['counts'][k] for k in fields[2:]}})
target.parent.mkdir(exist_ok=True,parents=True)
with target.open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
print('Aggregate scenario rows:',len(rows),'; internal validation only; review small cells before release.')
