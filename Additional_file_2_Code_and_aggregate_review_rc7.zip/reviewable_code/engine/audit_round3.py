"""Local authorized CABG code verification and three-state creatinine-change screening.

This does not estimate AKI incidence, stage complete KDIGO, or infer surgery-end time.
No clinical rows, identifiers, credentials or raw reader errors are exported.
"""
from pathlib import Path
from collections import Counter,defaultdict
from decimal import Decimal
import argparse,csv,hashlib,json,sys,time
from audit_round2 import Audit,lit,ident,ts,number

HERE=Path(__file__).resolve().parent
H48=48*3600;D7=168*3600
POS='positive_recorded_criterion';NEG='no_positive_in_observed_comparisons';UNK='not_evaluable'
CONTRACT={
    'version':'0.3-exploratory-screen','population':'Reviewed CABG-related first recorded ICU/unit admission; all CABG modalities and combined surgery retained.',
    'time_zero':'Recorded ICU/unit entry, not surgery completion',
    'observation':'Same-admission pre-entry7days plus [0,168h) indexed ICU/unit follow-up, truncated at min(unit exit,hospital discharge).',
    'reference_A':'Latest nonconflicting measurement in [-48h,0).',
    'reference_B':'Minimum nonconflicting measurement in [-168h,0); most recent timestamp if tied.',
    'criteria':'At each actual comparison: rise>=0.3mg/dl when 0<dt<=48h OR value>=1.5*reference when 0<dt<=168h.',
    'common_comparison':'Same patients and same post-entry samples with both reference ages<=168h. Absolute-rise criterion enabled only if both ages<=48h; ratio enabled for both.',
    'monotonicity':'On shared comparison conditions B reference<=A reference by construction; A-positive/B-negative must be0. More B positives do not establish better accuracy or clinical benefit.',
    'rolling_screen':'Compare each target with all earlier nonconflicting observations in actual rolling48h/168h. Pre-entry and post-entry targets reported separately.',
    'duplicates':'Collapse identical values at identical timestamp; exclude only conflicting timestamps, retain other observations and the patient.',
    'numeric':'mg/dl rounded to decimal6places; Decimal threshold arithmetic. Timestamps verified integral seconds before conversion.',
    'states':[POS,NEG,UNK],
    'negative_state_limit':'No positive observed is not no AKI, complete follow-up, or proof of normal baseline.',
    'renal_status':'Prior/index chronic evidence and RRT documentation separately flagged. No treatment-time censoring or automatic stage3; late documentation not used to exclude primary cohort.',
    'no_chronic_flag_stratum':'Exploratory retrospective evidence-negative stratum, not proven absence of chronic disease or an entry-time exclusion.',
    'no_imputation':True,'AKI_incidence_estimated':False,'clinical_row_export':False,
}

def result_state(positives,comparisons):return POS if positives else NEG if comparisons else UNK
def criterion(target,reference,absolute_allowed=True,ratio_allowed=True):
    dt=target[0]-reference[0]
    return (absolute_allowed and 0<dt<=H48 and target[1]-reference[1]>=Decimal('0.3')) or (ratio_allowed and 0<dt<=D7 and target[1]>=reference[1]*Decimal('1.5'))

def fixed_screen(post,ref):
    if ref is None:return UNK
    valid=[x for x in post if 0<x[0]-ref[0]<=D7]
    return result_state(any(criterion(x,ref) for x in valid),len(valid))

def rolling_screen(observations,post):
    valid=positive=False
    for i,target in enumerate(observations):
        if (target[0]>=0)!=post:continue
        refs=[ref for ref in observations[:i] if 0<target[0]-ref[0]<=D7]
        valid=valid or bool(refs)
        positive=positive or any(criterion(target,ref) for ref in refs)
    return result_state(positive,valid)

class Round3(Audit):
    def __init__(self,a,duckdb):
        super().__init__(a,duckdb)
        self.book=json.loads(Path(a.codebook).read_text(encoding='utf-8-sig'))
        self.renal=json.loads(Path(a.renal_rules).read_text(encoding='utf-8-sig'))
        self.r.update({'scope':'Reviewed CABG and renal-status evidence; exploratory three-state SCr-change screening, not adjudicated AKI.',
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'core_script_sha256':hashlib.sha256((HERE/'audit_round2.py').read_bytes()).hexdigest(),
            'codebook_sha256':hashlib.sha256(Path(a.codebook).read_bytes()).hexdigest(),
            'renal_rules_sha256':hashlib.sha256(Path(a.renal_rules).read_bytes()).hexdigest(),
            'contract':CONTRACT,'stage':'phenotype_screen','cohort_coverage':[]})
        (self.out/'screening_contract.json').write_text(json.dumps(CONTRACT,ensure_ascii=False,indent=2),encoding='utf-8')

    def table(self,name,required):
        if name not in self.columns or any(c not in self.columns[name] for c in required):raise ValueError('Missing required table or field: '+name)
        if name in self.bound:return
        path,delim=self.files[name];s=path.stat();h=hashlib.sha256()
        with path.open('rb') as f:
            for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
        self.stats[path]=(s.st_size,s.st_mtime_ns)
        self.r['inputs'].append({'table':name,'path':str(path),'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'sha256':h.hexdigest()})
        columns=', '.join(ident(actual)+' AS '+ident(c) for c,actual in self.columns[name].items())
        self.c.execute(f'''CREATE TEMP VIEW {ident(name)} AS SELECT {columns} FROM read_csv({lit(path)},delim={lit(delim)},header=true,all_varchar=true,quote='"',escape='"',strict_mode=true,ignore_errors=false)''')
        self.bound.add(name)

    def reviewed_cohort(self):
        if self.a.source=='mimic':
            self.mimic()
            self.c.execute('CREATE TEMP TABLE old_cohort AS SELECT stay FROM flags WHERE cabg_day')
            self.c.execute('CREATE TEMP TABLE allow_codes(code VARCHAR,version VARCHAR,title VARCHAR)')
            self.c.executemany('INSERT INTO allow_codes VALUES (?,?,?)',[(r['icd_code'],str(r['icd_version']),r['long_title']) for r in self.book['mimic_include']])
            found=self.rows('SELECT count(*) n FROM allow_codes a WHERE EXISTS(SELECT 1 FROM d_icd_procedures d WHERE d.icd_code=a.code AND d.icd_version=a.version AND d.long_title=a.title)')[0]['n']
            if found!=len(self.book['mimic_include']):raise ValueError('CABG codebook does not match actual local dictionary.')
            self.c.execute('''CREATE TEMP TABLE reviewed_dates AS SELECT b.stay,count(DISTINCT try_cast(p.chartdate AS DATE)) n_dates,max(try_cast(p.chartdate AS DATE)) cabg_date
                FROM base b JOIN procedures_icd p ON b.person=p.subject_id AND b.encounter=p.hadm_id
                JOIN allow_codes a ON p.icd_code=a.code AND p.icd_version=a.version
                WHERE try_cast(p.chartdate AS DATE) BETWEEN cast(b.t0 AS DATE)-1 AND cast(b.t0 AS DATE) GROUP BY b.stay''')
            self.c.execute('''CREATE TEMP TABLE new_flags AS SELECT f.* EXCLUDE(cabg_day,cabg_date),true cabg_day,r.cabg_date
                FROM flags f JOIN reviewed_dates r USING(stay) WHERE r.n_dates=1''')
            self.r['reviewed_code_utilization']=self.rows('''SELECT a.code,a.version,a.title,count(*) n_code_rows,count(DISTINCT f.stay) n_stays
                FROM new_flags f JOIN procedures_icd p ON f.person=p.subject_id AND f.encounter=p.hadm_id AND try_cast(p.chartdate AS DATE)=f.cabg_date
                JOIN allow_codes a ON p.icd_code=a.code AND p.icd_version=a.version GROUP BY 1,2,3 ORDER BY n_stays DESC''')
        else:
            self.eicu()
            self.c.execute('CREATE TEMP TABLE old_cohort AS SELECT stay FROM flags WHERE or_pacu AND cabg_any')
            self.c.execute('CREATE TEMP TABLE allow_paths(path VARCHAR,subgroup VARCHAR)')
            self.c.executemany('INSERT INTO allow_paths VALUES (?,?)',[(r['admitdxpath'],r['group']) for r in self.book['eicu_include']])
            found=self.rows('SELECT count(*) n FROM allow_paths a WHERE EXISTS(SELECT 1 FROM admissiondx d WHERE d.admitdxpath=a.path)')[0]['n']
            if found!=len(self.book['eicu_include']):raise ValueError('CABG paths not found in local admission diagnoses.')
            self.c.execute('''CREATE TEMP TABLE new_flags AS SELECT f.* FROM flags f WHERE or_pacu
                AND EXISTS(SELECT 1 FROM admissiondx d JOIN allow_paths a ON d.admitdxpath=a.path WHERE d.patientunitstayid=f.stay)''')
            self.r['reviewed_diagnosis_subgroups']=self.rows('''SELECT a.subgroup,count(DISTINCT f.stay) n_stays FROM new_flags f
                JOIN admissiondx d ON f.stay=d.patientunitstayid JOIN allow_paths a ON d.admitdxpath=a.path GROUP BY 1''')
        self.r['cohort_flow']=self.rows('''SELECT (SELECT count(*) FROM old_cohort) round2_lexical_candidates,count(*) reviewed_cabg_candidates,
            count(DISTINCT person) n_persons,count(DISTINCT encounter) n_encounters,
            count(*) FILTER(WHERE strict_bounds) strict_time_bounds,
            (SELECT count(*) FROM old_cohort o WHERE NOT EXISTS(SELECT 1 FROM new_flags n WHERE n.stay=o.stay)) removed_after_review,
            count(*) FILTER(WHERE NOT EXISTS(SELECT 1 FROM old_cohort o WHERE o.stay=new_flags.stay)) added_after_review FROM new_flags''')[0]
        self.c.execute('DROP TABLE flags');self.c.execute('ALTER TABLE new_flags RENAME TO flags')

    def renal_flags(self):
        if self.a.source=='mimic':
            self.table('diagnoses_icd',['subject_id','hadm_id','icd_code','icd_version'])
            self.table('d_icd_diagnoses',['icd_code','icd_version','long_title'])
            self.c.execute('CREATE TEMP TABLE renal_codes(code VARCHAR,version VARCHAR,category VARCHAR,title VARCHAR)')
            for category,entries in self.renal['mimic_chronic_selectors'].items():
                if isinstance(entries,list):
                    self.c.executemany('INSERT INTO renal_codes VALUES (?,?,?,?)',[(r['icd_code'],r['icd_version'],category,r['actual_local_title']) for r in entries])
            missing=self.rows('SELECT count(*) n FROM renal_codes r WHERE NOT EXISTS(SELECT 1 FROM d_icd_diagnoses d WHERE d.icd_code=r.code AND d.icd_version=r.version AND d.long_title=r.title)')[0]['n']
            if missing:raise ValueError('Renal code dictionary validation failed.')
            self.c.execute('''CREATE TEMP TABLE renal_diagnoses AS SELECT d.subject_id person,d.hadm_id encounter,r.category FROM diagnoses_icd d JOIN renal_codes r ON d.icd_code=r.code AND d.icd_version=r.version''')
            rrt=self.renal['mimic_rrt_selectors']['specific_documented_therapy_items']
            for item in rrt:
                if self.rows(f"SELECT count(*) n FROM d_items WHERE itemid={lit(item['itemid'])} AND label={lit(item['label'])} AND linksto='procedureevents'")[0]['n']!=1:raise ValueError('RRT dictionary mismatch.')
            ids=','.join(lit(i['itemid']) for i in rrt)
            self.c.execute(f'''CREATE TEMP TABLE rrt_records AS SELECT f.stay,p.statusdescription,{ts('p.starttime')} starts,{ts('p.endtime')} ends,
                f.t0,f.tout,f.admit,f.discharge FROM flags f JOIN procedureevents p ON f.stay=p.stay_id AND f.person=p.subject_id AND f.encounter=p.hadm_id
                WHERE p.itemid IN ({ids})''')
            self.r['rrt_documentation_quality']=self.rows('''SELECT statusdescription,count(*) n_records,
                count(*) FILTER(WHERE starts IS NULL OR ends IS NULL) missing_times,count(*) FILTER(WHERE ends<starts) reversed_times,
                count(*) FILTER(WHERE ends=starts) zero_duration,count(*) FILTER(WHERE starts<t0) starts_recorded_before_entry,
                count(*) FILTER(WHERE starts>=t0 AND starts<=least(tout,discharge)) starts_within_observation,
                count(*) FILTER(WHERE starts<admit OR ends>discharge) outside_hospital_bounds FROM rrt_records GROUP BY 1''')
            self.c.execute('''CREATE TEMP TABLE renal_flags AS SELECT f.stay,
                EXISTS(SELECT 1 FROM renal_diagnoses d JOIN admissions a ON d.encounter=a.hadm_id AND d.person=a.subject_id
                    WHERE d.person=f.person AND d.encounter<>f.encounter AND try_cast(a.dischtime AS TIMESTAMP)<f.admit
                    AND d.category IN ('documented_eskd_codes','documented_dialysis_status_codes')) prior_chronic,
                EXISTS(SELECT 1 FROM renal_diagnoses d WHERE d.person=f.person AND d.encounter=f.encounter AND d.category='documented_eskd_codes') index_eskd,
                EXISTS(SELECT 1 FROM renal_diagnoses d WHERE d.person=f.person AND d.encounter=f.encounter AND d.category='documented_dialysis_status_codes') index_dialysis_status,
                EXISTS(SELECT 1 FROM renal_diagnoses d WHERE d.person=f.person AND d.encounter=f.encounter AND d.category='ckd_stage5_separate_not_equivalent_to_dialysis') ckd5_separate,
                EXISTS(SELECT 1 FROM rrt_records r WHERE r.stay=f.stay) rrt_documented FROM flags f''')
        else:
            self.table('pasthistory',['patientunitstayid','pasthistorypath','pasthistoryvalue','pasthistoryoffset','pasthistoryenteredoffset'])
            self.table('diagnosis',['patientunitstayid','diagnosisstring','diagnosisoffset'])
            self.table('treatment',['patientunitstayid','treatmentstring','treatmentoffset'])
            self.table('apacheapsvar',['patientunitstayid','dialysis'])
            pairs=self.renal['eicu_chronic_selectors']['past_history_positive_pairs']
            cond=' OR '.join('(pasthistorypath='+lit(x['pasthistorypath'])+' AND pasthistoryvalue='+lit(x['pasthistoryvalue'])+')' for x in pairs)
            self.c.execute(f'''CREATE TEMP TABLE prior_history AS SELECT p.patientunitstayid stay,{number('p.pasthistoryoffset')} history_offset,
                {number('p.pasthistoryenteredoffset')} entered_offset FROM pasthistory p JOIN flags f ON p.patientunitstayid=f.stay WHERE {cond}''')
            esrd=lit(self.renal['eicu_chronic_selectors']['esrd_diagnosis_exact'])
            rrt=self.renal['eicu_rrt_selectors']; strings=rrt['specific_documented_therapy_exact_strings']+rrt['other_dialysis_treatment_documentation_exact_strings']
            self.c.execute(f'''CREATE TEMP TABLE rrt_records AS SELECT t.patientunitstayid stay,{number('t.treatmentoffset')} entered_offset,
                t.treatmentstring FROM treatment t JOIN flags f ON t.patientunitstayid=f.stay WHERE t.treatmentstring IN ({','.join(lit(s) for s in strings)})''')
            self.r['rrt_documentation_quality']=self.rows('''SELECT count(*) n_records,count(DISTINCT stay) n_stays,
                count(*) FILTER(WHERE entered_offset IS NULL OR NOT isfinite(entered_offset)) missing_offset,
                count(*) FILTER(WHERE entered_offset<=0) documented_by_entry,count(*) FILTER(WHERE entered_offset>0) documented_after_entry FROM rrt_records''')[0]
            self.r['prior_history_documentation']=self.rows('''SELECT count(DISTINCT stay) any_positive_history,
                count(DISTINCT stay) FILTER(WHERE entered_offset<=0) entered_by_entry,
                count(DISTINCT stay) FILTER(WHERE entered_offset>0) entered_after_entry,
                count(*) FILTER(WHERE entered_offset IS NULL OR NOT isfinite(entered_offset)) missing_entry_offset FROM prior_history''')[0]
            self.r['apache_dialysis_documentation']=self.rows('''SELECT a.dialysis,count(*) n_rows,count(DISTINCT f.stay) n_stays
                FROM flags f LEFT JOIN apacheapsvar a ON a.patientunitstayid=f.stay GROUP BY 1''')
            self.c.execute(f'''CREATE TEMP TABLE renal_flags AS SELECT f.stay,
                EXISTS(SELECT 1 FROM prior_history p WHERE p.stay=f.stay) prior_chronic,
                EXISTS(SELECT 1 FROM diagnosis d WHERE d.patientunitstayid=f.stay AND d.diagnosisstring={esrd}) index_eskd,
                false index_dialysis_status,false ckd5_separate,
                (EXISTS(SELECT 1 FROM rrt_records t WHERE t.stay=f.stay) OR EXISTS(SELECT 1 FROM apacheapsvar a WHERE a.patientunitstayid=f.stay AND try_cast(a.dialysis AS INTEGER)=1)) rrt_documented FROM flags f''')
        self.r['renal_flag_summary']=self.rows('''SELECT count(*) n_candidates,
            count(*) FILTER(WHERE prior_chronic) prior_chronic_documentation,
            count(*) FILTER(WHERE index_eskd) index_eskd_documentation,count(*) FILTER(WHERE index_dialysis_status) index_dialysis_status_documentation,
            count(*) FILTER(WHERE ckd5_separate) ckd5_separate,count(*) FILTER(WHERE prior_chronic OR index_eskd OR index_dialysis_status) any_chronic_status_evidence,
            count(*) FILTER(WHERE rrt_documented) rrt_documentation,
            count(*) FILTER(WHERE rrt_documented AND NOT (prior_chronic OR index_eskd OR index_dialysis_status)) rrt_without_chronic_evidence FROM renal_flags''')[0]
        if self.a.source=='eicu':
            self.r['renal_flag_summary']['index_dialysis_status_documentation']=None
            self.r['renal_flag_summary']['ckd5_separate']=None
            self.r['renal_flag_summary']['not_assessed']='Standalone current-admission dialysis-status code and CKD5 not assessed here; internal neutral flags do not mean absent disease.'

    def screen(self):
        self.creatinine()
        fractional=self.rows('SELECT count(*) n FROM usable WHERE abs(h*3600-round(h*3600))>0.00001')[0]['n']
        if fractional:raise ValueError('Subsecond timestamps require an explicit time-unit revision.')
        self.c.execute('''CREATE TEMP TABLE all_times AS SELECT stay,cast(round(h*3600) AS BIGINT) t,
            min(cast(mgdl AS DECIMAL(18,6))) v,count(*) n_rows,count(DISTINCT cast(mgdl AS DECIMAL(18,6))) n_values
            FROM usable WHERE h<0 OR h<=end_h GROUP BY 1,2''')
        self.r['duplicate_time_qc']=self.rows('''SELECT count(*) n_unique_timepoints,sum(n_rows) n_rows,
            sum(n_rows-1) extra_same_time_rows,count(*) FILTER(WHERE n_values>1) conflicting_timepoints,
            count(DISTINCT stay) FILTER(WHERE n_values>1) stays_with_conflict FROM all_times''')[0]
        self.c.execute('CREATE TEMP TABLE observations AS SELECT stay,t,v FROM all_times WHERE n_values=1')
        self.r['creatinine_range_qc']=self.rows('SELECT count(*) FILTER(WHERE v>20) observations_over20mgdl,count(DISTINCT stay) FILTER(WHERE v>20) stays_over20mgdl FROM observations')[0]
        values=defaultdict(list)
        for stay,t,v in self.c.execute('SELECT stay,t,v FROM observations ORDER BY stay,t').fetchall():values[stay].append((t,v))
        flags=self.rows('SELECT * FROM renal_flags')
        aggregate=defaultdict(Counter)
        for f in flags:
            obs=values.get(f['stay'],[]);pre=[x for x in obs if x[0]<0];post=[x for x in obs if x[0]>=0]
            last=[x for x in pre if x[0]>=-H48];A=last[-1] if last else None
            B=min(pre,key=lambda x:(x[1],-x[0])) if pre else None
            a=fixed_screen(post,A);b=fixed_screen(post,B)
            rp=rolling_screen(obs,True);re=rolling_screen(obs,False)
            common=[x for x in post if A is not None and B is not None and 0<x[0]-A[0]<=D7 and 0<x[0]-B[0]<=D7]
            apos=bpos=False
            for target in common:
                absolute=target[0]-A[0]<=H48 and target[0]-B[0]<=H48
                apos=apos or criterion(target,A,absolute_allowed=absolute)
                bpos=bpos or criterion(target,B,absolute_allowed=absolute)
            chronic=f['prior_chronic'] or f['index_eskd'] or f['index_dialysis_status']
            groups=['all_reviewed_cabg','documented_chronic_status' if chronic else 'no_documented_chronic_status']
            if f['rrt_documented']:groups.append('rrt_documented')
            for group in groups:
                c=aggregate[group];c['n_stays']+=1;c['has_reference_A']+=A is not None;c['has_reference_B']+=B is not None
                c['has_post_entry_observation']+=bool(post);c['A_'+a]+=1;c['B_'+b]+=1;c['rolling_post_'+rp]+=1;c['rolling_pre_'+re]+=1
                c['post_positive_with_pre_positive']+=rp==POS and re==POS
                c['post_positive_with_pre_not_evaluable']+=rp==POS and re==UNK
                c['post_positive_with_pre_no_positive']+=rp==POS and re==NEG
                c['common_evaluable']+=bool(common)
                if common:c['common_A'+str(int(apos))+'_B'+str(int(bpos))]+=1
        self.r['screening_counts']=[{'stratum':k,**dict(v)} for k,v in aggregate.items()]
        # Independent SQL on real observations validates the common-time comparison and rolling flags.
        self.c.execute('''CREATE TEMP TABLE refA AS SELECT stay,t,v FROM observations WHERE t>=-172800 AND t<0
            QUALIFY row_number() OVER(PARTITION BY stay ORDER BY t DESC)=1''')
        self.c.execute('''CREATE TEMP TABLE refB AS SELECT stay,t,v FROM observations WHERE t>=-604800 AND t<0
            QUALIFY row_number() OVER(PARTITION BY stay ORDER BY v ASC,t DESC)=1''')
        common_sql=self.rows('''WITH comparisons AS (SELECT o.stay,
            bool_or(o.v>=a.v*1.5 OR (o.t-a.t<=172800 AND o.t-b.t<=172800 AND o.v-a.v>=0.3)) ap,
            bool_or(o.v>=b.v*1.5 OR (o.t-a.t<=172800 AND o.t-b.t<=172800 AND o.v-b.v>=0.3)) bp
            FROM observations o JOIN refA a USING(stay) JOIN refB b USING(stay)
            WHERE o.t>=0 AND o.t-a.t BETWEEN 1 AND 604800 AND o.t-b.t BETWEEN 1 AND 604800 GROUP BY o.stay)
            SELECT count(*) n,count(*) FILTER(WHERE ap AND bp) both_positive,count(*) FILTER(WHERE ap AND NOT bp) A_only,
            count(*) FILTER(WHERE NOT ap AND bp) B_only,count(*) FILTER(WHERE NOT ap AND NOT bp) neither_positive FROM comparisons''')[0]
        c=aggregate['all_reviewed_cabg']
        for q,k in [('n','common_evaluable'),('both_positive','common_A1_B1'),('A_only','common_A1_B0'),('B_only','common_A0_B1'),('neither_positive','common_A0_B0')]:
            if common_sql[q]!=c[k]:raise ValueError('Common-time SQL validation failed.')
        rolling_sql=self.rows('''WITH comparisons AS (SELECT o.stay,o.t>=0 post,
            bool_or(o.v>=p.v*1.5 OR (o.t-p.t<=172800 AND o.v-p.v>=0.3)) positive
            FROM observations o JOIN observations p ON o.stay=p.stay AND o.t-p.t BETWEEN 1 AND 604800 GROUP BY o.stay,post)
            SELECT post,count(*) evaluable,count(*) FILTER(WHERE positive) n_positive FROM comparisons GROUP BY post''')
        for row in rolling_sql:
            prefix='rolling_post_' if row['post'] else 'rolling_pre_'
            if row['n_positive']!=c[prefix+POS] or row['evaluable']!=c[prefix+POS]+c[prefix+NEG]:raise ValueError('Rolling-screen SQL validation failed.')
        self.r['calculation_validation']={'independent_SQL_common_time':common_sql,'independent_SQL_rolling':rolling_sql,'matched_Python_counts':True,'synthetic_patients_used':False}
        for group,c in aggregate.items():
            for prefix in ['A_','B_','rolling_pre_','rolling_post_']:
                for state in [POS,NEG,UNK]:c.setdefault(prefix+state,0)
            for a in [0,1]:
                for b in [0,1]:c.setdefault('common_A'+str(a)+'_B'+str(b),0)
            if c['common_A1_B0']!=0:raise ValueError('Reference monotonicity invariant failed.')
            for prefix in ['A_','B_','rolling_pre_','rolling_post_']:
                if sum(c[prefix+s] for s in [POS,NEG,UNK])!=c['n_stays']:raise ValueError('State denominator mismatch.')
            if sum(c['common_A'+str(a)+'_B'+str(b)] for a in [0,1] for b in [0,1])!=c['common_evaluable']:raise ValueError('Common denominator mismatch.')
        self.r['screening_counts']=[{'stratum':k,**dict(v)} for k,v in aggregate.items()]
        self.r['limitation']='All screening counts are descriptive signals from recorded SCr comparisons. No full KDIGO diagnosis, incident postoperative AKI, gold-standard accuracy, effect estimate or model was produced. RRT absence and no chronic flag are not proven negatives.'

    def save3(self):
        self.r['elapsed_seconds']=round(time.time()-self.t,3)
        (self.out/'audit_round3.json').write_text(json.dumps(self.r,ensure_ascii=False,indent=2),encoding='utf-8')
        rows=self.r.get('screening_counts',[])
        if rows:
            keys=list(dict.fromkeys(k for row in rows for k in row))
            with (self.out/'screening_counts.csv').open('w',encoding='utf-8-sig',newline='') as f:
                w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
                for row in rows:w.writerow({k:row.get(k,0) for k in keys})

    def run3(self):
        try:
            print(self.a.source+': verifying CABG codes and renal documentation.',flush=True)
            self.reviewed_cohort();self.renal_flags();self.save3()
            print(self.a.source+': checking actual SCr references and timed comparison signals.',flush=True)
            self.screen()
            for path,before in self.stats.items():
                s=path.stat()
                if (s.st_size,s.st_mtime_ns)!=before:raise ValueError('Source changed during run.')
            self.r['status']='completed';self.save3();print(self.a.source+': completed; independent calculations agree.',flush=True)
        except Exception as exc:
            self.r['status']='failed';self.r['error_type']=type(exc).__name__;self.save3()
            print(self.a.source+': failed with '+type(exc).__name__+'; raw clinical reader messages withheld.',flush=True)
            raise SystemExit(2)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',choices=['mimic','eicu'],required=True);p.add_argument('--root',required=True);p.add_argument('--out',required=True)
    p.add_argument('--dependency-dir',required=True);p.add_argument('--memory-limit',default='4GB')
    p.add_argument('--codebook',default=str(HERE/'cabg_review.json'));p.add_argument('--renal-rules',default=str(HERE/'renal_rules.json'))
    p.add_argument('--authorized-local-data',action='store_true');a=p.parse_args();a.stage='full'
    if not a.authorized_local_data:p.error('Only use authorized local data with the explicit authorization flag.')
    sys.path.insert(0,str(Path(a.dependency_dir).resolve(strict=True)));import duckdb
    Round3(a,duckdb).run3()

if __name__=='__main__':main()
