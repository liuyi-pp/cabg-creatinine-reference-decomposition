"""Authorized local v1.0 ascertainment analysis. Clinical records remain in memory.
No clinical network calls, imputation, predictive models, or patient-level exports.
"""
from pathlib import Path
from collections import defaultdict,Counter
from decimal import Decimal
import argparse,hashlib,json,sys,time,statistics,traceback
from audit_round3 import Round3,rolling_screen,POS,NEG,UNK,H48,D7
from audit_round2 import ts,trim,lit

HERE=Path(__file__).resolve().parent

def make_record(meta,obs,horizon=168,death_cap=True):
    pre=[x for x in obs if x[0]<0]
    end_seconds=min(meta['end_seconds'],horizon*3600)
    if death_cap and meta['death_valid']:end_seconds=min(end_seconds,meta['death_seconds'])
    end=end_seconds/3600
    post=[x for x in obs if 0<=x[0]<horizon*3600 and x[0]<=end_seconds]
    near=[x for x in pre if x[0]>=-H48]
    a=near[-1] if near else None;b=min(pre,key=lambda x:(x[1],-x[0])) if pre else None
    def comparisons(ref):
        out={}
        if ref is None:return out
        for t,v in post:
            dt=t-ref[0]
            if 0<dt<=D7:out[(t,'ratio')]=v>=ref[1]*Decimal('1.5')
            if 0<dt<=H48:out[(t,'absolute')]=v-ref[1]>=Decimal('0.3')
        return out
    ca,cb=comparisons(a),comparisons(b);common=ca.keys()&cb.keys()
    if a is not None and b is not None:assert b[1]<=a[1],'Reference monotonicity'
    ya,yb=any(ca.values()),any(cb.values())
    yaj=any(ca[k] for k in common) if common else None
    ybj=any(cb[k] for k in common) if common else None
    if common:assert not(yaj and not ybj) and ya>=yaj and yb>=ybj,'Comparison invariant'
    def reason(ref,comp):
        if comp:return None
        if ref is None:return 'reference_unavailable'
        if not post:return 'no_valid_followup'
        return 'no_time_valid_pair'
    age=meta['age_descriptive'];agegroup=meta['age_group']
    return {'stay':meta['stay'],'person':meta['person'],'hospital':meta['hospital'],
      'age':age,'age_group':agegroup,'age_topcoded':meta['age_topcoded'],'sex':meta['sex'],
      'admit_lag':-meta['admit_h'],'EA':bool(ca),'EB':bool(cb),'C':bool(common),
      'YA':ya,'YB':yb,'YAJ':yaj,'YBJ':ybj,'refA':a is not None,'refB':b is not None,
      'no_reasonA':reason(a,ca),'no_reasonB':reason(b,cb),
      'A_state':POS if ya else NEG if ca else UNK,'B_state':POS if yb else NEG if cb else UNK,
      'post_count':len(post),'pre_count':len(pre),'post_median_gap_h':statistics.median([(post[i][0]-post[i-1][0])/3600 for i in range(1,len(post))]) if len(post)>1 else None,
      'last_gap_h':(end_seconds-post[-1][0])/3600 if post else None,'observation_h':end,
      'last_pre_age_h':-pre[-1][0]/3600 if pre else None,
      'rolling_post_state':rolling_screen(pre+post,True),
      'raw_missing_refA':a is None,'raw_missing_refB':b is None,'raw_no_followup':not post,
      'raw_both_present_without_pairA':a is not None and bool(post) and not ca,
      'raw_both_present_without_pairB':b is not None and bool(post) and not cb,
      'pre_state':meta['pre_state'],'both_refs_recent48':a is not None and b is not None and b[0]>=-H48,
      'refA_age_h':-a[0]/3600 if a else None,'refB_age_h':-b[0]/3600 if b else None,
      'chronic':meta['chronic'],'prior_chronic':meta['prior_chronic'],'rrt_documented':meta['rrt_documented'],
      'strict_bounds':meta['strict_bounds'],'death_conflict':meta['death_conflict'],
      'pairs_A':len(ca),'pairs_B':len(cb),'pairs_common':len(common)}

class Round5(Round3):
    def __init__(self,a,duckdb):
        super().__init__(a,duckdb)
        self.executed_paths=[Path(__file__),HERE/'analysis_stats.py',HERE/'audit_round2.py',HERE/'audit_round3.py',Path(a.codebook),Path(a.renal_rules)]
        self.start_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in self.executed_paths}

    def metadata(self):
        if self.a.source=='mimic':
            self.table('patients',['subject_id','gender','anchor_age'])
            self.table('admissions',['hadm_id','subject_id','deathtime','hospital_expire_flag'])
            self.c.execute(f'''CREATE TEMP TABLE formal_metadata AS SELECT f.*,r.* EXCLUDE(stay),
                'single_center' hospital,{trim('p.gender')} sex,
                epoch(least(f.tout,f.discharge)-f.t0) raw_end_seconds,
                epoch({ts('a.deathtime')}-f.t0) raw_death_seconds,
                try_cast(p.anchor_age AS INTEGER)=91 age_topcoded,
                {trim('a.deathtime')} death_raw,{ts('a.deathtime')} death_ts,
                coalesce(regexp_matches(trim(a.deathtime),'^[0-9]{{4}}-[0-9]{{2}}-[0-9]{{2}}[ T][0-9]{{2}}:[0-9]{{2}}:[0-9]{{2}}([.][0-9]+)?$'),false) death_clock_precision,
                try_cast(a.hospital_expire_flag AS INTEGER)=1 hospital_death_recorded
                FROM flags f JOIN renal_flags r USING(stay)
                JOIN patients p ON f.person=p.subject_id
                JOIN admissions a ON f.person=a.subject_id AND f.encounter=a.hadm_id''')
            self.c.execute('''ALTER TABLE formal_metadata ADD COLUMN death_h DOUBLE''')
            self.c.execute('UPDATE formal_metadata SET death_h=epoch(death_ts-t0)/3600.0')
            self.c.execute('ALTER TABLE formal_metadata ADD COLUMN death_valid BOOLEAN')
            self.c.execute('UPDATE formal_metadata SET death_valid=coalesce(death_clock_precision AND death_ts BETWEEN admit AND discharge AND death_ts>=t0,false)')
            self.c.execute('ALTER TABLE formal_metadata ADD COLUMN death_conflict BOOLEAN')
            self.c.execute('UPDATE formal_metadata SET death_conflict=death_raw IS NOT NULL AND NOT death_valid')
            self.r['death_quality']=self.rows('''SELECT count(*) F,
                count(*) FILTER(WHERE death_raw IS NOT NULL) nonblank_death,
                count(*) FILTER(WHERE death_raw IS NOT NULL AND death_ts IS NULL) unparseable,
                count(*) FILTER(WHERE death_raw IS NOT NULL AND NOT death_clock_precision) unverified_clock_precision,
                count(*) FILTER(WHERE death_valid) valid_death,
                count(*) FILTER(WHERE death_conflict) conflict,
                count(*) FILTER(WHERE death_ts<t0) before_entry,
                count(*) FILTER(WHERE death_ts<admit OR death_ts>discharge) outside_hospital,
                count(*) FILTER(WHERE death_valid AND death_h<end_h) observation_shortened,
                count(*) FILTER(WHERE hospital_death_recorded) hospital_death_status,
                count(*) FILTER(WHERE hospital_death_recorded AND death_raw IS NULL) death_status_without_time
                FROM formal_metadata''')[0]
        else:
            self.table('patient',['patientunitstayid','patienthealthsystemstayid','uniquepid','gender','age','unitdischargestatus','hospitaldischargestatus'])
            self.c.execute(f'''CREATE TEMP TABLE formal_metadata AS SELECT f.*,r.* EXCLUDE(stay),
                {trim('p.gender')} sex,replace(trim(p.age),' ','')='>89' age_topcoded,
                least(try_cast(p.unitdischargeoffset AS DECIMAL(18,6)),try_cast(p.hospitaldischargeoffset AS DECIMAL(18,6)))*60 raw_end_seconds,
                NULL::DOUBLE raw_death_seconds,
                lower(trim(p.unitdischargestatus))='expired' unit_death_recorded,
                lower(trim(p.hospitaldischargestatus))='expired' hospital_death_recorded,
                NULL::DOUBLE death_h,false death_valid,false death_conflict
                FROM flags f JOIN renal_flags r USING(stay)
                JOIN patient p ON f.stay={trim('p.patientunitstayid')}
                AND f.person={trim('p.uniquepid')} AND f.encounter={trim('p.patienthealthsystemstayid')}''')
            self.r['death_quality']=self.rows('''SELECT count(*) F,
                count(*) FILTER(WHERE unit_death_recorded) unit_death_status,
                count(*) FILTER(WHERE hospital_death_recorded) hospital_death_status FROM formal_metadata''')[0]
            self.r['death_quality']['precise_death_time']='not_available_not_inferred'
        precision=self.rows('''SELECT count(*) FILTER(WHERE raw_end_seconds IS NULL OR NOT isfinite(raw_end_seconds) OR raw_end_seconds<0) invalid_end,
            count(*) FILTER(WHERE abs(raw_end_seconds-round(raw_end_seconds))>0.000001) fractional_end,
            count(*) FILTER(WHERE death_valid AND abs(raw_death_seconds-round(raw_death_seconds))>0.000001) fractional_valid_death FROM formal_metadata''')[0]
        assert not any(precision.values()),'Endpoint precision requires explicit revision'
        self.c.execute('ALTER TABLE formal_metadata ADD COLUMN end_seconds BIGINT')
        self.c.execute('ALTER TABLE formal_metadata ADD COLUMN death_seconds BIGINT')
        self.c.execute('UPDATE formal_metadata SET end_seconds=cast(round(raw_end_seconds) AS BIGINT),death_seconds=CASE WHEN death_valid THEN cast(round(raw_death_seconds) AS BIGINT) END')
        self.r['endpoint_precision']=precision
        self.r['endpoint_precision'].update(self.rows('''SELECT count(*) FILTER(WHERE o.t=m.end_seconds) observations_exactly_at_recorded_end,
            count(*) FILTER(WHERE o.t=m.end_seconds AND o.t>m.end_h*3600) boundary_observations_lost_by_float_roundtrip,
            count(*) FILTER(WHERE m.death_valid AND o.t=m.death_seconds) observations_exactly_at_valid_death,
            count(*) FILTER(WHERE m.death_valid AND o.t=m.death_seconds AND o.t>m.death_h*3600) death_boundary_lost_by_float_roundtrip
            FROM observations o JOIN formal_metadata m USING(stay) WHERE o.t>=0''')[0])
        n=self.rows('SELECT count(*) n,count(DISTINCT stay) distinct_stays,count(DISTINCT person) persons,count(DISTINCT hospital) hospitals,count(*) FILTER(WHERE hospital IS NULL OR trim(hospital)=\'\') missing_hospital FROM formal_metadata')[0]
        assert n['n']==n['distinct_stays']==self.r['cohort_flow']['reviewed_cabg_candidates'],'Metadata cardinality'
        assert n['missing_hospital']==0,'Missing hospital prevents declared clustering'
        bad=self.rows('SELECT count(*) n FROM (SELECT encounter FROM formal_metadata GROUP BY encounter HAVING count(DISTINCT person)>1 OR count(DISTINCT hospital)>1)')[0]['n']
        assert bad==0,'Encounter identity mismatch'
        self.r['formal_identity_quality']=n
        self.r['formal_identity_quality']['persons_spanning_hospitals']=self.rows('SELECT count(*) n FROM (SELECT person FROM formal_metadata GROUP BY person HAVING count(DISTINCT hospital)>1)')[0]['n']
        self.r['age_quality']=self.rows('SELECT count(*) FILTER(WHERE age_topcoded) privacy_topcoded,count(*) FILTER(WHERE age IS NULL AND NOT coalesce(age_topcoded,false)) other_missing FROM formal_metadata')[0]
        return self.rows('SELECT * FROM formal_metadata')

    def sql_validate(self,records):
        self.c.execute('''CREATE TEMP TABLE formal_bounds AS SELECT stay,
             least(end_seconds,604800,CASE WHEN death_valid THEN death_seconds ELSE end_seconds END) end_t FROM formal_metadata''')
        self.c.execute('''CREATE TEMP TABLE formal_pairs AS
            SELECT o.stay,o.t,'A' strategy,'ratio' criterion,o.v>=a.v*1.5 positive
              FROM observations o JOIN refA a USING(stay) JOIN formal_bounds b USING(stay) WHERE o.t>=0 AND o.t<604800 AND o.t<=b.end_t AND o.t-a.t BETWEEN 1 AND 604800
            UNION ALL SELECT o.stay,o.t,'A','absolute',o.v-a.v>=0.3 FROM observations o JOIN refA a USING(stay) JOIN formal_bounds b USING(stay) WHERE o.t>=0 AND o.t<604800 AND o.t<=b.end_t AND o.t-a.t BETWEEN 1 AND 172800
            UNION ALL SELECT o.stay,o.t,'B','ratio',o.v>=a.v*1.5 FROM observations o JOIN refB a USING(stay) JOIN formal_bounds b USING(stay) WHERE o.t>=0 AND o.t<604800 AND o.t<=b.end_t AND o.t-a.t BETWEEN 1 AND 604800
            UNION ALL SELECT o.stay,o.t,'B','absolute',o.v-a.v>=0.3 FROM observations o JOIN refB a USING(stay) JOIN formal_bounds b USING(stay) WHERE o.t>=0 AND o.t<604800 AND o.t<=b.end_t AND o.t-a.t BETWEEN 1 AND 172800''')
        own=self.rows('SELECT stay,strategy,count(*) np,bool_or(positive) positive FROM formal_pairs GROUP BY 1,2')
        shared=self.rows('''SELECT a.stay,count(*) np,bool_or(a.positive) ap,bool_or(b.positive) bp
            FROM formal_pairs a JOIN formal_pairs b ON a.stay=b.stay AND a.t=b.t AND a.criterion=b.criterion
            WHERE a.strategy='A' AND b.strategy='B' GROUP BY 1''')
        own={(x['stay'],x['strategy']):x for x in own};shared={x['stay']:x for x in shared}
        for r in records:
            for s in ['A','B']:
                x=own.get((r['stay'],s))
                assert r['E'+s]==bool(x),'SQL own eligibility mismatch'
                assert r['Y'+s]==(x['positive'] if x else False),'SQL own detection mismatch'
                assert r['pairs_'+s]==(x['np'] if x else 0),'SQL pair count mismatch'
            x=shared.get(r['stay']);assert r['C']==bool(x),'SQL common eligibility mismatch'
            assert r['YAJ']==(x['ap'] if x else None) and r['YBJ']==(x['bp'] if x else None),'SQL common detection mismatch'
            assert r['pairs_common']==(x['np'] if x else 0),'SQL common pair count mismatch'
        return {'status':'PASS','n_stays_compared':len(records),'independent_implementations':'Python Decimal criterion/time dictionaries versus DuckDB DECIMAL SQL UNION and inner join',
            'own_comparison_keys':sum(x['np'] for x in own.values()),'shared_comparison_keys':sum(x['np'] for x in shared.values())}

    def analyze_all(self,metadata):
        from analysis_stats import analyze,hospital_summary,baseline_descriptions
        values=defaultdict(list)
        for stay,t,v in self.c.execute('SELECT stay,t,v FROM observations ORDER BY stay,t').fetchall():values[stay].append((t,v))
        for m in metadata:
            m['chronic']=m['prior_chronic'] or m['index_eskd'] or m['index_dialysis_status']
            m['age_descriptive']=None if m['age_topcoded'] and self.a.source=='mimic' else '>89' if m['age_topcoded'] else m['age']
            age=m['age_descriptive'];m['age_group']='>=80' if age=='>89' else 'unknown' if age is None else '18-64' if age<65 else '65-79' if age<80 else '>=80'
            m['pre_state']=rolling_screen(values[m['stay']],False)
        allrows=[make_record(m,values[m['stay']]) for m in metadata]
        validation=self.sql_validate(allrows)
        main=[r for r in allrows if not r['chronic']]
        variants={'main_168h':main,
            'prior_chronic_only_exclusion':[r for r in allrows if not r['prior_chronic']],
            'all_reviewed_F':allrows,
            'documented_chronic_stratum':[r for r in allrows if r['chronic']],
            'strict_hospital_bounds':[r for r in main if r['strict_bounds']],
            'exclude_death_time_conflicts':[r for r in main if not r['death_conflict']],
            'pre_positive':[r for r in main if r['pre_state']==POS],
            'pre_no_positive_observed':[r for r in main if r['pre_state']==NEG],
            'pre_not_evaluable':[r for r in main if r['pre_state']==UNK],
            'rrt_documented':[r for r in main if r['rrt_documented']],
            'no_rrt_documentation':[r for r in main if not r['rrt_documented']],
            'common_both_refs_recent48':[r for r in main if r['C'] and r['both_refs_recent48']],
            'common_two_post_times':[r for r in main if r['C'] and r['post_count']>=2],
            'common_two_post_final12h':[r for r in main if r['C'] and r['post_count']>=2 and r['last_gap_h']<=12],
            'common_two_post_final6h':[r for r in main if r['C'] and r['post_count']>=2 and r['last_gap_h']<=6]}
        for h in [48,72]:variants[f'main_{h}h']=[make_record(m,values[m['stay']],horizon=h) for m in metadata if not m['chronic']]
        # Legacy no-death-cap bridge is implementation validation, not another primary analysis.
        legacy=[make_record(m,values[m['stay']],death_cap=False) for m in metadata]
        expected={x['stratum']:x for x in self.r['screening_counts']}
        for label,rs in [('all_reviewed_cabg',legacy),('no_documented_chronic_status',[r for r in legacy if not r['chronic']])]:
            e=expected[label]
            assert len(rs)==e['n_stays'],'Legacy denominator bridge'
            for s in ['A','B']:
                assert sum(r['Y'+s] for r in rs)==e[s+'_positive_recorded_criterion'],'Legacy detection bridge'
                assert sum(not r['E'+s] for r in rs)==e[s+'_not_evaluable'],'Legacy unknown bridge'
            assert sum(r['C'] for r in rs)==e['common_evaluable'],'Legacy common bridge'
            assert sum(r['YAJ'] is True for r in rs)==e['common_A1_B1'],'Legacy common positive bridge'
            assert sum(r['YBJ'] is True and r['YAJ'] is False for r in rs)==e['common_A0_B1'],'Legacy discordance bridge'
        formal={'scope':'Exploratory v1.0 analysis after literature review; not AKI diagnostic accuracy or incident AKI risk',
            'source':self.a.source,'N':len(main),'F':len(allrows),'patient_rows_exported':False,
            'validation':validation,'legacy_bridge':'PASS','variants':{},
            'flow':{'F':len(allrows),'recorded_chronic_excluded':len(allrows)-len(main),'N':len(main)},
            'source_quality':{'death':self.r['death_quality'],'age':self.r['age_quality'],'identity':self.r['formal_identity_quality'],'endpoint_precision':self.r['endpoint_precision']},
            'python_dependencies':{},'observed_counts':{},'hospital_summary':None}
        import numpy
        formal['python_dependencies']={'numpy':numpy.__version__,'duckdb':self.r['duckdb'],'python':sys.version.split()[0]}
        for index,(name,rows) in enumerate(variants.items()):
            print(self.a.source+': estimating '+name+' with fixed cluster resampling.',flush=True)
            formal['variants'][name]=analyze(rows,self.a.source,replicates=self.a.replicates,seed=20261115,include_details=False)
        formal['baseline_descriptions']=baseline_descriptions(main)
        formal['hospital_summary']=hospital_summary(main,replicates=self.a.replicates,seed=20261115) if self.a.source=='eicu' else None
        # This dictionary contains aggregates only, never identifiers or raw rows.
        formal['observed_counts']={s:{'state':dict(Counter(r[s+'_state'] for r in main)),
            'not_evaluable_reason':dict(Counter(r['no_reason'+s] for r in main if not r['E'+s]))} for s in ['A','B']}
        formal['nonexclusive_missingness_flags']={k:sum(r[k] for r in main) for k in ['raw_missing_refA','raw_missing_refB','raw_no_followup','raw_both_present_without_pairA','raw_both_present_without_pairB']}
        formal['rolling_supplement']={'post_states':dict(Counter(r['rolling_post_state'] for r in main)),
            'pre_by_post_states':[{'pre':pre,'post':post,'n':sum(r['pre_state']==pre and r['rolling_post_state']==post for r in main)} for pre in [POS,NEG,UNK] for post in [POS,NEG,UNK]],
            'interpretation':'Observed rolling biochemical signal only, not incident clinical AKI'}
        formal['observation_summary']={}
        for name,rows in [('N',main),('EA',[r for r in main if r['EA']]),('not_EA',[r for r in main if not r['EA']]),('EB',[r for r in main if r['EB']]),('not_EB',[r for r in main if not r['EB']]),('C',[r for r in main if r['C']])]:
            summary={'n':len(rows)}
            for field in ['observation_h','pre_count','post_count','last_gap_h','post_median_gap_h','refA_age_h','refB_age_h','last_pre_age_h']:
                a=[r[field] for r in rows if r[field] is not None]
                summary[field]={'observed':len(a),'missing':len(rows)-len(a),'q1':float(numpy.quantile(a,.25)) if a else None,'median':float(numpy.quantile(a,.5)) if a else None,'q3':float(numpy.quantile(a,.75)) if a else None}
            formal['observation_summary'][name]=summary
        formal['joint_count_validation']={'N_nonempty':bool(main),'no_C_as_zero':all(r['YAJ'] is None and r['YBJ'] is None for r in allrows if not r['C'])}
        return formal

    def run5(self):
        try:
            print(self.a.source+': reconstructing reviewed cohort and legacy comparison checks.',flush=True)
            self.reviewed_cohort();self.renal_flags();self.screen()
            metadata=self.metadata()
            formal=self.analyze_all(metadata)
            for path,before in self.stats.items():
                s=path.stat();assert (s.st_size,s.st_mtime_ns)==before,'Source changed during run'
            formal['elapsed_seconds']=round(time.time()-self.t,2)
            formal['source_files']=self.r['inputs']
            end_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in self.executed_paths}
            assert end_hashes==self.start_hashes,'Executable source changed during run'
            formal['script_hashes']=self.start_hashes
            formal['loaded_module_paths']={x:sys.modules[x].__file__ for x in ['audit_round2','audit_round3','analysis_stats']}
            (self.out/'formal_analysis.json').write_text(json.dumps(formal,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
            self.r['status']='completed';self.r['stage']='legacy_bridge_only';self.save3()
            print(self.a.source+': formal analysis completed and validated.',flush=True)
        except Exception as exc:
            # No raw CSV values, SQL parameters or trace variables are written.
            diagnostic={'status':'failed','error_type':type(exc).__name__,'phase':'formal_v1_execution',
                'stack':[{'file':Path(f.filename).name,'function':f.name,'line':f.lineno} for f in traceback.extract_tb(exc.__traceback__)]}
            (self.out/'failure.json').write_text(json.dumps(diagnostic,indent=2),encoding='utf-8')
            print(self.a.source+': failed with '+type(exc).__name__+'; raw reader details withheld.',flush=True)
            raise SystemExit(2)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for arg in ['source','root','out','dependency-dir','stats-dependency-dir']:p.add_argument('--'+arg,required=True)
    p.add_argument('--memory-limit',default='4GB');p.add_argument('--replicates',type=int,default=2000)
    p.add_argument('--codebook',default=str(HERE/'cabg_review.json'));p.add_argument('--renal-rules',default=str(HERE/'renal_rules.json'))
    p.add_argument('--authorized-local-data',action='store_true');a=p.parse_args();a.stage='full'
    if a.source not in ['mimic','eicu'] or not a.authorized_local_data:p.error('Supported local authorized sources only.')
    if a.replicates<2000:p.error('Formal v1.0 uses at least2000 bootstrap replicates.')
    for path in [a.dependency_dir,a.stats_dependency_dir]:sys.path.insert(0,str(Path(path).resolve(strict=True)))
    import duckdb
    Round5(a,duckdb).run5()
if __name__=='__main__':main()
