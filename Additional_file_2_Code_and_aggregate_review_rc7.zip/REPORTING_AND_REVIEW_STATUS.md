# Reporting and review scope

Current version aki-code-2026-11-17-rc7. Software attribution and the representative's source/institution/third-party permission checks are confirmed. MIT and CC BY 4.0 scopes are implemented. No institutional ownership or ORCID is inferred.

Primary counts/estimates/CIs and existing SMDs are unchanged. Numerical secondary/hospital families remain outside the article's evidence, following the disclosed post-analysis history; their inventory is not robustness evidence. Independent external classification/CI reproduction remains incomplete. A proposed lawful request/execution procedure exists; the actual custodian, environment and execution status require real records.

Cohort and plotting source inputs retain their r3 filenames. Only documentation, metadata and Figure 2 presentation changed. Repository/archive availability is recorded by external landing pages and the separate release receipt.
